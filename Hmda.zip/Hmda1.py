import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
df = pd.read_csv("C:/Users/gshas/OneDrive/Desktop/GMU/AIT-582/project/hmda_test.csv")

def missing_values(df, percentage):
    columns = df.columns
    percent_missing = df.isnull().sum() * 100 / len(df)
    missing_value_df = pd.DataFrame({'column_name': columns, 'percent_missing': percent_missing})
    missing_drop = list(missing_value_df[missing_value_df.percent_missing>percentage].column_name)
    df = df.drop(missing_drop, axis=1)
    return df

data=missing_values(df,10)
df= pd.DataFrame(data)
df.replace('', np.NaN)
df=df.fillna(df.mean())

feature=['as_of_year','agency_code','loan_type','property_type','loan_purpose','owner_occupancy','loan_amount_000s','preapproval','msamd','state_code','county_code','census_tract_number','applicant_ethnicity','co_applicant_ethnicity','applicant_race_1','co_applicant_race_1','applicant_sex','co_applicant_sex','purchaser_type','hoepa_status','lien_status','population','minority_population','hud_median_family_income','tract_to_msamd_income','number_of_owner_occupied_units','number_of_1_to_4_family_units']
x= df[feature]#27 features
y=df["action_taken"]#target

from sklearn import model_selection
from sklearn.preprocessing import StandardScaler
x = StandardScaler().fit_transform(x)

X_train, X_test , Y_train, Y_test = model_selection.train_test_split(x, y, test_size=0.3, random_state=1)

from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor
rf = RandomForestRegressor()
rf.fit(X_train, Y_train)
##Features sorted by their score
important= (sorted(zip(map(lambda x: round(x, 4), rf.feature_importances_), x), reverse=True))
count=0
names=[]
for x in range(1, 1000):
    if(important[x][0]>0.01):
        count=count+1
        names.append(important[x][1])
    else:
        break

x=df[names]

accuracies = {}
mse= {}

x = StandardScaler().fit_transform(x)
x_train, x_test , y_train, y_test = model_selection.train_test_split(x, y, test_size=0.2, random_state=1)

random_forest = RandomForestClassifier(n_estimators=100,oob_score=True)
random_forest.fit(x_train, y_train)
y_pred = random_forest.predict(x_test)
accuracies['Random Forest']=accuracy_score(y_test,y_pred)
print(accuracies)