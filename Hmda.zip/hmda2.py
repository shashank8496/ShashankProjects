import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
df = pd.read_csv("C:/Users/gshas/OneDrive/Desktop/GMU/AIT-582/project/hmda_test.csv")

def missing_values(df, percentage):
    columns = df.columns
    percent_missing = df.isnull().sum() * 100 / len(df)
    missing_value_df = pd.DataFrame({'column_name': columns, 'percent_missing': percent_missing})
    missing_drop = list(missing_value_df[missing_value_df.percent_missing>percentage].column_name)
    df = df.drop(missing_drop, axis=1)
    return df

data=missing_values(df,10)
df= pd.DataFrame(data)
df.isna().sum()
df=df.fillna(df.mean())

collection=['as_of_year','agency_code','loan_type','property_type','loan_purpose','owner_occupancy','loan_amount_000s','preapproval','msamd','state_code','county_code','census_tract_number','applicant_ethnicity','co_applicant_ethnicity','applicant_race_1','co_applicant_race_1','applicant_sex','co_applicant_sex','purchaser_type','hoepa_status','lien_status','population','minority_population','hud_median_family_income','tract_to_msamd_income','number_of_owner_occupied_units','number_of_1_to_4_family_units']
df=df[['as_of_year','agency_code','loan_type','property_type','loan_purpose','owner_occupancy','loan_amount_000s','preapproval','msamd','state_code','county_code','census_tract_number','applicant_ethnicity','co_applicant_ethnicity','applicant_race_1','co_applicant_race_1','applicant_sex','co_applicant_sex','purchaser_type','hoepa_status','lien_status','population','minority_population','hud_median_family_income','tract_to_msamd_income','number_of_owner_occupied_units','number_of_1_to_4_family_units','action_taken']]
x= df[collection]#27 features
y=df["action_taken"]#target


# Standardizing the features
from sklearn.preprocessing import StandardScaler
x = StandardScaler().fit_transform(x)
accuracies = {}

##Featurte selection
import seaborn as sns
corrmat = df.corr()
print(corrmat)

plt.figure(figsize=(30,30))
g=sns.heatmap(corrmat,annot=True,cmap="RdYlGn", fmt='.2f')
plt.show()

X = df.iloc[:,0:27]  
'''
from sklearn.ensemble import ExtraTreesClassifier
import matplotlib.pyplot as plt
model = ExtraTreesClassifier()
model.fit(X,y)
print(model.feature_importances_) 
feat_importances = pd.Series(model.feature_importances_, index=X.columns)
feat_importances.nlargest(20).plot(kind='barh')
plt.show()
'''
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

bestfeatures = SelectKBest(score_func=chi2, k=10)
fit = bestfeatures.fit(X,y)
dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(X.columns)
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
featureScores.columns = ['Specs','Score']  #naming the dataframe columns
print(featureScores.nlargest(10,'Score'))

mainfeature=['hud_median_family_income','census_tract_number','loan_amount_000s','county_code','purchaser_type','msamd','number_of_owner_occupied_units','number_of_1_to_4_family_units','population','tract_to_msamd_income']
x=df[mainfeature]

from sklearn import model_selection
x_train, x_test , y_train, y_test = model_selection.train_test_split(x, y, test_size=0.2, random_state=1)



##logistic regression 
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

lr = LogisticRegression()
lr.fit(x_train,y_train)
acc = lr.score(x_test,y_test)
accuracies['logistic regression ']=acc
print("Test Accuracy {:.2f}%".format(acc))
print(classification_report(y_test,lr.predict(x_test)))

from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve
logit_roc_auc = roc_auc_score(y_test, lr.predict(x_test))
fpr, tpr, thresholds = roc_curve(y_test, lr.predict_proba(x_test)[:,1])
plt.figure()
plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.savefig('Log_ROC')
plt.show()


confusion_matrix = confusion_matrix(y_test, lr.predict(x_test))
print(confusion_matrix)


from sklearn import metrics
y_pred_proba = lr.predict_proba(x_test)[::,1]
fpr, tpr, _ = metrics.roc_curve(y_test,  y_pred_proba)
auc = metrics.roc_auc_score(y_test, y_pred_proba)
plt.plot(fpr,tpr,label="data 1, auc="+str(auc))
plt.legend(loc=4)
plt.show()

##descision tree 
from sklearn.tree import DecisionTreeClassifier 
classifier = DecisionTreeClassifier(max_leaf_nodes=128)
classifier.fit(x_train, y_train)
y_predict_test=classifier.predict(x_test)
y_predict_train=classifier.predict(x_train)
accuracies['descision tree']=classifier.score(x_test, y_test)
print("Classifier Accuracy:", '%f'%classifier.score(x_test, y_test))
print(classification_report(y_test,classifier.predict(x_test)))


##Ridge classifier
from sklearn.linear_model import RidgeClassifier
clf = RidgeClassifier().fit(x_train, y_train)
clf.score(x_train, y_train) 
accuracies['Ridge classifier']=clf.score(x_train, y_train)
print(classification_report(y_test,clf.predict(x_test)))


##feature generation 
def plotgraph(modelname, X ):
	Df = pd.DataFrame(data = X, columns = ['component 1', 'component 2']) 
    #storing new features generated in new Dataframe df
	finalDf = pd.concat([Df, df["action_taken"]], axis = 1)	
	fig = plt.figure(figsize = (8,8))  #size of 8*8
	ax = fig.add_subplot(1,1,1) 
	ax.set_xlabel(modelname + ' 1', fontsize = 10) #xlabel
	ax.set_ylabel(modelname +' 2', fontsize = 10)  #ylabel
	ax.set_title(modelname, fontsize = 20)         #title
	targets = [1,2,3,4,5,6]
	colors = ['r', 'g','b','k','y','m']
	for target, color in zip(targets,colors): #new iterator with both variables combined (random)
		indicesToKeep = finalDf['action_taken'] == target
		ax.scatter(finalDf.loc[indicesToKeep,'component 1'], finalDf.loc[indicesToKeep, 'component 2'] , c = color , s = 20)
	ax.legend(targets)
	ax.grid()

from sklearn.decomposition import PCA
pca = PCA(n_components=2)#,whiten=True,random_state=20
pc = pca.fit_transform(x)
plotgraph('PCA',pc)

x_train, x_test , y_train, y_test = model_selection.train_test_split(pc, y, test_size=0.2, random_state=1)

from sklearn.linear_model import RidgeClassifier
from sklearn.metrics import classification_report
clf = RidgeClassifier().fit(x_train, y_train)
clf.score(x_train, y_train) 
accuracies['Ridge classifier']=clf.score(x_train, y_train)
print(classification_report(y_test,clf.predict(x_test)))

#XGboost
import xgboost as xgb
from sklearn.metrics import precision_score, recall_score
D_train = xgb.DMatrix(x_train, label=y_train)
D_test = xgb.DMatrix(x_test, label=y_test)
param = {
    'eta': 0.3, 
    'max_depth': 5,  'nfold': 5,
    'objective': 'multi:softprob',
    'num_class': 9} 

steps = 100  # The number of training iterations
model = xgb.train(param, D_train, steps)


preds = model.predict(D_test)
best_preds = np.asarray([np.argmax(line) for line in preds])

pre=precision_score(y_test, best_preds, average='macro')
print("Precision = {}".format(pre))
rec=recall_score(y_test, best_preds, average='macro')
print("Recall = {}".format(rec))
acc=accuracy_score(y_test, best_preds)
accuracies['xgboost'] = acc
print("Accuracy {:.2f}%".format(acc))

f1=2*((pre*rec)/(pre+rec))

print("F1 Score ={}".format(f1))