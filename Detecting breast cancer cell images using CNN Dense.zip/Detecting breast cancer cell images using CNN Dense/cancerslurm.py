import json
import math
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image
from sklearn.model_selection import train_test_split
from tqdm import tqdm
from keras import layers
from keras.applications import DenseNet169,DenseNet201
from keras.callbacks import Callback, ModelCheckpoint, ReduceLROnPlateau, TensorBoard
from keras.preprocessing.image import ImageDataGenerator
from keras.utils.np_utils import to_categorical
from keras.models import Sequential
from keras.optimizers import Adam
from sklearn.metrics import roc_auc_score, auc,roc_curve,confusion_matrix,accuracy_score

def load_images(DIR, sigmaX=10):
    IMG = []
    read = lambda imname: np.asarray(Image.open(imname).convert("RGB"))
    for img_name in tqdm(os.listdir(DIR)):
        try:
            PATH = os.path.join(DIR,img_name)
            _, ftype = os.path.splitext(PATH)
            #if ftype == ".svs":    #type of image to read
            img = read(PATH)
            img = cv2.resize(img, (224,224))
            IMG.append(np.array(img))
        except:
            print("Issue files")
            print(img_name)
            continue
    return IMG

carcinoma0_train = np.array(load_images('/scratch/sgourise/data/cancer0/'))#training non cancer images
carcinoma1_train = np.array(load_images('/home/sgourise/AIT690/project/data/cancer1/'))#training cancer images
carcinoma0_test = np.array(load_images('/home/sgourise/AIT690/project/data/cancer0_test/'))#test non cancer images
carcinoma1_test = np.array(load_images('/home/sgourise/AIT690/project/data/cancer1_test/'))#test cancer images

carcinoma0_train_label = np.zeros(len(carcinoma0_train))
carcinoma1_train_label = np.ones(len(carcinoma1_train))
carcinoma0_test_label = np.zeros(len(carcinoma0_test))
carcinoma1_test_label = np.ones(len(carcinoma1_test))

X_train = np.concatenate((carcinoma0_train, carcinoma1_train), axis = 0)
Y_train = np.concatenate((carcinoma0_train_label, carcinoma1_train_label), axis = 0)
X_test = np.concatenate((carcinoma0_test, carcinoma1_test), axis = 0)
Y_test = np.concatenate((carcinoma0_test_label, carcinoma1_test_label), axis = 0)

s = np.arange(X_train.shape[0])
np.random.shuffle(s)
X_train = X_train[s]
Y_train = Y_train[s]

s = np.arange(X_test.shape[0])
np.random.shuffle(s)
X_test = X_test[s]
Y_test = Y_test[s]

Y_train = to_categorical(Y_train, num_classes= 2)
Y_test = to_categorical(Y_test, num_classes= 2)

x_train, x_val, y_train, y_val = train_test_split(X_train, Y_train,test_size=0.2, random_state=11)

fig=plt.figure(figsize=(15, 15))
columns = 2
rows = 2
#sample 4 images with titles
for i in range(1, columns*rows +1):
    ax = fig.add_subplot(rows, columns, i)
    if np.argmax(Y_train[i]) == 0:
        ax.title.set_text('cancer 0')
    else:
        ax.title.set_text('cancer 1')
    plt.imshow(x_train[i], interpolation='nearest')

plt.savefig('/scratch/sgourise/'+'Breif.png')
plt.close()
#set parameters
train_generator = ImageDataGenerator(zoom_range=2,rotation_range = 45,brightness_range=[0.2,1.0],horizontal_flip=True,vertical_flip=True,)

# lr is learning rate
def build_model():
    model = Sequential()
    model.add(DenseNet169(weights='imagenet',include_top=False,input_shape=(224,224,3)))
    model.add(layers.GlobalAveragePooling2D())
    model.add(layers.Dropout(0.3))
    model.add(layers.BatchNormalization())
    model.add(layers.Dense(2, activation='softmax'))
    model.compile(loss='binary_crossentropy',optimizer=Adam(lr=0.0001),metrics=['accuracy'])
    return model

model = build_model()
model.summary()

from keras.utils.vis_utils import plot_model
plot_model(model, to_file='/scratch/sgourise/model_plot.png', show_shapes=True, show_layer_names=True)

learn_control = ReduceLROnPlateau(monitor='val_acc', patience=5,verbose=1,factor=0.2, min_lr=0.0001)
filepath="/scratch/sgourise/model_weights/cnn_model1.hdf5"

if not os.path.isdir('/scratch/sgourise/model_weights/'):
    os.mkdir('/scratch/sgourise/model_weights/')
model.save_weights(filepath, overwrite=True)

#set number of epochs for training model
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=True, mode='max')
history = model.fit_generator(train_generator.flow(x_train, y_train, batch_size=16),steps_per_epoch=x_train.shape[0] / 16, epochs=50, validation_data=(x_val, y_val),callbacks=[learn_control, checkpoint])

with open('/scratch/sgourise/history.json', 'w') as f:
    json.dump(str(history.history), f)
model.load_weights(filepath)

print("Validation accuracy is ")
Y_val_pred = model.predict(x_val)
print(accuracy_score(np.argmax(y_val, axis=1), np.argmax(Y_val_pred, axis=1)))
print("Test accuracy is")
Y_pred = model.predict(X_test)
print(accuracy_score(np.argmax(Y_test, axis=1), np.argmax(Y_pred, axis=1)))

score = model.evaluate(X_test, Y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])

print("Confusion Matrix")
print(confusion_matrix(np.argmax(Y_test, axis=1), np.argmax(Y_pred, axis=1)))
#ROC plot
import matplotlib.pyplot as plt2
roc_log = roc_auc_score(np.argmax(Y_test, axis=1), np.argmax(Y_pred, axis=1))
fpr, tpr, threshold = roc_curve(np.argmax(Y_test, axis=1), np.argmax(Y_pred, axis=1))
area_under_curve = auc(fpr, tpr)

plt2.plot([0, 1], [0, 1], 'r--')
plt2.plot(fpr, tpr, label='AUC = {:.3f}'.format(area_under_curve))
plt2.xlabel('False positive rate')
plt2.ylabel('True positive rate')
plt2.title('ROC curve')
plt2.legend(loc='best')
plt2.savefig('/scratch/sgourise/'+'Roc.png')
plt2.close()
#loss plot
history_df = pd.DataFrame(history.history)
plot1=history_df[['loss', 'val_loss']].plot()
fig=plot1.get_figure()
fig.savefig('/scratch/sgourise/'+'Loss.png')

#accuracy plot
plot2=history_df[['accuracy', 'val_accuracy']].plot()
fig1=plot2.get_figure()
fig1.savefig('/scratch/sgourise/'+'Accuracy.png')

print("End")