#!/bin/bash
python /home/sgourise/AIT690/project/code/cancerslurm.py