#!/bin/bash
IFS=","
rm -v /home/sgourise/AIT690/project/data/cancer0/*
rm -v /home/sgourise/AIT690/project/data/cancer0_test/*
rm -v /home/sgourise/AIT690/project/data/cancer1/*
rm -v /home/sgourise/AIT690/project/data/cancer1_test/*
echo "Input folder name is $1"
echo "target csv is $2"

#cp /home/sgourise/AIT690/project/backup/svsimages/*  /home/sgourise/AIT690/project/images/
while read f1 f2
do    
	imagename="/home/sgourise/AIT690/project/backup/svsimages/${f1}"
	echo "$imagename"
    echo "Target is    : $f2"
	STRLENGTH=$(echo -n $f2 | head -c 1)
	
	if [ "$STRLENGTH" = "0" ]
	then
	echo "0"
	mv $imagename /home/sgourise/AIT690/project/data/cancer0/
#	mv $imagename /home/sgourise/AIT690/project/data/cancer0_test/
	else
	echo "1"
	mv $imagename /home/sgourise/AIT690/project/data/cancer1/
#	mv $imagename /home/sgourise/AIT690/project/data/cancer1_test/	
	fi

done < /home/sgourise/AIT690/project/images/targetsvs.csv

#find /home/sgourise/AIT690/project/data/cancer0/ -type f -name "*.png" -print0 | xargs -0 shuf -e -n 497 -z | xargs -0 mv -vt /home/sgourise/AIT690/project/data/cancer0_test/
#find /home/sgourise/AIT690/project/data/cancer1/ -type f -name "*.png" -print0 | xargs -0 shuf -e -n 1088 -z | xargs -0 mv -vt /home/sgourise/AIT690/project/data/cancer1_test/
