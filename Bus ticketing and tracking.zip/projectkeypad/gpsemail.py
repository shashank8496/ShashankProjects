import smtplib
import time
import os
from socket import *
import RPi.GPIO as GPIO
import sys
import MySQLdb as db
from time import strftime

smtpUser ='rtc.raspberrypi@gmail.com'
smtpPass='raspberrypi'
toAdd ='gshashi8@gmail.com'
fromAdd =smtpUser

name="BUSTICKETINGSYS"
con = db.connect("localhost", "root", "123")
cur = con.cursor()
cur.execute("use "+name)
       
print "buslocation" 
cur.execute(("SELECT LOCATION,SEATS FROM reallocation WHERE GPS_ID=1"))
result=cur.fetchall()
for row in result:
   location=row[0]
   seat=row[1]   
#####

subject ='BUS location'
header ='To: '+ toAdd +'\n' +'From: ' +fromAdd + '\n' + 'Subject:' +subject

body1 =location
body2='no of seats unoccupied are '+str(seat)

body=body1 +'\n'+ body2

print header + '\n' + body
s=smtplib.SMTP('smtp.gmail.com',587)

s.ehlo()
s.starttls()
s.ehlo()
s.login(smtpUser,smtpPass)
s.sendmail(fromAdd, toAdd,header + '\n\n'+ body)
s.quit()
                                                                                                                
                                                                                                                 
             
