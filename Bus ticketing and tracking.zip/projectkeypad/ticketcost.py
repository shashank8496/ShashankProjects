#from keypad import *           #for keypad input    
#from keyboard import *          #for keyboard input
#print " from keypad file=%d" %(keyvalue)
#i=keyvalue     #from keypad.py file
#i=SD 		#value from keyboard.py file

def ticketcost(i):
 
 if i==0:
   journey=2
   cost=0
 elif i==1:
   journey=4
   cost=1
 elif i==2:
   journey=6
   cost=2
 elif i==3:
   journey=8
   cost=3
 elif i==4:
   journey=10   
   cost=4
 elif i==5:
   cost=5
   journey=12
 elif i==6:
   journey=14
   cost=6
 elif i==7:
   journey=16 
   cost=7
 elif i==8:
   journey=18
   cost=8
 elif i==9: 
   journey=20 
   cost=9
   
 print "ticket cost=%d" %(cost)
 return cost,journey
 

