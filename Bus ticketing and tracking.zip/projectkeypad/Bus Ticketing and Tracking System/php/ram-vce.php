<!DOCTYPE Html>
<Html>
<Head>
<meta http-equiv="refresh" content="3" > 
<link href='temp.css' rel='stylesheet' type='text/css'/>
</Head>
<body>

<ul>
  <li><a class="active" href="indexrtc.php">ALL</a></li>
  <li><a href="tdate.php">Tdate & Ttime</a></li>

  <li class="dropdown">
    <a href="rtcallzone.php" class="dropbtn">Zone</a>
    <div class="dropdown-content">
      <a href="dsnr-vce.php">DSNR-VCE</a>
      <a href="ram-vce.php">RAM-VCE</a>

   
    </div>
  
</ul>
      <h3 style="Color:deeppink; padding-left:220px;"><u>Display BUSES BETWEEN RAM AND VCE </u></h3>

	  <section class="scroll">
<?php
$servername="localhost";
$username="root";
$password="123";
$dbname="BUSTICKETINGSYS";

//creating connection to database

$conn=mysqli_connect($servername,$username,$password,$dbname);

//checking connection
if(!$conn){
	echo"Failed to connect!".mysql_error()."<br>";
}
else{
	echo"<h3></h3>";
}

//executing query

$sql="SELECT * FROM reallocation WHERE GPS_ID=2;";
if($result=mysqli_query($conn,$sql)){
	if(mysqli_num_rows($result)>0){
		
		echo "<table>";
            echo "<tr>";
                echo "<th>LOCATION</th>";
                echo "<th>SEATS</th>";
                
            echo "</tr>";
			while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['LOCATION'] . "</td>";
		echo "<td>" . $row['SEATS'] . "</td>";                

            echo "</tr>";
        }
        echo "</table>";
        // Close result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
	

?>
</section>

<footer>
BUS TICKETING AND TRACKING SYSTEM
<h5>Powered by : SHASHANK</h5>
</footer>

</body>
</Html>