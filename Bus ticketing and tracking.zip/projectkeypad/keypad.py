import time
import os
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

row1 = 1 #physical pin=7
row2 = 2 #physical pin=11
row3 = 3 #physical pin=40
row4 = 4 #physical pin=13
col1 = 5 #physical pin=13
col2 = 6 #physical pin=13
col3 = 7 #physical pin=13

print "In Progress"

GPIO.setup(row1,GPIO.IN)
GPIO.setup(row2,GPIO.IN)
GPIO.setup(row3,GPIO.IN)
GPIO.setup(row4,GPIO.IN)
GPIO.setup(col1,GPIO.IN)
GPIO.setup(col2,GPIO.IN)
GPIO.setup(col3,GPIO.IN)



if ( not (GPIO.input(1) & GPIO.input(5))):
     time.sleep(.500)
     keyvalue=1
     print("1")
elif ( not (GPIO.input(1) & GPIO.input(6))):
    time.sleep(.500)
    print("2")
    keyvalue=2
elif ( not (GPIO.input(1) & GPIO.input(7))):
    time.sleep(.500)
    print("3")
    keyvalue=3
elif ( not (GPIO.input(2) & GPIO.input(5))):
    time.sleep(.500)
    print("4")
    keyvalue=4
elif ( not (GPIO.input(2) & GPIO.input(6))):
    time.sleep(.500)
    print("5")
    keyvalue=5
elif ( not (GPIO.input(2) & GPIO.input(7))):
    time.sleep(.500)
    print("6")
    keyvalue=6
elif ( not (GPIO.input(3) & GPIO.input(5))):
    time.sleep(.500)
    print("7")
    keyvalue=7
elif ( not (GPIO.input(3) & GPIO.input(6))):
    time.sleep(.500)
    print("8")
    keyvalue=8
elif ( not (GPIO.input(3) & GPIO.input(7))):
    time.sleep(.500)
    print("9")
    keyvalue=9
elif ( not (GPIO.input(4) & GPIO.input(5))):
    time.sleep(.500)
    print("*")
    keyvalue=10
elif ( not (GPIO.input(4) & GPIO.input(6))):
    time.sleep(.500)
    print("0")
    keyvalue=0
elif ( not (GPIO.input(4) & GPIO.input(7))):
    time.sleep(.500)
    print("#")
    keyvalue=11

GPIO.cleanup()

