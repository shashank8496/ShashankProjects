import time
import os
from socket import *
import RPi.GPIO as GPIO
import sys
import MySQLdb as db
from time import strftime
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


name="BUSTICKETINGSYS"
con = db.connect("localhost", "root", "123")
cur = con.cursor()
cur.execute("CREATE DATABASE IF NOT EXISTS "+name)
cur.execute("use "+name)
cur.execute("create table IF NOT EXISTS cardholders( CARD_ID int(3) NOT NULL,NAME  varchar(10) NOT NULL,PASSWORD int(3),PHONE_NUMBER bigint(20) NOT NULL,EMAIL_ID varchar(30) NOT NULL,BALANCE int(3) NOT NULL,LASTUSED DATETIME NOT NULL,TEMPPSWD varchar(3))")



cardid=103
name='sma'
balance=400
emailid='smaran.technodreamz@gmail.com'
password=103
num=1003

datetimewrite = (time.strftime("%Y-%m-%d ") + time.strftime("%H:%M:%S"))
print datetimewrite
sql = ("INSERT INTO cardholders(CARD_ID,NAME,PASSWORD,PHONE_NUMBER,EMAIL_ID,BALANCE,LASTUSED) VALUES (%d,'%s',%d,%d,'%s',%d,'%s')" %(cardid,name,password,num,emailid,balance,datetimewrite))

try:
    print "Writing to database..."
    cur.execute(sql)
    con.commit()
except:
   
    con.rollback()
    print "rollback"
time.sleep(3)
cur.close()
con.close()

