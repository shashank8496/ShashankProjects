import time
import MySQLdb as db
from time import strftime

name="BUSTICKETINGSYS"
con = db.connect("localhost", "root", "123")
cur = con.cursor()
cur.execute("CREATE DATABASE IF NOT EXISTS "+name)
cur.execute("use "+name)
cur.execute("create table IF NOT EXISTS reallocation( GPS_ID int(2) NOT NULL,SEATS INT(2) NOT NULL,BUSROUTE  varchar(10) NOT NULL,LOCATION blob(20))")
#while True:

gpsid=2
seats=4
busroute='ram-vce'
location='https.//www.google.com/maps/place/17.38825578.527307' 
sql = ("INSERT INTO reallocation(GPS_ID,SEATS,BUSROUTE,LOCATION) VALUES (%d,%d,'%s','%s')" %(gpsid,seats,busroute,location))

try:
    print "Writing to reallocation database..."
    cur.execute(sql)
    con.commit()
except:
    con.rollback()
    print "rollback"

time.sleep(2)
seats=seats+1
cur.close()
con.close()


