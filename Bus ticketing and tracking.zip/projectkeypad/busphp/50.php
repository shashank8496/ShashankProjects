<?php
$servername="localhost";
$username="root";
$password="123";
$dbname="BUSTICKETINGSYS";

//creating connection to database

$conn=mysqli_connect($servername,$username,$password,$dbname);

//checking connection
if(!$conn){
	echo"Failed to connect!".mysql_error()."<br>";
}
else{
	echo"<h3></h3>";
}

//executing query




$sql="UPDATE cardholders SET BALANCE=1000 WHERE CARD_ID=94;";

$sql="SELECT * FROM cardholders WHERE CARD_ID=94;";

if($result=mysqli_query($conn,$sql))
{
	if(mysqli_num_rows($result)>0)
          { 
	    echo "<table>";
            echo "<tr>";
                echo "<th>CARD_ID</th>"; 
                echo "<th>BALANCE</th>";
                 
            echo "</tr>";	
	   while($row = mysqli_fetch_array($result)){
        
         
         echo "<tr>";
          
                echo "<td>" . $row['CARD_ID'] . "</td>";        
                echo "<td>" . $row['BALANCE'] . "</td>";
		
         echo "</tr>";
        } echo "</table>";
   mysqli_free_result($result);
}
      
     
 else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
	

?>