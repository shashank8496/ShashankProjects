<!DOCTYPE Html>
<Html>
<Head>
<meta http-equiv="refresh" content="3" > 
<link href='temp.css' rel='stylesheet' type='text/css'/>
</Head>
<body>

<ul>
  <li><a class="active" href="index.php">ALL</a></li>
  <li><a href="tdate.php">Tdate & Ttime</a></li>

  <li class="dropdown">
    <a href="allzone.php" class="dropbtn">Zone</a>
    <div class="dropdown-content">
      <a href="greenhouse.php">Greenhouse</a>
      <a href="garage.php">Garage</a>
      <a href="kitchen.php">Kitchen</a>
    </div>
  </li>
         <li class="dropdown">
    <a href="index.php" class="dropbtn">Temperature</a>
    <div class="dropdown-content">
      <a href="temp1.php"> 0-20 &#8451 </a>
      <a href="temp2.php"> 20-40 &#8451 </a>
      <a href="temp3.php"> 40-50 &#8451 </a>
      <a href="temp4.php"> 50-100 &#8451 </a>
    
    </div>
	</li>
	
</ul>
    <h3 style="Color:deeppink; padding-left:190px;"><u>Temperature based on latest date and time</u></h3> 
<section class="scroll">
<?php
$servername="localhost";
$username="root";
$password="123";
$dbname="TESTDB";

//creating connection to database

$conn=mysqli_connect($servername,$username,$password,$dbname);

//checking connection
if(!$conn){
	echo"Failed to connect!".mysql_error()."<br>";
}
else{
	echo"<h3></h3>";
}

//executing query

//$sql="SELECT * FROM tempdat";
$sql="SELECT * FROM tempLog ORDER BY YEAR(daytime) DESC , MONTH(daytime) DESC , DAY(daytime) DESC, HOUR(daytime) DESC, MINUTE(daytime) DESC, SECOND(daytime) DESC;";
if($result=mysqli_query($conn,$sql)){
	if(mysqli_num_rows($result)>0){
		
		echo "<table>";
            echo "<tr>";
                echo "<th>daytime</th>";
                echo "<th>zone</th>";
                echo "<th>temperature</th>";
            echo "</tr>";
			while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['daytime'] . "</td>";
                echo "<td>" . $row['zone'] . "</td>";
                echo "<td>" . $row['temperature'] . "&#8451</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Close result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
	

?>
</section>

<footer class="footer_wrapper">
Copyright &copy; 2016 www.uptecidealabs.com
<h5>Powered by :Maker Space</h5>
</footer>

</body>
</Html>
