<!DOCTYPE Html>
<Html>
<Head>
<meta http-equiv="refresh" content="3" > 
<link href='temp.css' rel='stylesheet' type='text/css'/>
</Head>
<body>

<ul>
  <li><a class="active" href="indexrtc.php">ALL</a></li>
  <li><a href="tdate.php">Tdate & Ttime</a></li>
  <li><a class="active" href="bal50.php">RECHARGE</a></li>
  <li class="dropdown">
    <a href="rtcallzone.php" class="dropbtn">Zone</a>
    <div class="dropdown-content">
      <a href="dsnr-vce.php">DSNR-VCE</a>
      <a href="ram-vce.php">RAM-VCE</a>

   
    </div>
  
</ul>
<h3 style="Color:deeppink; padding-left:220px;"><u>Display BUSES BETWEEN DSNR AND VCE </u></h3>

	  <section class="scroll">
        <head>
	<title>HTML Button Tag</title>
	</head>
	<form method="get" action="50.php">
	<button type="submit">continue</button>
	</form>

</section>

<footer>
BUS TICKETING AND TRACKING SYSTEM
<h5>Powered by : SHASHANK</h5>
</footer>

</body>
</Html>