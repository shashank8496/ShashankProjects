


def placefun(num):
 if(num==0):
  place='DSNR'
 elif(num==1):
  place='MALAKPET'
 elif(num==2):
  place='CHADERGHAT'
 elif(num==3):
  place='KOTI'
 elif(num==4):
  place='ABIDS'
 elif(num==5):
  place='ASSEMBLY'
 elif(num==6):
  place='LP'
 elif(num==7):
  place='MP'
 elif(num==8):
  place='LANGAR HOUZ'
 elif(num==9):
  place='VCE'
 elif(num==20):
  place='N.A'
 return place
