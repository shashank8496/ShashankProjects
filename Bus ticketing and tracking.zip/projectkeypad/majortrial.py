import time
import os
from socket import *
import RPi.GPIO as GPIO
import sys
import MySQLdb as db
from time import strftime
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
import smtplib
#from ticketcost import *
from getopt import getopt
from keyboard import *
import getpass

ticketsissued=0
totalrevenue=0
cost=0 
RFIDNUM=94

smtpUser ='rtc.raspberrypi@gmail.com'
smtpPass='raspberrypi'
fromAdd =smtpUser

name="BUSTICKETINGSYS"
con = db.connect("localhost", "root", "123")
cur = con.cursor()
cur.execute("use "+name)



while True:
 print "\tWelcome \n  Please scan RFID card \n"
 pswdd=getpass.getpass('Enter Password :')

 sql = (("UPDATE cardholders SET TEMPPSWD='%s' WHERE CARD_ID=%d") %(pswdd,RFIDNUM))

 try:
    print "checking password\n"
    cur.execute(sql)
    con.commit()
 except:
 
    con.rollback()
    print "rollback"


 if  (cur.execute(("select PASSWORD,TEMPPSWD from cardholders AS pr where((NOT EXISTS(SELECT PASSWORD,TEMPPSWD FROM cardholders as p WHERE (( PASSWORD<>pr.TEMPPSWD)&&(CARD_ID=%d))))&&(CARD_ID=%d))") %(RFIDNUM,RFIDNUM))):

  print "password correct\n" 
  cost,journey,sp,dp=keyboardfun()
  
  boardingpoint=sp
  destinationpoint=dp
  journeydistance=journey       
  driverIDdetails=123          
  conductorIDdetails=124      
  faircharges=cost           
  
  cur.execute(("SELECT BALANCE,EMAIL_ID,NAME FROM cardholders WHERE CARD_ID=%d") %(RFIDNUM))
  result=cur.fetchall()

  for row in result:
   balance=row[0]
   emailid=row[1]
   passengername=row[2]     


  print "beforetransaction balance=%d \n" %(balance)
  
  newbalance=balance-faircharges
  
  ticketsissued=ticketsissued+1
  totalrevenue=totalrevenue+cost

  qu=(("UPDATE cardholders SET balance=%d WHERE CARD_ID=%d") %(newbalance,RFIDNUM))

  try:
    
     cur.execute(qu)
     con.commit()
     time.sleep(1)
  except:
     con.rollback()
     time.sleep(1)

  #print " name= %s \n balance=%d   \n email=%s \n faircharges=%d \n  "%(passengername,newbalance,emailid,faircharges)


     ######
  print"\n\n"
  toAdd =''+emailid

  subject ='Ticket details'

  header ='To: '+ toAdd +'\n' +'From: ' +fromAdd + '\n' + 'Subject:' +subject

  body1 ='boarding point='+boardingpoint
  time.sleep(.200)
  body2 ='destination point='+destinationpoint
  time.sleep(.200)
  body3='balanceamount='+str(newbalance)
  time.sleep(.200)
  body4='Passenger name : '+passengername
  time.sleep(.200)
  body5='Driverdetails  : '+str(driverIDdetails)
  time.sleep(.200)
  body6='Conductor details : '+str(conductorIDdetails)
  time.sleep(.200)
  body7='Ticket cost : '+str(faircharges)
  time.sleep(.200)
  body8='Journey distance : '+str(journeydistance)
 
  body =body4+'\n'+body1+'\n'+body2+'\n'+ body7+'\n'+body3+'\n'+body5+ '\n'+body6+'\n'+body8

  print header + '\n' + body
  s=smtplib.SMTP('smtp.gmail.com',587)

  s.ehlo()
  s.starttls()
  s.ehlo()
  s.login(smtpUser,smtpPass)
  s.sendmail(fromAdd, toAdd,header + '\n\n'+ body)
  s.quit()
  
 else:
  print "wrong password" 

 #ticketsissued=ticketsissued+1
 #totalrevenue=totalrevenue+cost
 time.sleep(.200)
 print "\nNo. of Tickets issued = %d \nTotal revenue = %d \n" %(ticketsissued,totalrevenue)
cur.close()
con.close

