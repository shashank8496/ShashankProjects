import smtplib

smtpUser ='rtc.raspberrypi@gmail.com' 
smtpPass='raspberrypi'
toAdd ='shailender2596@gmail.com'
fromAdd =smtpUser

subject ='Python test'
header ='To: '+ toAdd +'\n' +'From: ' +fromAdd + '\n' + 'Subject:' +subject
body ='https.//www.google.com/maps/place/26.189,91.701'
print header + '\n' + body
s=smtplib.SMTP('smtp.gmail.com',587)

s.ehlo()
s.starttls()
s.ehlo()
s.login(smtpUser,smtpPass)
s.sendmail(fromAdd, toAdd,header + '\n\n'+ body)
s.quit()
