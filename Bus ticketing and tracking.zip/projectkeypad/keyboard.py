from ticketcost import ticketcost 
from places import *

def keyboardfun():
 print " for internet press * \n for ticket press #"
 d=raw_input("Enter choice :")

 if(d=='*'):
  print"internet"
  cost=10
  journey=0
  sp=placefun(20)
  dp=placefun(20)
  return cost,journey,sp,dp
 elif(d=='#'):

  print "Ticket \n\nEnter Starting and Boarding Points Code \n "
 
  print " 0->DSNR\n 1->MALAKPET\n 2->CHADERGHAT\n 3->KOTI\n 4->ABIDS\n 5->ASSEMBLY\n 6->LP\n 7->MP\n 8->LANGARHOUZ\n 9->VCE"

  SP=raw_input("Enter Starting point :")
  sp=placefun(int(SP))
  print sp

  DP=raw_input("Enter Destination point :")
  dp=placefun(int(DP))
  print dp
 
  SD=int(DP)-int(SP)
  print SD
  cost,journey=ticketcost(SD)
  return cost,journey,sp,dp

