package e5_RandomBag;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;
import edu.princeton.cs.algs4.StdRandom;

public class RandomBag<Item> implements Iterable<Item> {
	Item[] array;
	int W;
	public void add(Item value)
	{
		array[W]=value;
		W++;
	}
	public RandomBag(int length)
	{
		array=(Item[])new Object[length];
		W=0;
	}
	@SuppressWarnings("unchecked")
	public Iterator iterator()
	{
		StdRandom.shuffle(array,0,W-1);
		return new BagIterator();
	}
	public int size()
	{
		return W;
	}

	public boolean isEmpty()
	{
		return W==0;
	}
	@SuppressWarnings("rawtypes")
	private class BagIterator implements Iterator
	{
		private int p=0;
		public boolean hasNext()
		{
			return p<W;
		}
		public Item next()
		{
			if(!hasNext())
				throw new NoSuchElementException();
			Item value=array[(p)%array.length];
			p++;
			return value;
		}
		public void remove()
		{
	}

}
@SuppressWarnings({ "unchecked", "rawtypes", "resource" })
public static void main(String[] args)
{
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Test case 3");
	System.out.print("Enter size of the bag:");
	Scanner sc=new Scanner(System.in);
	int length=sc.nextInt();
	RandomBag randBag=new RandomBag(length);
	System.out.println("Enter string elements:");
	for(int i=0;i<length;i++)
	{
		String item=sc.next();
		randBag.add(item);
	}
	System.out.println("Bag size:" +randBag.size());
	for(Object o: randBag)
	{
		if(o != null)
			System.out.println(o);
	}
}
}