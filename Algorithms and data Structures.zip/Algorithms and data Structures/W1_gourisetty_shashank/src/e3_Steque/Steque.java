package e3_Steque;
/*
 * @author Sai Shashank Gourisetty
 */

import java.util.Iterator;

public class Steque<Item> implements Iterable<Item> {
public class Node
	{
Item item;	
Node next;
Node(Item item)
{
this.item=item;
next=null;
}
}
 Node first,last;
 int T;
public Steque()
{
first=null;
last=null;
T=0;
}
public boolean isEmpty()
{
return T == 0;
}
public int size() 
{
return T;
}
public void push(Item value)
{
if(isEmpty())
last=first=new Node(value);
else
{
Node node=first;
first=new Node(value);
first.next=node;
}
T++;
}
public void enqueue(Item value)
{
if(isEmpty())
last=first=new Node(value);
else
{
last.next=new Node(value);
last=last.next;
}
T++;
}
public Item pop()
{
Item value=null;
value=first.item;
if(size()==1)
first=last=null;
else
first=first.next;
T--;
return value;
}
public void display()
{
Node k=first;
if (k == null)
{
System.out.println("null");
} 
else
{
 while(k!=null)
 {
 System.out.print(k.item);	
 k=k.next;
 }
 System.out.println();
 }
}
@SuppressWarnings("unchecked")
public Iterator iterator()
{
return new StackIterator();
}
private class StackIterator implements Iterator<Object>
{
private Node h=first;
public boolean hasNext()
{
return h!=null;
}
public Item next()
{
Item item=h.item;
h=h.next;
return item;
}
public void remove()
{}
}
}