package e3_Steque;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Scanner;

public class TestSteque {
	@SuppressWarnings({ "resource", "unchecked" })
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		Steque sq=new Steque();
		Scanner sc=new Scanner(System.in);
		System.out.println("Test output produced by Sai Shashank Gourisetty \nGive number of words in the sentence" );
		System.out.println("Test case 5");
		int n=sc.nextInt();
		
		System.out.println("Type sentence:");
		
		for(int i=0;i<n;i++){
			String value=sc.next();
			sq.push(value);
		}
		System.out.println("stack after push is");
		sq.display();
		System.out.println("Stack after enqueue is ");
		sq.enqueue("S");
		sq.display();
		System.out.println("Stack after pop is ");
		sq.pop();
		sq.display();
		
	}


}
