package e1_BinarySearch;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {
//function searches for the index of given number and takes array and key as a input
	public static int indexOf(int[] a,int key)
	{
		int min=0,max=a.length-1;
		while(min<=max)
		{
		int mid = min + (max - min) / 2;
		 if(a[mid]==key)
		 {
			 return mid;
		 }
		 else if(key<a[mid])
		 {
			 max=mid-1;
		 }
		 else if (key > a[mid])
		 {
			 min=mid+1;
		 }
		}
		return -1;
}
	static int rank(int a[],int keynum)
	{//calculates no. of elements smaller than the key 
		int result=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<keynum)
			++result;
		}
		return result;
	}
	static int count(int a[],int keynum)
	{//calculates no. of elements smaller than the key
		int result1=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==keynum)
			++result1;
		}
		return result1;
	}	
	public static void main(String[] args)
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case 5");
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the size of array");
	    int n = input.nextInt();

	    int array[] = new int[n];

	    System.out.println("Enter numbers for array ");

	    for (int i = 0;i < array.length;i++)
	    {
	       array[i] = input.nextInt();
	    }
	    Arrays.sort(array);
	    System.out.println("Sorted array is: "+Arrays.toString(array));//prints sorted array
	    System.out.println("Enter key which is present in array that need to be searched");
	    int key=input.nextInt();
	    
	    int index=indexOf(array,key);
	    int result=rank(array,array[index]);
	    System.out.println("Number of elements that are smaller than the key is " +result);
	    int result1=count(array,array[index]);
	    System.out.println("Number of elements that are equal to key is " +result1);
	    input.close();
	}


}
