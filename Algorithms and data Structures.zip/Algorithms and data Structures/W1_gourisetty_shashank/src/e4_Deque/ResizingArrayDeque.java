package e4_Deque;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Iterator;
import java.util.NoSuchElementException;

public class ResizingArrayDeque<Item> implements Iterable<String> 
{
	Item[] array;
	int N;
	int first;
	int last;
	@SuppressWarnings("unchecked")
	public ResizingArrayDeque()
	{
	array=(Item[])new Object[2];
	N=0;
	first=0;
	last=0;
	}
	public boolean isEmpty()
	{
	return N==0;
	}
	public int size()
	{
	return N;
	}

	public void pushLeft(Item item)
	{
	if(N==array.length)
	resize(2*array.length);
	for(int i=N-1;i>=0;i--)
	array[i+1]=array[i];
	array[0]=item;
	if(last==array.length)
	last=0;
	N++;
	}
@SuppressWarnings("unchecked")
private void resize(int capacity)
	{
	assert capacity>=N;
	Item[] temp=(Item[]) new Object[capacity];
	for(int i=0;i<N;i++)
	temp[i]=array[i];
	array=temp;
	first=0;
	last=N;
	}
	public void pushRight(Item item)
	{
	if(N==array.length)
	resize(2*array.length);
	array[N++]=item;
	if(last==array.length)
	last=0;
	N++;
	}
	public Item popLeft()
	{
	if(isEmpty())
	throw new NoSuchElementException();
	Item item=array[first];
	array[first]=null;
	first++;
	if(first==array.length)
	first=0;
	N--;
	if(N>0&&N==array.length/4)
	resize(array.length/2);
	return item;
	}
	public Item popRight()
	{
	if(isEmpty())
		throw new NoSuchElementException();
	Item item=array[N-1];
	array[N-1]=null;
	if(first==array.length)
	first=0;
	N--;
	if(N>0&&N==array.length/4)
	resize(array.length/2);
	return item;
	}
	@SuppressWarnings("unchecked")
	public Iterator<String> iterator()
	{
	Iterator<String> iterator = (Iterator<String>) new DeqIterator();
	return iterator;
	}
	@SuppressWarnings("rawtypes")
	private class DeqIterator implements Iterator
	{
	private int i=0;
	public boolean hasNext()
	{
	return i<N;
	}
	public Item next()
	{
	if(!hasNext())
	throw new NoSuchElementException();
	Item item=array[(i+first)%array.length];
	i++;
	return item;
	}
	public void remove()
	{
	}
	}
    }
