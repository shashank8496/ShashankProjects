package e4_Deque;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {

	public class Node
	{
	Item item;
	Node next;
	Node prev;
	Node(Item item)
	{
	this.item=item;
	next=null;
	}
	}
	int N;
	Node first;
	Node last;

	public boolean isEmpty()
	{
	return N==0;
	}
	public Deque()
	{
	first=null;
	last=null;
	N=0;
	}
	public Item popLeft()
	{
	if(first == null)
	return null;
	Item value=first.item;
	first=first.next;
	if(first!=null)
	first.prev=null;
	else
	last=null;
	N--;
	return value;
	}
	public void pushLeft(Item value)
	{
	Node prevFirst=first;
	first=new Node(value);
	first.item=value;
	first.prev=null;
	if(prevFirst!=null)
	prevFirst.prev=first;
	if(last==null)
	last=first;
	N++;
	}
	public int size()
	{
	return N;
	}
	public void pushRight(Item value)
	{
	Node prevLast=last;
	last=new Node(value);
	last.item=value;
	last.next=null;
	last.prev=prevLast;
	if(prevLast!=null)
	prevLast.next=last;
	if(first==null)
	first=last;
	N++;
	}
	
	public Item popRight()
	{
	if(last==null)
	return null;
	Item value=last.item;
	last=last.prev;
	if(last!=null)
	last.next=null;
	else
	first=null;
	N++;
	return value;
	}
	@SuppressWarnings("unchecked")
	public Iterator iterator()
	{
	return new DequeIterator();
	}
	@SuppressWarnings("rawtypes")
	private class DequeIterator implements Iterator
	{
	private Node current=first;
	public Item next()
	{
	Item item=current.item;
	current=current.next;
	return item;
	}
	public boolean hasNext()
	{
	return current!=null;
	}
	public void remove() {
	}
	}
}
