package e4_Deque;
import java.util.NoSuchElementException;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Scanner;
public class TestMain{

	@SuppressWarnings("rawtypes")
	public static void main(String[] args)
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case 5");
	Deque deq =new Deque();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number of elements");
	int l=sc.nextInt();
	ResizingArrayDeque deq1=new ResizingArrayDeque();
	System.out.println("Enter sentence ");
	for(int i=0;i<l;i++)
	{
	String value=sc.next();
	deq.pushLeft(value);
	deq1.pushLeft(value);
	}
	try{
	System.out.println("linked list Deque");
	System.out.println("Given Steque ");
	printDeque(deq);
	System.out.println("Steque after push Right");
	deq.pushRight("pushRight");
	printDeque(deq);
	System.out.println("Steque after pop left");
	deq.popLeft();
	printDeque(deq);
	System.out.println("Steque after popRight:");
	deq.popRight();
	printDeque(deq);
	System.out.println("Deque implementation using resizable array \nGiven resizable array ");
	printArr(deq1);
	System.out.println("Deque resizable array after pushRight");
	deq.pushRight("pushRight");
	printArr(deq1);
	System.out.println("Deque resizable array after popRight");
	deq1.popRight();
	printArr(deq1);
	System.out.println("Deque resizable array after popLeft");
	deq1.popLeft();
	
	printArr(deq1);

	}catch (NoSuchElementException e)
	{
		System.out.println("No more elements");
	}
	}
	public static void printDeque(Deque<String> dq)
	{
	for(String element : dq)
	{
	System.out.print(element + "");
	}

	System.out.println("\nsize: " +dq.size());
	}
	public static void printArr(ResizingArrayDeque<String> dequeArr)
	{
	for(String element : dequeArr)
	{
	if(element != null)
	System.out.print(element+ "");
	}
	System.out.println("\nsize:" +dequeArr.size());
	}

}
