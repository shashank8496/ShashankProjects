package e2_RobustRational;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Scanner;

public class Rational {
	long num;
	long den;
	public Rational (long n,long d)	//Textbook as a reference
	{
		if (d==0)
			throw new RuntimeException("The denominator is ZERO");

		assert n<Long.MAX_VALUE&&n>
		Long.MIN_VALUE : "OVERFLOW IN THE NUMERATOR";
		assert d<Long.MAX_VALUE&&n
		>
		Long.MIN_VALUE : "OVERFLOW IN THE DENOMINATOR";		
			long p=gcd(n,d);
			num=n/p;
			den=d/p;
	}

	private long gcd(long x,long y)
	{
		if(y==0)
			return x;
		long p=x%y;
		return gcd(y,p);
	}
	public Rational addition(Rational y)//performs addition of fractions
	{
	long f=this.den*y.den;
	long e=this.num*y.den+this.den*y.num;
	return new Rational(e,f);
	}
	public Rational multiplication(Rational y)//performs multiplication of fractions
	{

		long f=this.den*y.den;
		long e=this.num*y.num;
	return new Rational(e,f);
	}
	public Rational minus(Rational y)//performs minus of fractions
	{
	long f=this.den*y.den;
	long e=this.num*y.den-this.den*y.num;
	return new Rational(e,f);
	}
	public Rational division(Rational y)//performs division of fractions
	{
	long e=this.num*y.den;
	long f=this.den*y.num;
	return new Rational(e,f);
	}
	public boolean equals(Object y)//checks for equal fraction
	{

		if(this.getClass()!=y.getClass())
			return false;
		Rational that=(Rational) y;
		return this.num==that.num&&this.den==that.den;
			
	}
	public String toString()
	{
		return num + "/" +den;
		}
public static void main(String args[]) {
			System.out.println("Test output produced by Sai Shashank Gourisetty");
			@SuppressWarnings("resource")
			Scanner input=new Scanner(System.in);
			System.out.println("Test case 3");
			System.out.println("Operations on rational number " +"\n"+"Enter any four numbers");

			long n1=input.nextLong();
			long d1=input.nextLong();
			long n2=input.nextLong();
			long d2=input.nextLong();
			Rational rn1=new Rational(n1,d1);
			Rational rn2=new Rational(n2,d2);
			System.out.println("Rational number 1:" +rn1);
			System.out.println("Rational number 2:" +rn2);
			System.out.println("equal of two rational is " +rn1.equals(rn2));
			System.out.println("sum of two rational is " +rn1.addition(rn2));
			System.out.println("quotient of two rational is " +rn1.division(rn2));
			System.out.println("product of two rational is " +rn1.multiplication(rn2));
			System.out.println("difference of two rational is " +rn1.minus(rn2));
		}
}
