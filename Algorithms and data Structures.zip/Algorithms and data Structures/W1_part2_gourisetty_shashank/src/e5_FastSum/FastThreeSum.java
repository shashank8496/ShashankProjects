package e5_FastSum;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
import java.util.Scanner;
import edu.princeton.cs.algs4.StdRandom;

public class FastThreeSum {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case 1 \nenter the size of the Array");
		int N=sc.nextInt();
		int[] array=new int[N];
		for(int i=0;i<N;i++)
			array[i]=StdRandom.uniform(2*N)-N;//generate random array
		System.out.println("Generated array elements are :"+Arrays.toString(array));
		Arrays.sort(array);		//sort array
		int i=0;
		int j=array.length-1;
		int count=0;
		while(i<j)
		{
			if(array[i]<0 && array[j]<0 || array[i]>0&&array[j]>0)			//check if array has same number with opposite sign
				break;
			if(array[i]+array[j]==0)
			{
				count++;
				i++;
				j--;
			}
			else if(Math.abs(array[i])>Math.abs(array[j]))
					i++;
			else if(Math.abs(array[i])<Math.abs(array[j]))
				j--;
		}
		System.out.println("\nNumber of pairs that sum to zero:" +count);
		}
}
