package e1_ModifiedThreeSum;

/*
 * @author Sai Shashank Gourisetty
 */

import java.math.BigInteger;
import java.util.Scanner;

public class ModifiedThreeSum {
	public static int countthreesum(int[] a) 
{
    int a_size = a.length;
    int count = 0;
    for (int i = 0; i < a_size-2; i++)     {//if conditions checks for sum equal to zero
        for (int j = i+1; j < a_size-1; j++)        {
            for (int k = j+1; k < a_size; k++)            {
            	BigInteger sum=BigInteger.valueOf(0);
            	sum=sum.add(BigInteger.valueOf(a[i]));
            	sum=sum.add(BigInteger.valueOf(a[j]));
            	sum=sum.add(BigInteger.valueOf(a[k]));
            	
                    if (sum == BigInteger.valueOf(0)) 
                    {
                    	count++;
                    }        }       }    }
    return count;
}
	
public static void main(String[] args)  
{ 
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Test case 5");
	Scanner input=new Scanner(System.in);
	System.out.println("Enter array size");
	int size = input.nextInt();
int array[] = new int[size];
System.out.println("Enter numbers ");
for (int i = 0 ; i < array.length; i++ )
{
   array[i] = input.nextInt();//stores integers into an array
}
input.close();
System.out.println("Number of three sum sets are ");
System.out.println(countthreesum(array));//function call to countthreesum array as a parameter
} 
 }
