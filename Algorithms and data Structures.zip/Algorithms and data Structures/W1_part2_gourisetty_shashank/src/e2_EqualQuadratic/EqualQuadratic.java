package e2_EqualQuadratic;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
import java.util.Scanner;

public class EqualQuadratic {

	public static int[] count(int[] a)
	{int end = a.length;

    for (int i = 0; i < end; i++) {//removes duplicates in array
        for (int j = i + 1; j < end; j++) {
            if (a[i] == a[j]) {                  
                a[j] = a[end-1];
                end--;
                j--;
            }
        }
    }

    int[] list = new int[end];
    int fact=1;
    System.arraycopy(a, 0, list, 0, end);
    fact=end*(end-1);
    System.out.println("number of distinctive pairs are "+fact);
    return list;
}
public static void main(String args[])
{
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Test case 5");
	
	Scanner input=new Scanner(System.in);
	System.out.println("enter the size of the array");
    int num = input.nextInt();

    int array[] = new int[num];

    System.out.println("Enter the digits");

    for (int i = 0 ; i < array.length; i++ )
    {
       array[i] = input.nextInt();
    }
    Arrays.sort(array);
  input.close();
  count(array);
}
}
