package e3_ModifiedBinary;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
import java.util.Scanner;
public class ModifiedBinarySearch {

			public static int indexOf(int[] a,int key)//function calculates position of key number by taking array and key as a input parameters
			{
				int min=0,max=a.length-1;
				while(min<=max)
				{
				int mid = min + (max - min) / 2;
				 if(a[mid]==key)
				 {
					 if(key==a[mid-1])
				 {
					 max=mid-1;
				 }else
					 return mid;
					 
				 }
				 else if(key<a[mid])
				 {
					 max=mid-1;
				 }
				 else if (key > a[mid])
				 {
					 min=mid+1;
				 }
				}
				
				return -1;
				}
			public static void main(String[] args)
			{
				System.out.println("Test output produced by Sai Shashank Gourisetty");
				System.out.println("Test case 2");
				Scanner input=new Scanner(System.in);
				System.out.println("Enter the size of array");
			    int n = input.nextInt();

			    int array[] = new int[n];

			    System.out.println("Enter numbers for array ");

			    for (int i = 0;i < array.length;i++)
			    {
			       array[i] = input.nextInt();
			    }
			    Arrays.sort(array);//sorts the array
			    System.out.println("Sorted array is: "+Arrays.toString(array));
			    System.out.println("Enter key to be searched");
			    int key=input.nextInt();
			    
			    int index=indexOf(array,key);
			    if(index >-1)
			    System.out.println("The key element: "+key+" is found at index " +index);
			    else
			    System.out.println("The key element not found");
			    input.close();
			}

	}