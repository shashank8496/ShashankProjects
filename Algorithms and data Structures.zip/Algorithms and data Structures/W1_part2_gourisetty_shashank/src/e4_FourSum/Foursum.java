package e4_FourSum;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Scanner;

public class Foursum {
	static void Foursum(int a[]) 
	{ int count=0;
	int a_size=a.length;
	for (int l = 0; l < a_size - 3; l++) {//if conditions checks for sum equal to zero
	for (int i = l+1; i < a_size - 2; i++) { 
	for (int j = i + 1; j < a_size - 1; j++) { 
	for (int k = j + 1; k < a_size; k++) { 
	if (a[i] + a[j] + a[k]+a[l] == 0) { 
	System.out.print("Quads are " + a[i] + ", " + a[j] + ", " + a[k]+ ", " +a[l] +"\n");  
	++count;
	}	}	}	}  }
	if(count==0)
	{System.out.print("No numbers in the array form foursum");}
	}
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case 5");
		Scanner input=new Scanner(System.in);
		System.out.println("enter the size of the array");
	    int num = input.nextInt();
	    int array1[] = new int[num];
	    System.out.println("Enter the digits");

	    for (int i = 0 ; i < array1.length; i++ )
	    {
	       array1[i] = input.nextInt();//takes integer numbers as a input to array
	    }
	    input.close();
	    Foursum(array1);
     
}
}
