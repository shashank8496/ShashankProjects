package e3_Binarysearch;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.NoSuchElementException;
import edu.princeton.cs.algs4.Queue;
import java.util.Scanner;
public class BinarySearch<Key extends Comparable<Key>, Value>  {

	private static final int INIT_CAPACITY = 2;
    private Key[] keys;
    private Value[] vals;
	private static char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
    private int n = 0;

    public BinarySearch() {
        this(INIT_CAPACITY);
    }

    public BinarySearch(int capacity) { 
        keys = (Key[]) new Comparable[capacity]; 
        vals = (Value[]) new Object[capacity]; 
    }   

        public int size() {
    	//size of array
        return n;
    }
    public boolean isEmpty() {
        return size() == 0;//checks array is empty or not
    }
    private void resize(int capacity) {	// resize the arrays
        assert capacity >= n;
        Key[]   k = (Key[])   new Comparable[capacity];
        Value[] v = (Value[]) new Object[capacity];
        for (int i = 0; i < n; i++) {
            k[i] = keys[i];
            v[i] = vals[i];
        }
        vals = v;
        keys = k;
    }
	//taking the elements in to the array
    public void put(Key key, Value val)  {
        if (key == null) throw new IllegalArgumentException("null argument to put"); 
        if (val == null) {
            delete(key);
            return;
        }
        int r = rank(key);
        if (r < n && keys[r].compareTo(key) == 0) {
            vals[r] = val;
            return;
        }
        if (n == keys.length) resize(2*keys.length);
        for (int j = n; j > r; j--)  {
            keys[j] = keys[j-1];
            vals[j] = vals[j-1];
        }
        keys[r] = key;
        vals[r] = val;
        n++;

        assert check();
    } 
    public boolean contains(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to contains");
        return get(key) != null;
    }

    public int rank(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to rank"); 
        int low = 0, high = n-1; 
        while (low <= high) { 
            int mid = low + (high - low) / 2; 
            int cmp = key.compareTo(keys[mid]);
            if      (cmp < 0) 
				high = mid - 1; 
            else if (cmp > 0)
				low = mid + 1; 
            else return mid; 
        } 
        return low;
    }
    public Value get(Key key) {
        if (key == null) throw new IllegalArgumentException(" null argument to get"); 
        if (isEmpty()) 
			return null;
        int i = rank(key); 
        if (i < n && keys[i].compareTo(key) == 0) return vals[i];
        return null;
    } 	


    public void delete(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to delete"); 
        if (isEmpty()) return;
        int i = rank(key);
        if (i == n || keys[i].compareTo(key) != 0) {
            return;
        }

        for (int j = i; j < n-1; j++)  {
            keys[j] = keys[j+1];
            vals[j] = vals[j+1];
        }

        n--;
        keys[n] = null;
        vals[n] = null;

       
        if (n > 0 && n == keys.length/4) resize(keys.length/2);

        assert check();
    } 

    public void deleteMin() {
        if (isEmpty()) throw new NoSuchElementException("ST min error");
        delete(min());
    }

    public void deleteMax() {
        if (isEmpty()) throw new NoSuchElementException("ST max error");
        delete(max());
    }

    public Key min() {
        if (isEmpty()) throw new NoSuchElementException("min() invoked with empty ST");
        return keys[0]; 
    }

    public Key max() {
        if (isEmpty()) throw new NoSuchElementException("max() invoked with empty ST");
        return keys[n-1];
    }

 
    public Key select(int k) {
        if (k < 0 || k >= size()) {
            throw new IllegalArgumentException("Invalid argument for select: " + k);
        }
        return keys[k];
    }

   
    public Key floor(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to floor()"); 
        int i = rank(key);
        if (i < n && key.compareTo(keys[i]) == 0) return keys[i];
        if (i == 0) return null;
        else return keys[i-1];
    }


    public Key ceiling(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to ceiling()"); 
        int i = rank(key);
        if (i == n) return null; 
        else return keys[i];
    }

    
    public int size(Key low, Key high) {
        if (low == null) throw new IllegalArgumentException("first argument in size() is null"); 
        if (high == null) throw new IllegalArgumentException("second argument in size() is null"); 

        if (low.compareTo(high) > 0) return 0;
        if (contains(high)) return rank(high) - rank(low) + 1;
        else              return rank(high) - rank(low);
    }

    public Iterable<Key> keys() {
        return keys(min(), max());
    }

 
    public Iterable<Key> keys(Key low, Key high) {
        if (low == null) throw new IllegalArgumentException("first argument in keys() is null"); 
        if (high == null) throw new IllegalArgumentException("second argument in keys() is null"); 

        Queue<Key> queue = new Queue<Key>(); 
        if (low.compareTo(high) > 0) return queue;
        for (int i = rank(low); i < rank(high); i++) 
            queue.enqueue(keys[i]);
        if (contains(high)) queue.enqueue(keys[rank(high)]);
        return queue; 
    }

    private boolean check() {
        return isSorted() && rankCheck();
    }

    private boolean isSorted() {
        for (int i = 1; i < size(); i++)
            if (keys[i].compareTo(keys[i-1]) < 0) return false;
        return true;
    }

    private boolean rankCheck() {
        for (int i = 0; i < size(); i++)
            if (i != rank(select(i))) return false;
        for (int i = 0; i < size(); i++)
            if (keys[i].compareTo(select(rank(keys[i]))) != 0) return false;
        return true;
    }

    public static void main(String[] args) { 
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
    	System.out.println("Test case 5");
    	System.out.print("\nEnter string of 10 that should be checked:");
    	Scanner sc=new Scanner(System.in);
        BinarySearch<String, Integer> ST = new BinarySearch<String, Integer>();

        for (int i = 0; i<=9; i++) {        //enter string of length 10
            String key = sc.next();
            ST.put(key, i);
        }
        
        for (char letter : alphabet)
        {
        	String x = ""+letter+"";
        	
if(ST.get(x) != null)
        		System.out.println(x.toUpperCase() + " Letter Number: " + (ST.get(x).intValue()+1));
        	else if(ST.get(x.toUpperCase()) != null)
        		System.out.println(x.toUpperCase() + " Letter Number: " + (ST.get(x.toUpperCase()).intValue()+1));
        	else
        		System.out.println(x.toUpperCase() + " " + "not found");
        }   
    }
}