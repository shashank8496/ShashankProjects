package e4_binarysearchsymboltable;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.NoSuchElementException;
import java.util.Scanner;
import edu.princeton.cs.algs4.Queue;

public class BinarySearchSymbolTable<Key extends Comparable<Key>, Value> 
{
	private static final int INIT_CAPACITY = 2;
//giving the alphabets
    private static char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
    private Key[] keys;
    private Value[] vals;
    private int n = 0;

    public BinarySearchSymbolTable() {
        this(INIT_CAPACITY);
    }

    public BinarySearchSymbolTable(int capacity) { 
        keys = (Key[]) new Comparable[capacity]; 
        vals = (Value[]) new Object[capacity]; 
    }   

    // resize the underlying arrays
    private void resize(int capacity) {
        assert capacity >= n;
        Key[]   tempk = (Key[])   new Comparable[capacity];
        Value[] tempv = (Value[]) new Object[capacity];
        for (int i = 0; i < n; i++) {
            tempk[i] = keys[i];
            tempv[i] = vals[i];
        }
        vals = tempv;
        keys = tempk;
    }

    public int size() {
        //size of array 
    	return n;
    }

    public boolean isEmpty() {
    	//is array empty?
        return size() == 0;
    }

    public boolean contains(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to contains()");
        return get(key) != null;
    }

    public Value get(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to get()"); 
        if (isEmpty()) return null;
        int i = rank(key); 
        if (i < n && keys[i].compareTo(key) == 0) return vals[i];
        return null;
    } 

    public int rank(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to rank()"); 

        int lo = 0, hi = n-1; 
        while (lo <= hi) { 
            int mid = lo + (hi - lo) / 2; 
            int cmp = key.compareTo(keys[mid]);
            if      (cmp < 0) hi = mid - 1; 
            else if (cmp > 0) lo = mid + 1; 
            else return mid; 
        } 
        return lo;
    } 

    public void put(Key key, Value val)  {
        if (key == null) throw new IllegalArgumentException("first argument to put() is null"); 

        if (val == null) {
            delete(key);
            return;
        }

        int i = rank(key);

        if (i < n && keys[i].compareTo(key) == 0) {
            vals[i] = val;
            return;
        }

        if (n == keys.length) resize(2*keys.length);

        for (int j = n; j > i; j--)  {
            keys[j] = keys[j-1];
            vals[j] = vals[j-1];
        }
        keys[i] = key;
        vals[i] = val;
        n++;

        assert check();
    } 

    public void delete(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to delete()"); 
        if (isEmpty()) return;

        int i = rank(key);

        if (i == n || keys[i].compareTo(key) != 0) {
            return;
        }

        for (int j = i; j < n-1; j++)  {
            keys[j] = keys[j+1];
            vals[j] = vals[j+1];
        }

        n--;
        keys[n] = null;  
        vals[n] = null;

        if (n > 0 && n == keys.length/4) resize(keys.length/2);

        assert check();
    } 
// specifying condition to throw n exception
    public void deleteMin() {
        if (isEmpty()) throw new NoSuchElementException("ST underflow error");
        delete(min());
    }

    public void deleteMax() {
        if (isEmpty()) throw new NoSuchElementException("ST underflow error");
        delete(max());
    }

    public Key select(int k) {
        if (k < 0 || k >= size()) {
            throw new IllegalArgumentException("invalid argument to select() " + k);
        }
        return keys[k];
    }
    public Key min() {
        if (isEmpty()) throw new NoSuchElementException("invoked min() with empty ST");
        return keys[0]; 
    }

    public Key max() {
        if (isEmpty()) throw new NoSuchElementException("invoked max() with empty ST");
        return keys[n-1];
    }

  
    public Key floor(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to floor()"); 
        int i = rank(key);
        if (i < n && key.compareTo(keys[i]) == 0) return keys[i];
        if (i == 0) return null;
        else return keys[i-1];
    }


    public Key ceiling(Key key) {
        if (key == null) throw new IllegalArgumentException("null argument to ceiling()"); 
        int i = rank(key);
        if (i == n) return null; 
        else return keys[i];
    }

    public Iterable<Key> keys() {
        return keys(min(), max());
    }
 
    public int size(Key lo, Key hi) {
        if (lo == null) throw new IllegalArgumentException("first argument to size() is null"); 
        if (hi == null) throw new IllegalArgumentException("second argument to size() is null"); 

        if (lo.compareTo(hi) > 0) return 0;
        if (contains(hi)) return rank(hi) - rank(lo) + 1;
        else              return rank(hi) - rank(lo);
    }

    private boolean isSorted() {
    	// checking whether sorted or not
        for (int i = 1; i < size(); i++)
            if (keys[i].compareTo(keys[i-1]) < 0) return false;
        return true;
    }
    public Iterable<Key> keys(Key lo, Key hi) {
        if (lo == null) throw new IllegalArgumentException("first argument to keys() is null"); 
        if (hi == null) throw new IllegalArgumentException("second argument to keys() is null"); 

        Queue<Key> queue = new Queue<Key>(); 
        if (lo.compareTo(hi) > 0) return queue;
        for (int i = rank(lo); i < rank(hi); i++) 
            queue.enqueue(keys[i]);
        if (contains(hi)) queue.enqueue(keys[rank(hi)]);
        return queue; 
    }

    private boolean check() {
        return isSorted() && rankCheck();
    }
    private boolean rankCheck() {
        for (int i = 0; i < size(); i++)
            if (i != rank(select(i))) return false;
        for (int i = 0; i < size(); i++)
            if (keys[i].compareTo(select(rank(keys[i]))) != 0) return false;
        return true;
    }
public static void main(String[] args) 
{
	BinarySearchSymbolTable<String, Double> grades = new BinarySearchSymbolTable<String, Double>();
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Test case 1");
    System.out.println("Enter four Grades");
    grades.put("A",  4.00);
    grades.put("A+", 4.33);
    grades.put("A-", 3.67);
    grades.put("B+", 3.33);
    grades.put("B",  3.00);
    grades.put("B-", 2.67);
    grades.put("C-", 1.67);
    grades.put("C",  2.00);
    grades.put("C+", 2.33);
    grades.put("D",  1.00);
    grades.put("F",  0.00);
        
    Scanner sc=new Scanner(System.in);
    int n = 0;
    double total = 0.0;
    for (n = 0;n<=3; n++) {
    	// enter four grades 
        String grade = sc.next();
        double value = grades.get(grade);
        total += value;
    } 
    double gpa = total / n;
    System.out.println("GPA = " + gpa);
}
}