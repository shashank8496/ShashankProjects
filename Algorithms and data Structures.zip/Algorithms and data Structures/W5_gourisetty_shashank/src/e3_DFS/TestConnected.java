package e3_DFS;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;
public class TestConnected {
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("tinyG.txt"));//input file name
		G.detailedPrint();
		DepthFirstSearch search = new DepthFirstSearch(G, 0);
		if(search.isConnected())
			System.out.println("Connected");
		else
			System.out.println("Not Connected");
	}
}