package e5_DFS;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;
public class TestGraph {
	public static void main(String[] args) 
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("largeG.txt"));//input file name
		Graph H = new Graph(G);
		H.detailedPrint();
		G.addEdge(1, 2);
		H.detailedPrint();
		System.out.println("Graph G change is not affect to Graph H");
	}
}