package e5_DFS;
/*
 * @author Sai Shashank Gourisetty
 */
public class TestGraphOperations {

	public static int degree(Graph G, int v)
	{
		int degree = 0;
		for (int w : G.adj(v)) degree++;
		return degree;
	}
	
	public static int maxDegree(Graph G)//calculates max degree
	{
		int max = 0;
		for(int v = 0; v < G.V(); v++)
			if(degree(G, v) > max)
				max = degree(G, v);
		return max;
	}
	
	public static int avgDegree(Graph G)
	{
		return 2 * G.E() / G.V();
	}
	public static int minDegree(Graph G)//calculates min degree
	{
		int min = G.V();
		for(int v = 0; v < G.V(); v++)
			if(degree(G, v) < min)
				min = degree(G, v);
		return min;
	}
	public static int numberOfSelfLoops(Graph G)
	{
		int count = 0;
		for (int v = 0; v < G.V(); v++)
			for(int w : G.adj(v))
				if(v == w) count++;
		return count/2;
	}

	public static void deleteEdge(Graph G, int v, int w)//deletes edge
	{
		G.adj[v].remove(w);
		G.adj[w].remove(v);
	}
	
	public static void addVertex(Graph G)
	{
		G.addVertex();
	}
	public static boolean hasEdge(Graph G, int v, int w)
	{
		for(int t: G.adj(v))
			if(t == w)
				return true;
		return false;
	}
	public static void deleteVertex(Graph G)//deletes vertex
	{
		G.deleteVertex();
	}
}