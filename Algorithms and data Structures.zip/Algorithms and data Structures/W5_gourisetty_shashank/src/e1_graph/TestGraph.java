package e1_graph;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;

public class TestGraph {
	public static void main(String[] args) 
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("largeG.txt"));
		G.detailedPrint();
	}
}
