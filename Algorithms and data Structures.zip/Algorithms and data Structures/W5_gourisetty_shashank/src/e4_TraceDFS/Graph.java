package e4_TraceDFS;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.*;
public class Graph {

	private int V;
    private int E;
    public Bag<Integer>[] adj;
    
    @SuppressWarnings("unchecked")
	public Graph(int V) {
        this.V = V;
        this.E = 0;
        adj = (Bag<Integer>[]) new Bag[V];
        for (int v = 0; v < V; v++) {
            adj[v] = new Bag<Integer>();
        }
    }

    public void addVertex()
    {
    	@SuppressWarnings("unchecked")
		Bag<Integer>[] items = (Bag<Integer>[])new Bag[V+1];
		for (int i = 0; i < V; i++) {
			items[i] = adj[i];
		}
		items[V] = new Bag<Integer>();
		V = V + 1;
		adj = items;
    }
    
    public void deleteVertex()
    {
    	V--;
    }
    
    @SuppressWarnings("unchecked")
	public Graph(In in) {
        this.V = in.readInt();
        boolean big_flag = false;
        int tempv = 500, tempe = 6000;
        if(V > 3000)
        {
        	big_flag = true;
        }
        int E = in.readInt();
        if(big_flag == true)
        {
            adj = (Bag<Integer>[]) new Bag[tempv];
        	for (int v = 0; v < tempv; v++) {
                adj[v] = new Bag<Integer>();
            }
            if(E < 6000)
            	tempe = E;
            for (int i = 0; i < tempe; i++) {
                int v = in.readInt();
                int w = in.readInt();
               	addEdge(v%tempv, w%tempv);
            }
            this.E = E;
        }
        else
        {
            adj = (Bag<Integer>[]) new Bag[V];
        	for (int v = 0; v < V; v++) {
                adj[v] = new Bag<Integer>();
            }
            for (int i = 0; i < E; i++) {
                int v = in.readInt();
                int w = in.readInt();
                addEdge(v, w); 
            }
        }
    }

    public Graph(Graph G) {
        this(G.V());
        this.E = G.E();
        for (int v = 0; v < G.V(); v++) {
            Stack<Integer> save_r = new Stack<Integer>();
            for (int w : G.adj[v]) {
            	save_r.push(w);
            }
            for (int w : save_r) {
                adj[v].add(w);
            }
        }
    }

    public int V() {
        return V;
    }
    public void addEdge(int v, int w) {
        E++;
        adj[v].add(w);
        adj[w].add(v);
    }
    public int E() {
        return E;
    }

    public Iterable<Integer> adj(int v) {
        return adj[v];
    }

    public int degree(int v) {//returns degree
        return adj[v].size();
    }

    public void detailedPrint()
    {
    	StringBuilder s = new StringBuilder();
        s.append("Number of vertices : " + V + "\nNumber of edges : " + E + "\n");
        int displayV = V;
        if(V > 500)
        	displayV = 500;
        for (int v = 0; v < displayV; v++) {
            s.append("adj[" + v + "] = (");
            int size_t = adj[v].size();
            if(adj[v] != null)
            {
	            for (int w : adj[v]) {
	        		s.append(w);
	            	if(size_t != 1)
	            		s.append(",");
	            	size_t --;
	            }
            }
            s.append(")\n");
        }
        System.out.println(s.toString());
    }
}