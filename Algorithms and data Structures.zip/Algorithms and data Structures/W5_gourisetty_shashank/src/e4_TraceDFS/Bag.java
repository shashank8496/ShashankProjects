package e4_TraceDFS;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Iterator;
public class Bag<Item> implements Iterable<Item>  
{
	private Item[] contents;  
	private int N;
	@SuppressWarnings("unchecked")
	public Bag() {// creates a new empty Bag.
		contents = (Item[]) new Object[1];
		N = 0;
	}
	
	public boolean isEmpty() {
		return N == 0;
	}
	
	public void add(Item item) {
		if (item == null)
			throw new NullPointerException("Null insertion");
		if (N == contents.length) 
			resize(contents.length * 2);
		contents[N++] = item;
	}
	
	public void remove(Item item) {
		int j = 0;
		for(int i = 0; i < N; i++)
		{
			if(item.equals(contents[i]))
			{}
			else
			{
				contents[j] = contents[i];
				j ++ ;
			}
		}
		N = j;
	}
	public int size() {
		return N;
	}

	public Iterator<Item> iterator() {
		return new BagIterator();
	}
	
	private void resize(int size) {
		@SuppressWarnings("unchecked")
		Item[] items = (Item[]) new Object[size];
		for (int i = 0; i < N; i++) {
			items[i] = contents[i];
		}
		contents = items;
	}
	
	private class BagIterator implements Iterator<Item> {
		private int current;
		public BagIterator() {
			current = 0;
		}
		public Item next() {
			return contents[current++]; 
		}
		
		public boolean hasNext() {
			return current != N;
		}
		public void remove() {
			throw new UnsupportedOperationException("Invalid Operation");
		}	
	}
}