package e6_modifiedDFS;
/*
 * @author Sai Shashank Gourisetty
 */
public class DepthFirstSearch {
	private boolean[] marked;
	private int count;
	
	public DepthFirstSearch(Graph G)
	{
		marked = new boolean[G.V()];
	}
	
	private void dfs(Graph G, int v, int height)
	{
		marked[v] = true;
		count++;
		for(int i = 0; i < height; i++)
			System.out.print("   ");
		System.out.print("dfs(" + v + ")");
		displayMark();
		for(int w : G.adj(v))
		{
			if(!marked[w]) dfs(G, w, height+1);
		}
	}
	
	public boolean marked(int w)
	{
		return marked[w];
	}
	public int count()
	{
		return count;
	}
	
	public void displayMark()
	{
		System.out.print(" marked = [");
		for(int i = 0; i < marked.length - 1; i ++)
		{
			if(marked[i] == true)
				System.out.print("T,");
			else
				System.out.print("F,");
		}
		if(marked[marked.length - 1] == true)
			System.out.print("T");
		else
			System.out.print("F");
		System.out.print("]\n");
	}
	
	public void isConnected(Graph G, int s)//checks connected or not
	{
		System.out.print("isConnected()");
		displayMark();
		dfs(G, s, 0);
	}
}