package e6_modifiedDFS;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;
public class TestGraph {
		public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("mediumG.txt"));//input file name
		G.detailedPrint();
		System.out.println("Add Edge 1-3 4 times and Self Loop 1 2 times\n");
		G.addEdge(1, 3);
		G.addEdge(1, 3);
		G.addEdge(1, 3);
		G.addEdge(1, 3);
		G.addEdge(1, 1);
		G.addEdge(1, 1);
		G.detailedPrint();
		System.out.println("Parallel Edge and Self-Loop is Disallowed");
	}
}
