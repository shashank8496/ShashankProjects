package e2_GraphProcessing;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;

public class TestGraph1 {
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("tinyG.txt"));
		
		if(G.V() < 20)
			G.detailedPrint();
		System.out.println("The Degree of Vertex 0 is " + TestGraphOperations.degree(G, 0));
		System.out.println("The Maximum Degree is " + TestGraphOperations.maxDegree(G));
		System.out.println("The Minimum Degree is " + TestGraphOperations.minDegree(G));
		System.out.println("The Average Degree is " + TestGraphOperations.avgDegree(G));
		System.out.println("The Self Loop Count is " + TestGraphOperations.numberOfSelfLoops(G));
		
		TestGraphOperations.addVertex(G);
		System.out.println("Graph Added Vertex " + (G.V() - 1));
		
		if(G.V() < 30)
			G.detailedPrint();
		System.out.println("Graph Delete Vertex " + (G.V() - 1));//print values
		TestGraphOperations.deleteVertex(G);
		TestGraphOperations.deleteEdge(G, 0, 2);
		System.out.println("Graph Deleted Edge 0-2");
		System.out.println("Graph Contain Edge 0-3 : " + TestGraphOperations.hasEdge(G, 0, 3));
		
		if(G.V() < 20)
			G.detailedPrint();
	}
}