package e2_GraphProcessing;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;

public class TestGraph {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Graph G = new Graph(new In("mediumG.txt"));//input file name
		
		if(G.V() < 20)
			G.detailedPrint();
		
		for(int i = 0; i < 10; i++)
		{
			System.out.println("Graph Added Vertex " + G.V());
			TestGraphOperations.addVertex(G);
		}
		
		if(G.V() < 30)
			G.detailedPrint();
		for(int i = 0; i < 10; i++)
		{
			TestGraphOperations.deleteVertex(G);
			System.out.println("Graph Delete Vertex " + G.V());
		}
		
		if(G.V() < 20)
			G.detailedPrint();
		
		int add_v[] = {1,2,3,4,5,6,7,8,9,0};
		int add_w[] = {3,1,4,6,3,3,2,4,8,3};
		for(int i = 0; i < 10; i++)
		{
			System.out.println("Edge " + add_v[i] + "-" + add_w[i] + " added");
			G.addEdge(add_v[i], add_w[i]);
		}
		G.detailedPrint();
		for(int i = 0; i < 10; i++)
		{
			System.out.println("Edge " + add_v[i] + "-" + add_w[i] + " deleted");
			TestGraphOperations.deleteEdge(G, add_v[i], add_w[i]);
		}
		G.detailedPrint();
	}
}