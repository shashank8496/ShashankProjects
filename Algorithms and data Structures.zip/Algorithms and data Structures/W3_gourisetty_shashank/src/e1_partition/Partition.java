package e1_partition;
/*
 * @author Sai Shashank Gourisetty
 */
public class Partition {

	@SuppressWarnings("rawtypes")
	public static int Partition(Comparable[] a, int low, int high) {
        int i = low;
        int j = high + 1;
        Comparable v = a[low];
        while (true) 
        { 
            while (less(a[++i], v)) 
            {
                if (i == high)
                	break;
            }
            while (less(v, a[--j])) {
                if (j == low) 
                	break;
            }
            if (i >= j)// pointers meet or cross 
            	break;
            exchange(a, i, j);//swapping
        }
        exchange(a, low, j);//swapping
        return j;
    }
    private static boolean isSorted(Comparable[] a, int low, int high) {
        for (int i = low + 1; i <= high; i++)
            if (less(a[i], a[i-1])) return false;
        return true;
    }

	private static boolean less(Comparable u, Comparable v) {
	        if (u == v) 
	        	return false;
	        return u.compareTo(v) < 0;
	    }
	        
	    // swapping elements
	    private static void exchange(Object[] a, int i, int j) {
	        Object swap = a[i];
	        a[i] = a[j];
	        a[j] = swap;
	    }
	    // display array
	    private static void display(Comparable[] array) 
	    {
	        for (int i = 0; i < array.length; i++)
	            System.out.print(array[i]+" ");
	    }

	    public static void main(String[] args) {
	        String[] array = {"S","H","A","S","H","A","N","K","G","O","U","R","I","S","E","T","T","Y"};
	        System.out.println("Test output produced by Sai Shashank Gourisetty");
	        System.out.println("Before partition");
	        display(array);
	        Partition(array,0,17);
	        System.out.println("\nAfter partition");
	        display(array);
	        assert isSorted(array, 0, array.length - 1);
}
}