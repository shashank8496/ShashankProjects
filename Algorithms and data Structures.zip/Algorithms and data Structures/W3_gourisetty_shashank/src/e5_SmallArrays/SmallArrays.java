package e5_SmallArrays;
import java.util.Arrays;
import edu.princeton.cs.algs4.Quick;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.Stopwatch;
/*
 * @author Sai Shashank Gourisetty
 */
public class SmallArrays {
	public static void sort(Comparable[] a,int cutoff)
	{
		sort(a,cutoff,0,a.length-1);
		insertionSort(a,0,a.length-1);
	}
	private static double times(String type, Double[] array2, int cutoff) 
	{
		Stopwatch timer=new Stopwatch();
		if(type.equals("Quick"))
		Quick.sort(array2);
		else if(type.equals("Modifiedquick"))
			sort(array2,cutoff);
		return timer.elapsedTime();
	}

private static void insertionSort(Comparable[] array,int low,int high)
{
	for(int i=low;i<=high;i++)
	{
		for(int j=i;j>low&&less(array[j],array[j-1]);j--)
		{
			exchange(array,j,j-1);
		}
	}
}
private static void sort(Comparable[] a,int cutoff,int low,int high)
{
	if(high<=low)
		return;
	int N=high-low+1;
	if(N<=cutoff)
		return;
	else
	{
		int j=partition(a,low,high);
		sort(a,cutoff,low,j-1);
		sort(a,cutoff,j+1,high);
		assert isSorted(a,low,high);
	}
}
@SuppressWarnings("rawtypes")
private static boolean isSorted(Comparable[] a) {
    return isSorted(a, 0, a.length - 1);
}
private static boolean less(Comparable u, Comparable v) {
    return u.compareTo(v) < 0;
}
private static void exchange(Comparable[] a,int i,int j)//swapping
{
	Comparable temp=a[i];
	a[i]=a[j];
	a[j]=temp;
}

private static boolean isSorted(Comparable[] a, int low, int high) {
    for (int i = low + 1; i <= high; i++)
        if (less(a[i], a[i-1]))
        	return false;
    return true;
}

private static int partition(Comparable[] a,int low,int high)
{
	int i=low,j=high+1;
	Comparable v=a[low];
	while(true)
	{
		while(less(a[++i],v))
			if(i==high)
				break;
		while(less(v,a[--j]))
			if(j==low)
				break;
		if(i>=j)
			break;
		exchange(a,i,j);//swapping
	}
	exchange(a,low,j);//swapping
	return j;
}
public static void main(String[] args)
{
    System.out.println("Test output produced by Sai Shashank Gourisetty");
	int N=500,M=500;
	System.out.println("Array Size	Quick	New Quick	Ratio");
	for(int n=N;true;n*=2)
	{
		Double[] array1=new Double[n];
		Double[] array2=new Double[n];
		for(int i=0;i<n;i++)
		{
			array1[i]=StdRandom.uniform();//generate random array
		     array2[i]=array1[i];
		}

double quick=times("Quick",array1,M);
assert(isSorted(array1));
	array2=Arrays.copyOf(array1, array1.length);

double quickMod=times("ModifiedQuick",array1,M);
assert(isSorted(array1));
System.out.printf("%8d\t%5.3f\t%5.3f\t\t%2.3f\n",n,quick,quickMod,quickMod/quick);
	}
}
}