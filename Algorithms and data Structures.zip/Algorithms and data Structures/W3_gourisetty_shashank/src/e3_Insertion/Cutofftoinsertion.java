package e3_Insertion;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StopwatchCPU;

public class Cutofftoinsertion {
private static void sort(Comparable[] a,int cutoff)
{
	sort(a,cutoff,0,a.length-1);
}
private static void sort(Comparable[] a,int cutoff,int low,int high)//sort the array
{
	if(high<=low)
		return;
	int N=high-low+1;
	if(N<= cutoff)	//cutoff for insertion sort
	{
		Insertion.sort(a,low,high);
		return;
	}
	else
	{
		int j=partition(a,low,high);
		sort(a,cutoff,low,j-1);
		sort(a,cutoff,j+1,high);
		assert isSorted(a,low,high);
	}
}
private static int partition(Comparable[] a,int low,int high)
{
	int i=low,j=high+1;
	Comparable v=a[low];
	while(true)
	{
		while(less(a[++i],v))
			if(i== high)
				break;
		while(less(v,a[--j]))
			if(j==low)
				break;
		if(i>=j)
			break;
		exchange(a,i,j);//swapping
	}
	exchange(a,low,j);//swapping
	return j;
}
private static void exchange(Comparable[] a,int i,int j)
{
	Comparable t=a[i];
	a[i]=a[j];
	a[j]=t;
}
private static boolean less(Comparable u,Comparable v)
{
	return u.compareTo(v)<0;
}
public static boolean isSorted(Comparable[] a, int low, int high)
{
	for(int i=0;i<a.length;i++)
	if(less(a[i],a[i-1]))
		return false;
			return true;
}
public static void main(String[] args) 
{
    System.out.println("Test output produced by Sai Shashank Gourisetty");
	int size;
	int maxSize=1000000;
	if(args.length>0)
	{
	size=Integer.parseInt(args[0]);
	System.out.println("Array size 	 Cut-off   Time");
	for(int N=size;N<=maxSize;N*=10)
	{
		Double[] array=new Double[N];
		for(int i=0;i<N;i++)
		array[i]=StdRandom.uniform();			//random values
		
	for(int M=0;M<31;M++)	
	{
		StopwatchCPU timer=new StopwatchCPU();
		sort(array,M);//quick sort
		double time=timer.elapsedTime();
		assert(isSorted(array, M, M));
		System.out.printf("%7d \t %3d\t %3.3f\n",N,M,time);
		StdRandom.shuffle(array);			
	}}}
	else
		System.out.println("Enter array size in command line");
}}