package e4_MedianThreePartition;
/*
 * @author Sai Shashank Gourisetty
 */
public class Insertion {
	public static void sort(Comparable[] a)
	{
		for(int i=1;i<a.length;i++)
		{
			for(int j=i;j>0&&less(a[j],a[j-1]);j--)
				exchange(a,j,j-1);
 		}
	}
	public static boolean isSorted(Comparable[] a, int lo, int hi)
 	{
		for(int i=0;i<a.length;i++)
		if(less(a[i],a[i-1]))
			return false;
				return true;
	}
	private static boolean less(Comparable u,Comparable v)
	{
		return u.compareTo(v)<0;
	}
	private static void exchange(Comparable[] a,int i,int j)//swapping
 	{
		Comparable temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
}