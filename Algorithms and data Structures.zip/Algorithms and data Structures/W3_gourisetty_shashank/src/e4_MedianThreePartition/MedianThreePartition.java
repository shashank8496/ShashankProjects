package e4_MedianThreePartition;
import java.util.Arrays;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.Stopwatch;
/*
 * @author Sai Shashank Gourisetty
 */
public class MedianThreePartition {
	private static Comparable med;
	public static void main(String[] args)
	{
	Comparable[] b= {'1','0','8'};
	Comparable[] c= {"5","10","10"};
	Comparable[] d= {'5','8','5'};
	Comparable[] e= {'8','1','9'};
    System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("median of numbers: \nTest case 1 : Given array "+Arrays.toString(c)+" Median is " +medianOf3(c, 0, 2));
	System.out.println("Test case 2 : Given array "+Arrays.toString(b)+" Median is " +medianOf3(b, 0, 2));
	System.out.println("Test case 3 : Given array "+Arrays.toString(d)+" Median is " +medianOf3(d, 0, 2));
	System.out.println("Test case 4 : Given array "+Arrays.toString(e)+" Median is " +medianOf3(e, 0, 2));
	System.out.println("Test case 5 :");
	int size;
	if(args.length>0)
	{
	size=Integer.parseInt(args[0]);
	System.out.println("Array size    Time  Ratio");
	double prev=0.0;
	for(int N=size;true; N=N*2)
	{
		Double[] a=new Double[N];
		for(int j=0;j<N;j++)
		{
			a[j]=StdRandom.uniform();			//random numbers
		}
		Stopwatch timer=new Stopwatch();
		sort(a);
		assert isSorted(a);
		double time = timer.elapsedTime();
		if(prev==0)
			System.out.printf("%8d %8.3f --\n",N,time);
		else
			System.out.printf("%8d %8.3f %8.3f\n",N,time,time/prev);
		prev=time;
	}
	}
	else
		System.out.println("exception");
}
public static void sort(Comparable[] a)
{
	sort(a,0,a.length-1);
}
private static void sort(Comparable[] a,int lo,int hi)
{
	int size=hi-lo+1;
	if(size<=3)//insertion sort if small
	{
		Insertion.sort(a);
	} else //quick sort
	{
		Comparable medi = medianOf3(a,lo,hi);
	int partition=partition(a,lo,hi,medi);
	sort(a,lo,partition-1);
	sort(a,partition+1,hi);
}
}
//find the median of 3 numbers from the array
public static Comparable medianOf3(Comparable[] a,int lo,int hi)
{
int center=(lo+hi)/2;
if(less(a[center],a[lo]))
	exchange(a,lo,center);
if(less(a[hi],a[lo]))
	exchange(a,lo,hi);
if(less(a[hi],a[center]))
	exchange(a,center,hi);
exchange(a,center,hi-1);//put pivot on right
return a[hi-1];//return median value
}
public static boolean isSorted(Comparable[] a)
{
return isSorted(a,0,a.length-1);
}
private static int partition(Comparable[] a,int lo,int hi,Comparable v)
{
int i=0,j=hi-1;
while(true)
{
	while(less(a[++i],v))
		if(i==hi)
			break;
	while(less(a[--j],v))
		if(j==lo)
			break;
	if(i>=j) //if pointers cross or meets
		break;
	else
		exchange(a,i,j);//swap elements
}
exchange(a,i,hi-1);
return i; //return pivot location
}

private static boolean less(Comparable u,Comparable v)
{
return u.compareTo(v)<0;
}
public static boolean isSorted(Comparable[] a, int lo, int hi)
{
for(int i=0;i<=a.length;i++)
if(less(a[i],a[i-1]))
	return false;
		return true;
}
//displays the array
public static void display(Comparable[] a)
{
int n=a.length-1;
for(int j=0;j<=n;j++)
{
	System.out.print(a[j] + " ");
}
}
private static void exchange(Comparable[] a,int i,int j)
{
Comparable temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}