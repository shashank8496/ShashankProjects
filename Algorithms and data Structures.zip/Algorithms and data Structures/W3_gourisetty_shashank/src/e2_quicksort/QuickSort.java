package e2_quicksort;
import edu.princeton.cs.algs4.StdRandom;
/*
 * @author Sai Shashank Gourisetty
 */
public class QuickSort { 
    public static void sort(Comparable[] a)
    {
       StdRandom.shuffle(a);
        sort(a, 0, a.length - 1);
        assert isSorted(a, 0, a.length - 1);
    }
    private static void sort(Comparable[] a, int low, int high) { 
        if (high <= low) return;
        int j = partition(a, low, high);
        sort(a, low, j-1);
        sort(a, j+1, high);
        assert isSorted(a, low, high);
    }
   
    private static int partition(Comparable[] a, int low, int high) {
        int i = low;
        int j = high + 1;
        Comparable v = a[low];
        while (true) { 
            while (less(a[++i], v)) {
                if (i == high) break;
            }
            while (less(v, a[--j])) {
                if (j == low) break;  
            }
            if (i >= j)// check if pointers cross 
            	break;
            exchange(a, i, j);//swapping
        }
        exchange(a, low, j);//swapping
        return j;
    }
  
    // swapping elements
    private static void exchange(Object[] a, int i, int j) {
        Object swap = a[i];
        a[i] = a[j];
        a[j] = swap;
    }

    @SuppressWarnings("unchecked")
	private static boolean less(Comparable u, Comparable v) {
        if (u == v) 
        	return false;
        return u.compareTo(v) < 0;
    }
    //checks for array sort
    private static boolean isSorted(Comparable[] a, int low, int high) {
        for (int i = low + 1; i <= high; i++)
            if (less(a[i], a[i-1])) 
            	return false;
        return true;
    }

    // Displays array
    private static void display(Comparable[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]+" ");
        }
    }

    public static void main(String[] args) {
        String[] a = {"S","H","A","S","H","A","N","K","G","O","U","R","I","S","E","T","T","Y"};
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("Before quick sort");
        display(a);
        QuickSort.sort(a);
        System.out.println("\nAfter quick sort");
        display(a);
        assert isSorted(a, 0, a.length - 1);
}
}