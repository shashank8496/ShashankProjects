package Activity3Aand3B;

import java.util.Arrays;

/*
 * @author Sai Shashank Gourisetty
 */
public class StopWatch {
	 long startTime;
	 long stopTime;
	
	public StopWatch() {
		startTime = 0;
		stopTime = 0;
	}
	
	public void start() {//to start clock
		if (startTime>0) {
			throw new RuntimeException("Stopwatch already started.");
		}
		startTime = System.currentTimeMillis();
	}
	
	public void stop() {//to stop clock
		if (stopTime>0) {
			throw new RuntimeException("Stopwatch already stopped.");
		}
		stopTime = System.currentTimeMillis();
	}
	
	public long elapsedTimeInMiliseconds() {//to calculate time difference
		return stopTime-this.startTime;
	}
	public static void main(String [] args)
	 {
		int[] array1 = {-6 ,12 ,20 ,-11 ,13 ,0,20,-2};
		StopWatch sw= new StopWatch();
		sw.start();
		for(int i=0;i<12000;i++)
		{
			SumtoZero.ThreeNumber(array1);
		}
		sw.stop();
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case 1 for array " +Arrays.toString(array1));
		System.out.println("Total time executed for calculating three sum is " +sw.elapsedTimeInMiliseconds());
	 }
}
