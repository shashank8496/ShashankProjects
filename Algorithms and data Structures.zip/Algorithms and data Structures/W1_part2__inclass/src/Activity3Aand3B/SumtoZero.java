package Activity3Aand3B;
/*
 * @author Sai Shashank Gourisetty
 */
public class SumtoZero {
	
	static void ThreeNumber(int a[]) //function calculates the set of 3 numbers which sum to 0
	{ 
	int a_size=a.length;
	@SuppressWarnings("unused")
	int count=0;
	for (int i = 0; i < a_size - 2; i++) { 
	for (int j = i + 1; j < a_size - 1; j++) { 
	for (int k = j + 1; k < a_size; k++) { 
	if (a[i] + a[j] + a[k] == 0) { //checks for 0 condition
	++count;  
	}	}	}	}
	//System.out.print("Total Triplet in a given array is " +count +"\n");
	}
	
	public static void main(String[] args) {
        int[] array1 = {-6 ,4 ,1 ,-33 ,2 ,10 ,-11 ,23 ,0 ,-2};
        int[] array2 = {-16 ,52 ,11 ,-63 ,12 ,10 ,-11 ,23 ,5 ,0};
        int[] array3 = {-1 ,2 ,40 ,-3 ,10 ,0 ,-31 ,23 ,100 ,-50};
        int[] array4 = {-16 ,52 ,11 ,-63 ,12 ,10 ,-11 ,23 ,5 ,0};
        int[] array5 = {-1 ,2 ,40 ,-3 ,10 ,0 ,-31 ,23 ,100 ,-50};
        
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("Testcase 1:");
        ThreeNumber(array1);
        System.out.println("Testcase 2:");
        ThreeNumber(array2);
        System.out.println("Testcase 3:");
        ThreeNumber(array3);
        System.out.println("Testcase 4:");
        ThreeNumber(array4);
        System.out.println("Testcase 5:");
        ThreeNumber(array5);        
	}
}
