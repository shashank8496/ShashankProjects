package Activity1Cand1D;
import java.util.Arrays;
/*
 * @author Sai Shashank Gourisetty
 */
public class ArrayEquality {
	static void CommonNumbers(int array1[], int array2[]) 
	{ 
	System.out.println("First array is ");
		for(int i=0;i<array1.length;i++)
		{
		System.out.println(array1[i]+" ");
		}
		System.out.println("Second array is ");
		for(int i=0;i<array2.length;i++)
		{
		System.out.println(array2[i]+" ");
		}
		if (Arrays.equals(array1,array2))
		{
	System.out.println(" The two arrays are equal");
		}
		else 
		{
			System.out.println("The two arrays are not equal");
		}
	  
	} 

	public static void main(String[] args)
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
	    int array1[] = {2,3,1,4}; 
	    int array2[] = {2, 3, 1, 4};
	    System.out.println("common elements in the arrays are below");
	    System.out.println("testcase 1:");
	    CommonNumbers(array1,array2);//This function compares two arrays 
	    
	    int array3[] = {15, 13, 251, 32, 8}; 
	    int array4[] = {9,5,1,51,33,30,132}; 
	    System.out.println("testcase 2:");
	    CommonNumbers(array3,array4); 
	    
	    int array5[] = {1,3,29,21}; 
	    int array6[] = {3,4,25,127,8,13}; 
	    System.out.println("testcase 3:");
	    CommonNumbers(array5, array6); 
	    
	    int array7[] = {11,2,35,6,3}; 
	    int array8[] = {4,5,6,44,8,9,10}; 
	    System.out.println("testcase 4:");
	    CommonNumbers(array7, array8);
	    
	    int array9[] = {89,11,12,91,4,1}; 
	    int array10[] = {54,-1,31,12,10,1}; 
	    System.out.println("testcase 5:");
	    CommonNumbers(array9,array10);	
	}
}
