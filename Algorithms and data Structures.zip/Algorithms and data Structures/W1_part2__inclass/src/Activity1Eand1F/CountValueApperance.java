package Activity1Eand1F;

import java.util.Arrays;

/*
 * @author Sai Shashank Gourisetty
 */
public class CountValueApperance {
	public static int count(int val, int[] array, int first, int last) {
		int count = 0;
		for (int i=first; i<last+1; i++) {//counts the number of apperance in array
			if (array[i]==val) {
				count++;
			}
		}
		return count;
	}
	public static void main(String[] args) {
		int[] array1 = {-6 ,2 ,1 ,-33 ,2 ,10 ,-11 ,23 ,0 ,-2};
		int value=2;
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("Given array is " +Arrays.toString(array1));
        System.out.println("Testcase 1:");
		int result=count(value,array1,0,5);//takes value to be searched in a array between 0 and 5 index
		System.out.println("Number "+value+ " has appeared " +result+" times in a given array");
		value=10;
		System.out.println("Testcase 2:");
		result=count(value,array1,1,5);
		System.out.println("Number "+value+ " has appeared " +result+" times in a given array");
		value=96;
		System.out.println("Testcase 3:");
		result=count(value,array1,0,3);
		System.out.println("Number "+value+ " has appeared " +result+" times in a given array");
	}
}
