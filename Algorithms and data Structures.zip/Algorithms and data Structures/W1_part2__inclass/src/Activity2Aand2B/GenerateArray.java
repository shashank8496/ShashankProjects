package Activity2Aand2B;
import java.util.Random;
/*
 * @author Sai Shashank Gourisetty
 */
public class GenerateArray {
	public static int[] RandomArray(int minValue,int maxValue,int size)
	{
	int[] arr=new int[size];
	Random random = new Random();
	for(int i=0;i<size;i++)
	{
	arr[i]=random.nextInt(maxValue-minValue)+minValue;//generates random integer with min value
	  
	}
	return arr;
	}
	public static void testArray(int minValue,int maxValue,int size)
	{
	int[] arr=new int[size];
	arr=RandomArray(minValue,maxValue,size);
	for(int i=0;i<arr.length;i++)
	System.out.print(arr[i]+" ");
	}
	public static void main(String[] args) {
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Test case 3 ");
	System.out.println("Random elements generated are ");
    testArray(1,35,6);
	}
}
