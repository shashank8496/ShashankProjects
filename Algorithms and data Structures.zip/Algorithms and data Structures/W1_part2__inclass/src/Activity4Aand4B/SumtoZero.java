package Activity4Aand4B;
/*
 * @author Sai Shashank Gourisetty
 */
public class SumtoZero {
	
	static void ThreeNumber(int a[]) //this function calculates sum of three numbers to zero in a given array
	{ 
	int a_size=a.length;
	for (int i = 0; i < a_size - 2; i++) { 
	for (int j = i + 1; j < a_size - 1; j++) { 
	for (int k = j + 1; k < a_size; k++) { 
	if (a[i] + a[j] + a[k] == 0) { //checks sum of 3 numbers to zero
	System.out.print("Triplet are " + a[i] + ", " + a[j] + ", " + a[k]+"\n");  
	}	}	}	}  
	}
	
	public static void main(String[] args) {
        int[] array1 = {-6 ,4 ,1 ,-33 ,2 ,10 ,-11 ,23 ,0 ,-2};
        int[] array2 = {-16 ,52 ,11 ,-63 ,12 ,10 ,-11 ,23 ,5 ,0};
        int[] array3 = {-1 ,2 ,40 ,-3 ,10 ,0 ,-31 ,23 ,100 ,-50};
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("Testcase 1:");
        ThreeNumber(array1);
        System.out.println("Testcase 2:");
        ThreeNumber(array2);
        System.out.println("Testcase 3:");
        ThreeNumber(array3);
        
	}
}
