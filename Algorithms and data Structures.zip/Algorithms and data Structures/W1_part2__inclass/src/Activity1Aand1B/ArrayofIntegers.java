package Activity1Aand1B;

import java.util.Arrays;

/*
 * @author Sai Shashank Gourisetty
 */
public class ArrayofIntegers {

	public static void main(String[] args) {
        int[] array1 = {2, 23, 94 , 96};
        int[] array2 = {-6,9 , 3 , 12 , 1};//Store values in array
        int[] array3 = {-6, 1 , -33 , 10 ,1};
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("The array1 is" );
        System.out.println(Arrays.toString(array1));
        System.out.println("The array2 is" );
        System.out.println(Arrays.toString(array2));
        System.out.println("The array3 is" );
        System.out.println(Arrays.toString(array3));
    }
	}
