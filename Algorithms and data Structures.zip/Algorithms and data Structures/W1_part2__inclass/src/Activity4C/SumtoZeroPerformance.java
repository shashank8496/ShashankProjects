package Activity4C;

/*
 * @author Sai Shashank Gourisetty
 */
public class SumtoZeroPerformance 
{
	
	static int ThreeNumber(int a[]) 
	{ //calculates sum of 4 numbers in array to 0
	int a_size=a.length;
	int count=0;
	for (int i = 0; i < a_size - 2; i++) { 
	for (int j = i + 1; j < a_size - 1; j++) { 
	for (int k = j + 1; k < a_size; k++) { 
	if (a[i] + a[j] + a[k] == 0) { 
		++count;
	//System.out.print("Triplet are " + a[i] + ", " + a[j] + ", " + a[k]+"\n");  
	}	}	}	} 
	return count;
	}
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		
		int maxSize=4000;
		for (int size = 1000; size<=maxSize; size+=1000) {
			
			int a[]=GenerateArray.testArray(-1000, 1000,size);//generates array which has min value -1000 and max of 1000
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			int count = ThreeNumber(a);
			stopWatch.stop();
			System.out.println("Size "+size+": "+stopWatch.elapsedTimeInMiliseconds()+" ms (count="+count+")" );
		}
        
	}
}