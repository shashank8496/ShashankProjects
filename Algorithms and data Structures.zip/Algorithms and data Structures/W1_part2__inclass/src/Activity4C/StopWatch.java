package Activity4C;
/*
 * @author Sai Shashank Gourisetty
 */
public class StopWatch {
	 long startTime;
	 long stopTime;
	
	public StopWatch() {
		startTime = 0;
		stopTime = 0;
	}
	
	public void start() {//starts clock
		if (startTime>0) {
			throw new RuntimeException("Stopwatch already started.");
		}
		startTime = System.currentTimeMillis();
	}
	
	public void stop() {//stops clock
		if (stopTime>0) {
			throw new RuntimeException("Stopwatch already stopped.");
		}
		stopTime = System.currentTimeMillis();
	}
	
	public long elapsedTimeInMiliseconds() {
		return stopTime-startTime;
	}
}
