package Activity4C;
import java.util.Random;
/*
 * @author Sai Shashank Gourisetty
 */
public class GenerateArray {
	public static int[] RandomArray(int minValue,int maxValue,int size)//generates a random array of given size
	{
	int[] arr=new int[size];
	Random random = new Random();
	for(int i=0;i<size;i++)
	{
	arr[i]=random.nextInt(maxValue-minValue)+minValue;
	  
	}
	return arr;
	}
	public static int []testArray(int minValue,int maxValue,int size)
	{
	int[] arr=new int[size];
	arr=RandomArray(minValue,maxValue,size);

return arr;
	}

}
