package guidedassignment;
/*
 * @author Sai Shashank Gourisetty
 */
import java.io.ByteArrayInputStream;
import java.util.Scanner;

public class Dictionary extends RedBlackBST<String, String> 
{
	public void initialize() {
		Scanner scanner = new Scanner(new ByteArrayInputStream(SAMPLE_WORDS.getBytes()), "UTF-8");
		while ( scanner.hasNext()) {
			String key = scanner.next();
			put(key, key + "'s definition");
		}
		scanner.close();
	}
	private int getLeaves(String key) {
		Node x = root;
		while (x != null) {
			int cmp = key.compareTo(x.key);
			if (cmp < 0)
				x = x.left;
			else if (cmp > 0)
				x = x.right;
			else
				return 1 + (x.left != null ? 1 : 0) + (x.right != null ? 1 : 0);
		}
		return 0;
	}
	static void printInorder(Node node, String spaces) {
		if (node == null)
			return;
		printInorder(node.left, spaces + "    ");
		System.out.println(spaces + node.key);
		printInorder(node.right, spaces + "    ");
	}

	static void printPreorder(Node node, String spaces) {
		if (node == null)
			return;
		System.out.println(spaces + node.key);
		printPreorder(node.left, spaces + "    ");
		printPreorder(node.right, spaces + "    ");
	}

	static void printPostorder(Node node, String spaces) {
		if (node == null)
			return;
		printPostorder(node.left, spaces + "    ");
		printPostorder(node.right, spaces + "    ");
		System.out.println(spaces + node.key);
	}

	public String find(String key) {
		return get(key);
	}

	public boolean isLeaf(String key) {
		return getLeaves(key) == 1;
	}

	public boolean hasLeaf(String key) {
		return getLeaves(key) == 2;
	}

	public boolean hasLeaves(String key) {
		return getLeaves(key) == 3;
	}
	public String firstWord() {
		return min();
	}

	public String lastWord() {
		return max();
	}
	public void deleteLeaf(String key) {//delete leaf
		if (isLeaf(key)) {
			delete(key);
		}
	}

	public void deleteWithLeaf(String key) {
		if (hasLeaf(key)) {
			deleteNodes(key);
		}
	}
	 // delete leaves
	public void deleteWithLeaves(String key) {
		if (hasLeaves(key)) {
			deleteNodes(key);
		}
	}

	public void deleteNodes(String key) {
		Node x = root;
		while (x != null) {
			int cmp = key.compareTo(x.key);
			if (cmp < 0)
				x = x.left;
			else if (cmp > 0)
				x = x.right;
			else {
				deleteNode(x.left);
				deleteNode(x.right);
				delete(key);
				break;
			}
		}
	}

	private void deleteNode(Node node) {
		if (node == null)
			return;
		deleteNode(node.left);
		deleteNode(node.right);
		delete(node.key);
	}
	public String longestDefinitionWord() {
		String word = null;
		int definitionMax = 0;
		for (String s : keys()) {
			String definition = get(s);
			if (definition.length() > definitionMax) {
				word = s;
				definitionMax = definition.length();
			}
		}
		return word;
	}
	public static final String SAMPLE_WORDS = "G E O R G E M A S O N";
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Dictionary dict = new Dictionary();
		dict.initialize();
		dict.print();
		{
			String word;
			word = "Shashank";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
			word = "gourisetty";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
		}

		dict.put("S", "S's updated definition");
		dict.put("G", "G's updated definition");
		dict.put("Shashank", "Shashank's definition");
		dict.put("gourisetty","gourisetty's definition");
		dict.print();
		System.out.println("\nAfter adding shashank gourisetty");
		{
			String word;
			word = "Shashank";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
			word = "gourisetty";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
		}
		dict.delete("Shashank");
		dict.delete("gourisetty");
		System.out.println("\nAfter deleting shashank gourisetty");
		{
			String word;
			word = "Shashank";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
			word = "gourisetty";
			System.out.println(word + " is not present in dictionary: " + (dict.find(word) == null));
		}
		System.out.println("");
		for (String word : dict.keys()) {
			System.out.println(word + " is a leaf: " + dict.isLeaf(word)
				+ ", has a leaf: " + dict.hasLeaf(word)
				+ ", has leaves: " + dict.hasLeaves(word));
		}
		for (String word : new String[]{"gourisetty", "Shashank"}) {
			System.out.println(word + " is a leaf: " + dict.isLeaf(word)
				+ ", has a leaf: " + dict.hasLeaf(word)
				+ ", has leaves: " + dict.hasLeaves(word));
		}
		for (String word : dict.keys()) {
			if (dict.isLeaf(word)) {
				dict.deleteLeaf(word);
				System.out.println(word + " is deleted: " + (dict.find(word) == null));
				break;
			}
		}
		for (String word : dict.keys()) {
			if (dict.hasLeaf(word)) {
				dict.deleteWithLeaf(word);
				System.out.println(word + " is deleted: " + (dict.find(word) == null));
				break;
			}
		}
		for (String word : dict.keys()) {
			if (dict.hasLeaves(word)) {
				dict.deleteWithLeaves(word);
				System.out.println(word + " is deleted: " + (dict.find(word) == null));
				break;
			}
		}
		for (String word : dict.keys()) {
			dict.deleteNodes(word);
			System.out.println(word + " is deleted: " + (dict.find(word) == null));
			break;
		}
		dict.initialize();
		System.out.println("First word in dictionary is " + dict.firstWord());
		System.out.println("Last word in dictionary is " + dict.lastWord());
		System.out.println("Pre-order");
		printPreorder(dict.root, "");
		System.out.println("In-order");
		printInorder(dict.root, "");
		System.out.println("Post-order");
		printPostorder(dict.root, "");
		System.out.println("Height of tree is " + dict.height());
		System.out.println("Word with longest definition is " + dict.longestDefinitionWord());
		dict.put("gourisetty", "gourisetty's definition is longer than any other's");
		System.out.println("Word with longest definition is " + dict.longestDefinitionWord());
	}
}