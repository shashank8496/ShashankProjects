package e2_nonrecursive;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Scanner;
import java.util.Stack;
import edu.princeton.cs.algs4.Queue;

public class NonRecursiveBST  <Key extends Comparable<Key>, Value> 
{
    private Node root;  // root of BST
    private class Node 
    {	private Node left, right;    // subtrees
        private Key key;             // sorted by key
        private Value val;           // value
        public Node(Key key, Value val) 
        {
            this.key = key;
            this.val = val;
        }
    }
    public Iterable<Key> keys() 
    {
        Stack<Node> stack = new Stack<Node>();
        Queue<Key> queue = new Queue<Key>();
        Node x = root;
        while (x != null || !stack.isEmpty())
        {
            if (x != null) 
            {
                stack.push(x);
                x = x.left;
            }
            else
            {
                x = stack.pop();
                queue.enqueue(x.key);
                x = x.right;
            }
        }
        return queue;
    }
    public void put(Key key, Value val) 
    {
        Node z = new Node(key, val);
        if (root == null) 
        {
            root = z;
            return;
        }
        Node parent = null, x = root;
        while (x != null)
        {
            parent = x;
            int cmp = key.compareTo(x.key);
            if      (cmp < 0) 
            	x = x.left;
            else if (cmp > 0)
            	x = x.right;
            else 
            {
                x.val = val;
                return; 
            }
        }
        int cmp = key.compareTo(parent.key);
        if (cmp < 0) 
        	parent.left  = z;
        else 
        	parent.right = z;
    }
    Value get(Key key) {
        Node x = root;
        while (x != null) 
        {
            int cmp = key.compareTo(x.key);
            if      (cmp < 0) x = x.left;
            else if (cmp > 0) x = x.right;
            else return x.val;
        }
        return null;
    }

    public static void main(String[] args) 
    {   
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
    	System.out.println("Testcase 1");
        System.out.println("Enter String: ");
        @SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
        NonRecursiveBST<String, Integer> st = new NonRecursiveBST<String, Integer>();
        for (int i = 0; i<=7; i++) 
        {
            String key = sc.next();
            st.put(key, i);
        }
        for (String s : st.keys())
        	System.out.println(s + " " + st.get(s));
    }
}