package e4_DFA;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class DFA {

	static String txt[] = {"Algorithms and Data Structure Essentials","George Mason University ","week seven assignment","Master in Applied IT", "AIT Summer course " };
    static String pat[] = {"Structure","GMU","seven","Master","course" };

    public static void search(String pat){
        char[] chars = pat.toCharArray();
        Set<Character> charSet = new LinkedHashSet<Character>();
        for (char c : chars)
            charSet.add(c);

        StringBuilder sb = new StringBuilder();
        for (Character character : charSet) 
            sb.append(character);

        String index = sb.toString();
        int M = pat.length();
        int R = index.length();
        int dfa[][] = new int[R][pat.length()];

        System.out.println("pat: " + pat);

        dfa[index.indexOf(pat.charAt(0))][0] = 1;
        System.out.println("dfa['" + pat.charAt(0) + "'] [" + 0 + "] = " + 1);
        for (int X = 0, j = 1; j < M; j++)
        {
            for (int c = 0; c < R; c++) {
                dfa[c][j] = dfa[c][X];
                System.out.println("c: " + c);
                if(dfa[c][X] > 0)
                    System.out.println("dfa['" + index.charAt(c) + "'] [" + j + "] = " + dfa[c][X]);
            }
            dfa[index.indexOf(pat.charAt(j))][j] = j+1;
            System.out.println("dfa['" + pat.charAt(j) + "'] [" + j + "] = " + (j+1));
            X = dfa[index.indexOf(pat.charAt(j))][X];
            System.out.println("X: " + X);
        }

        for(int i = 0 ; i < index.length() ; i++)
            System.out.println(index.charAt(i) + ": " + Arrays.toString(dfa[i]));
        
    }
    public static void main(String args[]){
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        for(int i = 0 ; i < pat.length ; i++){
            search(pat[i]);
        }
    }
}