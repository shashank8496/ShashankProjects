package e5_KMP;
/*
 * @author Sai Shashank Gourisetty
 */
public class Main {

    static String txt[] = {"Algorithms and Data Structure Essentials","George Mason University ","week seven assignment","Master in Applied IT", "AIT Summer course " };
    static String pat[] = {"Structure","GMU","seven","Master","course" };

    public static void searchs(){
        for(int i = 0 ; i < pat.length ; i++){
            KMP kmp = new KMP(pat[i]);
            int offset = kmp.search(txt[i]);
            System.out.println("text:    " + txt[i]);
            System.out.print("pattern: ");
            for (int j = 0; j < offset; j++)
                System.out.print(" ");
            System.out.println(pat[i]);
        }
    }
    public static void main(String args[]){
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        searchs();
    }
}