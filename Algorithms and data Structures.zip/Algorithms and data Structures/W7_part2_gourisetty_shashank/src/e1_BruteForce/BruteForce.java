package e1_BruteForce;
/*
 * @author Sai Shashank Gourisetty
 */
public class BruteForce {

	static String txt[] = {"Algorithms and Data Structure Essentials","George Mason University ","week seven assignment","Master in Applied IT", "AIT Summer course "  };
    static String pat[] = {"Structure","GMU","seven","Master","course" };

    public static int search(String pat, String txt){
        System.out.println("txt: " + txt);
        System.out.println("pat: " + pat);
        int M = pat.length();
        int N = txt.length();
        for (int i = 0; i <= N - M; i++) {
            System.out.println("i: " + i + ", " + txt.substring(i));
            int j;
            for (j = 0; j < M; j++) {
                System.out.println("j-" + j);
                System.out.println("txt- " + txt.charAt(i + j));
                System.out.println("pat- " + pat.charAt(j));
                if (txt.charAt(i + j) != pat.charAt(j)) {
                    System.out.println("Not Equal");
                    break;
                }
                else
                    System.out.println("Equal");
            }
            if (j == M) {  
                System.out.println(" Found from position " + i );
                return i;
            }
        }
        System.out.println("Not Found");
        return N;
    }
    public static void main(String args[]){
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        for(int i= 0 ; i < txt.length ; i++){
            search(pat[i], txt[i]);
        }
    }
}