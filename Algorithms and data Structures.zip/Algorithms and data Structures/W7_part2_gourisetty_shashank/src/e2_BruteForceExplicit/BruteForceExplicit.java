package e2_BruteForceExplicit;
/*
 * @author Sai Shashank Gourisetty
 */
public class BruteForceExplicit {

	static String txt[] = {"Algorithms and Data Structure Essentials","George Mason University ","week seven assignment","Master in Applied IT", "AIT Summer course "  };

    static String pat[] = {"Structure","GMU","seven","Master","course" };

    public static int search(String pat, String txt)
    {
        System.out.println("txt: " + txt);
        System.out.println("pat: " + pat);
        int j, M = pat.length();
        int i, N = txt.length();
        for (i = 0, j = 0; i < N && j < M; i++) {
            System.out.println("i- " + i + ", " + txt.substring(i));
            System.out.println("j- " + j);
            System.out.println("pat-  " + pat.charAt(j));
            if (txt.charAt(i) == pat.charAt(j)) {
                System.out.println("Equal");
                j++;
            }
            else {
                System.out.println("Not Equal");
                i -= j;
                j = 0;
            }
        }
        if (j == M) { 
            System.out.println(" Found from position " + i );
            return i - M;
        }
        else {
            System.out.println("Not Found");
            return N; 
        }
    }
    public static void main(String args[]){
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        for(int i= 0 ; i < txt.length ; i++){
            search(pat[i], txt[i]);
        }
    }
}