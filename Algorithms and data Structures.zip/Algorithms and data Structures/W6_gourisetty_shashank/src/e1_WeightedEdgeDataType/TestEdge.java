package e1_WeightedEdgeDataType;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.In;
public class TestEdge {
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		In in = new In("tinyEWG.txt");
		in.readInt();
		in.readInt();
		for (int i = 0; i < 5; i++) {
			int v = in.readInt();
			int w = in.readInt();
			double weight = in.readDouble();
			Edge e = new Edge(v, w, weight);
			System.out.println(e);
		}
	}
}