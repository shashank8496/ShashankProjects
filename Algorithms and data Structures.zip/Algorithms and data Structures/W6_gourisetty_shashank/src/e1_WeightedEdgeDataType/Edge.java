package e1_WeightedEdgeDataType;
/*
 * @author Sai Shashank Gourisetty
 */
public class Edge implements Comparable<Edge> 
{
	private final int v;
	private final int w;
	private final double weight;

	public Edge(int v, int w, double weight) {
		if (v < 0)
			throw new IllegalArgumentException("vertex index must be a nonnegative integer");
		if (w < 0)
			throw new IllegalArgumentException("vertex index must be a nonnegative integer");
		if (Double.isNaN(weight))
			throw new IllegalArgumentException("Weight is NaN");
		this.v = v;
		this.w = w;
		this.weight = weight;
	}
	public int other(int vertex) {
		if (vertex == v)
			return w;
		else if (vertex == w)
			return v;
		else
			throw new IllegalArgumentException("Illegal endpoint");
	}
	public double weight() {
		return weight;
	}

	public int either() {
		return v;
	}

	@Override
	public int compareTo(Edge that) {
		return Double.compare(this.weight, that.weight);
	}

	public String toString() {
		return String.format("%d-%d %.5f", v, w, weight);
	}

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("After new edge is added ");
		Edge e = new Edge(10, 14, 4.61);//add new edge
		System.out.println(e);
	}
}