package e2_EdgeWeightedGraphDataType;
import edu.princeton.cs.algs4.Edge;
import edu.princeton.cs.algs4.In;
/*
 * @author Sai Shashank Gourisetty
 */
public class EdgeWeightedGraphTest {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		int V = 5;
		EdgeWeightedGraph ewg = new EdgeWeightedGraph(V);
		In in = new In("tinyEWG.txt");
		in.readInt();
		in.readInt();
		for (int i = 0; i < 5; i++) {
			int v = in.readInt();
			int w = in.readInt();
			double weight = in.readDouble();
			if (v >= V || w >= V) {
				i--;
				continue;
			}
			Edge e = new Edge(v, w, weight);
			ewg.addEdge(e);
		}
		System.out.println(ewg);
	}
}