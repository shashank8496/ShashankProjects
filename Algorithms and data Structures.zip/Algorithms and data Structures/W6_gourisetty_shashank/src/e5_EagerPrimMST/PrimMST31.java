package e5_EagerPrimMST;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.EdgeWeightedGraph;

public class PrimMST31  extends PrimMST{
	public PrimMST31(EdgeWeightedGraph G) {
		super(G);
	}
	public double weight() {
		return weight;
	}
}