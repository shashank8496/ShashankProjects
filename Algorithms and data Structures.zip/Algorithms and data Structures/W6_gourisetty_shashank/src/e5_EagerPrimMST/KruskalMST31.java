package e5_EagerPrimMST;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.*;

public class KruskalMST31  extends KruskalMST 
{
	public KruskalMST31(EdgeWeightedGraph G) {
		super(G);
	}
	public double weight() {
		double weight = 0.0;
		for (Edge e : edges())
			weight =weight+ e.weight();
		return weight;
	}
}