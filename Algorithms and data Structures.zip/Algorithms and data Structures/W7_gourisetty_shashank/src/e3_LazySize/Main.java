package e3_LazySize;

import e2_TrieSymbolTable.TrieSymbolTable;
import e2_TrieSymbolTable.Value;

/*
 * @author Sai Shashank Gourisetty
 */
public class Main {

	public static void main(String[] args) {
		TrieSymbolTable<Value> tst = new TrieSymbolTable<Value>();

		tst.put("she", new Value(0));
		tst.put("sells", new Value(1));
		tst.put("sea", new Value(2));
		tst.put("shells", new Value(3));
		tst.put("by", new Value(4));
		tst.put("the", new Value(5));
		tst.put("sea", new Value(6));
		tst.put("shore", new Value(7));
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 1");
		System.out.println("Input : she sells sea shells by the sea shore ");
		System.out.println("Node Lazy recursive size: "+tst.size()+"\n");
		
		TrieSymbolTable<Value> tst1 = new TrieSymbolTable<Value>();

		tst1.put("abbccc", new Value(0));
		tst1.put("abcc", new Value(1));
		tst1.put("abbcccdd", new Value(2));
		tst1.put("abbcccdddd", new Value(3));
		tst1.put("a", new Value(4));
		tst1.put("abb", new Value(5));

		System.out.println("Testcase 2");
		System.out.println("Input: abbccc abcc abbcccdd abbcccdddd a abb");
		System.out.println("Node Lazy recursive size: "+tst1.size()+"\n");
		
		TrieSymbolTable<Value> tst2 = new TrieSymbolTable<Value>();

		tst2.put("AIT", new Value(0));
		tst2.put("AIT512", new Value(1));
		tst2.put("AIT524", new Value(2));
		tst2.put("AIT542", new Value(3));
		tst2.put("AIT664", new Value(4));
		tst2.put("AIT614", new Value(5));
		tst2.put("AIT100", new Value(6));
		tst2.put("AIT666", new Value(7));
		
		System.out.println("Testcase 3");
		System.out.println("Input : AIT512 AIT524 AIT542 AIT664 AIT614 AIT100 AIT666");
		System.out.println("Node Lazy recursive size: "+tst2.size()+"\n");
		
		TrieSymbolTable<Value> tst3 = new TrieSymbolTable<Value>();

		tst3.put("wall", new Value(0));
		tst3.put("walmart", new Value(1));
		tst3.put("well", new Value(2));
		tst3.put("wear", new Value(3));

		System.out.println("Testcase 4");
		System.out.println("Input : wall walmart well wear");
		System.out.println("Node Lazy recursive size: "+tst3.size()+"\n");
		
		TrieSymbolTable<Value> tst4 = new TrieSymbolTable<Value>();

		tst4.put("a", new Value(0));
		tst4.put("at", new Value(1));
		tst4.put("all", new Value(2));
		tst4.put("almost", new Value(3));
		tst4.put("as", new Value(4));


		System.out.println("Testcase 5");
		System.out.println("Input : a at all almost as");
		System.out.println("Node Lazy recursive size: "+tst4.size()+"\n");
	}
}