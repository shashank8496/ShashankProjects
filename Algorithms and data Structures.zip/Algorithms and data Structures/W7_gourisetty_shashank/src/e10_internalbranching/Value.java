package e10_internalbranching;
/*
 * @author Sai Shashank Gourisetty
 */
public class Value {

private int val;
	
	public Value(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

	public void setVal(int val) {
		this.val = val;
	}

}
