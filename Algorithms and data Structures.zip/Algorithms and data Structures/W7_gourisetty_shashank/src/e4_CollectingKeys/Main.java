package e4_CollectingKeys;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Iterator;
import e2_TrieSymbolTable.TrieSymbolTable;
import e2_TrieSymbolTable.Value;

public class Main {
	public static void main(String[] args) {
		TrieSymbolTable<Value> tst = new TrieSymbolTable<Value>();

		tst.put("she", new Value(0));
		tst.put("sells", new Value(1));
		tst.put("sea", new Value(2));
		tst.put("shells", new Value(3));
		tst.put("by", new Value(4));
		tst.put("the", new Value(5));
		tst.put("sea", new Value(6));
		tst.put("shore", new Value(7));
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 1");
		System.out.println("Input : she sells sea shells by the sea shore ");

		System.out.println("Collecting the keys");
		Iterator<String> itr = tst.keys().iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println("\nCollecting keys with prefix 'se'");
		Iterator<String> itr1 = tst.keysWithPrefix("se").iterator();
		while(itr1.hasNext())
			System.out.println(itr1.next());
		
		TrieSymbolTable<Value> tst1 = new TrieSymbolTable<Value>();

		tst1.put("abbccc", new Value(0));
		tst1.put("abcc", new Value(1));
		tst1.put("abbcccdd", new Value(2));
		tst1.put("abbcccdddd", new Value(3));
		tst1.put("a", new Value(4));
		tst1.put("abb", new Value(5));
		tst1.put("abc", new Value(6));
		tst1.put("abcd", new Value(7));
		System.out.println("Testcase 2");
		System.out.println("Input: abbccc abcc abbcccdd abbcccdddd a abb abc abcd");

		System.out.println("Collecting the keys");
		Iterator<String> itr2 = tst1.keys().iterator();
		while(itr2.hasNext())
			System.out.println(itr2.next());
		
		System.out.println("\nCollecting keys with prefix 'abb'");
		Iterator<String> itr3 = tst1.keysWithPrefix("abb").iterator();
		while(itr3.hasNext())
			System.out.println(itr3.next());
		
		TrieSymbolTable<Value> tst2 = new TrieSymbolTable<Value>();

		tst2.put("AIT", new Value(0));
		tst2.put("AIT512", new Value(1));
		tst2.put("AIT524", new Value(2));
		tst2.put("AIT542", new Value(3));
		tst2.put("AIT664", new Value(4));
		tst2.put("AIT614", new Value(5));
		tst2.put("AIT100", new Value(6));
		tst2.put("AIT666", new Value(7));
		
		System.out.println("Testcase 3");
		System.out.println("Input : AIT512 AIT524 AIT542 AIT664 AIT614 AIT100 AIT666");

		System.out.println("Collecting the keys");
		Iterator<String> itr4 = tst2.keys().iterator();
		while(itr4.hasNext())
			System.out.println(itr4.next());
		
		System.out.println("\nCollecting keys with prefix 'abb'");
		Iterator<String> itr5 = tst2.keysWithPrefix("abb").iterator();
		while(itr5.hasNext())
			System.out.println(itr5.next());
		
		TrieSymbolTable<Value> tst3 = new TrieSymbolTable<Value>();

		tst3.put("wall", new Value(0));
		tst3.put("walmart", new Value(1));
		tst3.put("well", new Value(2));
		tst3.put("wear", new Value(3));
		tst3.put("wore", new Value(4));
		tst3.put("w", new Value(5));
		tst3.put("wet", new Value(6));
		tst3.put("was", new Value(7));

		System.out.println("Testcase 4");
		System.out.println("Input : wall walmart well wear wore w wet was");
		System.out.println("Collecting the keys");
		Iterator<String> itr6 = tst3.keys().iterator();
		while(itr6.hasNext())
			System.out.println(itr6.next());
		
		System.out.println("\nCollecting keys with prefix 'wa'");
		Iterator<String> itr7 = tst3.keysWithPrefix("wa").iterator();
		while(itr7.hasNext())
			System.out.println(itr7.next());
		
		TrieSymbolTable<Value> tst4 = new TrieSymbolTable<Value>();

		tst4.put("a", new Value(0));
		tst4.put("at", new Value(1));
		tst4.put("all", new Value(2));
		tst4.put("almost", new Value(3));
		tst4.put("as", new Value(4));
		tst4.put("are", new Value(5));
		tst4.put("alot", new Value(6));
		tst4.put("bat", new Value(7));

		System.out.println("Testcase 5");
		System.out.println("Input : a at all almost as are alot bat");

		System.out.println("Collecting the keys");
		Iterator<String> itr8 = tst4.keys().iterator();
		while(itr8.hasNext())
			System.out.println(itr8.next());
		
		System.out.println("\nCollecting keys with prefix 'al'");
		Iterator<String> itr9 = tst4.keysWithPrefix("al").iterator();
		while(itr9.hasNext())
			System.out.println(itr9.next());
	}}