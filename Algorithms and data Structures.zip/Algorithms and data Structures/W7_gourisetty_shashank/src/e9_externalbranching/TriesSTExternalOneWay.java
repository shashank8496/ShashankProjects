package e9_externalbranching;
/*
 * @author Sai Shashank Gourisetty
 */
public class TriesSTExternalOneWay<Value>  {
	private final Node root = new Node(false);
    private char CASE;  
    public void put(String key, Value val)
    {
    	insert(key, val);
    }
    public TriesSTExternalOneWay() {
        CASE = 'a';     
    }

    public TriesSTExternalOneWay(char CASE) {
        this.CASE = CASE;       }
 
    private void insert(String word, Value val) {
        Node trav = root;
        int i = 0;
        
        trav.val = val;

        while (i < word.length() && trav.edgeLabel[word.charAt(i) - CASE] != null) {
            int index = word.charAt(i) - CASE, j = 0;
            StringBuilder label = trav.edgeLabel[index];

            while (j < label.length() && i < word.length() && label.charAt(j) == word.charAt(i)) {
                ++i;
                ++j;
            }

            if (j == label.length()) {
                trav = trav.children[index];
            } else {
                if (i == word.length()) {  
                    Node existingChild = trav.children[index];
                    Node newChild = new Node(true);
                    StringBuilder remainingLabel = strCopy(label, j);

                    label.setLength(j);    
                    trav.children[index] = newChild;   
                    newChild.children[remainingLabel.charAt(0) - CASE] = existingChild;
                    newChild.edgeLabel[remainingLabel.charAt(0) - CASE] = remainingLabel;
                } else {    
                    StringBuilder remainingLabel = strCopy(label, j);
                    Node newChild = new Node(false);
                    StringBuilder remainingWord = strCopy(word, i);
                    Node temp = trav.children[index];

                    label.setLength(j);
                    trav.children[index] = newChild;
                    newChild.edgeLabel[remainingLabel.charAt(0) - CASE] = remainingLabel;
                    newChild.children[remainingLabel.charAt(0) - CASE] = temp;
                    newChild.edgeLabel[remainingWord.charAt(0) - CASE] = remainingWord;
                    newChild.children[remainingWord.charAt(0) - CASE] = new Node(true);
                }

                return;
            }
        }

        if (i < word.length()) {   
            trav.edgeLabel[word.charAt(i) - CASE] = strCopy(word, i);
            trav.children[word.charAt(i) - CASE] = new Node(true);
        } else {   
            trav.isEnd = true;
        }
    }

    private StringBuilder strCopy(CharSequence str, int index) {
        StringBuilder result = new StringBuilder(100);

        while (index != str.length()) {
            result.append(str.charAt(index++));
        }

        return result;
    }

    public void print() {
        printUtil(root, new StringBuilder());
    }

    private void printUtil(Node node, StringBuilder str) {
        if (node.isEnd) {
            System.out.println(str);
        }

        for (int i = 0; i < node.edgeLabel.length; ++i) {
            if (node.edgeLabel[i] != null) {
                int length = str.length();

                str = str.append(node.edgeLabel[i]);
                printUtil(node.children[i], str);
                str = str.delete(length, str.length());
            }
        }
    }
}

class Node {
    private final static int SYMBOLS = 26;
    Node[] children = new Node[SYMBOLS];
    StringBuilder[] edgeLabel = new StringBuilder[SYMBOLS];
    boolean isEnd;
    Object val;

    public Node(boolean isEnd) {
        this.isEnd = isEnd;
    }
}