package e9_externalbranching;
/*
 * @author Sai Shashank Gourisetty
 */
public class Main {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("External one way branching");
		System.out.println("Testcase 1");
		TriesSTExternalOneWay<Value> tst = new TriesSTExternalOneWay<>();
		tst.put("sai", new Value(1)); 
		tst.put("sais", new Value(2));
		tst.put("sha", new Value(3));
		System.out.println("Input: sai sais sha");
		System.out.println("Ouptut:");
		tst.print();
		
		System.out.println("\nTestcase 2");
		TriesSTExternalOneWay<Value> tst1 = new TriesSTExternalOneWay<>();
		tst1.put("sa", new Value(1)); 
		tst1.put("shashank", new Value(2));
		tst1.put("shashi", new Value(3));
		
		System.out.println("Input: sa shashank shashi");
		System.out.println("Ouptut:");
		tst1.print();
		
		System.out.println("\nTestcase 3");
		TriesSTExternalOneWay<Value> tst2 = new TriesSTExternalOneWay<>();
		tst2.put("usa", new Value(1)); 
		tst2.put("england", new Value(2));
		tst2.put("nz", new Value(2));
		
		System.out.println("Input: usa england nz");
		System.out.println("Ouptut:");
		tst2.print();
		
		System.out.println("Testcase 4");
		TriesSTExternalOneWay<Value> tst3 = new TriesSTExternalOneWay<>();
		tst3.put("c", new Value(1)); 
		tst3.put("b", new Value(2));
		tst3.put("a", new Value(3));
		
		System.out.println("Input: c b a");
		System.out.println("Ouptut:");
		tst3.print();
		
		System.out.println("Testcase 5");
		TriesSTExternalOneWay<Value> tst4 = new TriesSTExternalOneWay<>();
		tst4.put("ab", new Value(1)); 
		tst4.put("bc", new Value(2));
		tst4.put("cd", new Value(3));
		
		System.out.println("Input: ab bc cd");
		System.out.println("Ouptut:");
		tst4.print();
	}
}