package e2_TrieSymbolTable;
/*
 * @author Sai Shashank Gourisetty
 */
public class Main {

	public static void main(String[] args) {
		TrieSymbolTable<Value> tst = new TrieSymbolTable<Value>();

		tst.put("she", new Value(0));
		tst.put("sells", new Value(1));
		tst.put("sea", new Value(2));
		tst.put("shells", new Value(3));
		tst.put("by", new Value(4));
		tst.put("the", new Value(5));
		tst.put("sea", new Value(6));
		tst.put("shore", new Value(7));
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 1");
		System.out.println("Input : she sells sea shells by the sea shore ");
		System.out.println("Tries created \n(by) value is " + tst.get("by").getVal()+"\n");
		
		TrieSymbolTable<Value> tst1 = new TrieSymbolTable<Value>();

		tst1.put("abbccc", new Value(0));
		tst1.put("abcc", new Value(1));
		tst1.put("abbcccdd", new Value(2));
		tst1.put("abbcccdddd", new Value(3));
		tst1.put("a", new Value(4));
		tst1.put("abb", new Value(5));
		tst1.put("abc", new Value(6));
		tst1.put("abcd", new Value(7));
		System.out.println("Testcase 2");
		System.out.println("Input: abbccc abcc abbcccdd abbcccdddd a abb abc abcd");
		System.out.println("Tries created \n(abc) value is " + tst1.get("abc").getVal()+"\n");
		
		TrieSymbolTable<Value> tst2 = new TrieSymbolTable<Value>();

		tst2.put("AIT", new Value(0));
		tst2.put("AIT512", new Value(1));
		tst2.put("AIT524", new Value(2));
		tst2.put("AIT542", new Value(3));
		tst2.put("AIT664", new Value(4));
		tst2.put("AIT614", new Value(5));
		tst2.put("AIT100", new Value(6));
		tst2.put("AIT666", new Value(7));
		
		System.out.println("Testcase 3");
		System.out.println("Input : AIT512 AIT524 AIT542 AIT664 AIT614 AIT100 AIT666");
		System.out.println("Tries created \n(AIT524) value is " + tst2.get("AIT524").getVal()+"\n");
		
		TrieSymbolTable<Value> tst3 = new TrieSymbolTable<Value>();

		tst3.put("wall", new Value(0));
		tst3.put("walmart", new Value(1));
		tst3.put("well", new Value(2));
		tst3.put("wear", new Value(3));
		tst3.put("wore", new Value(4));
		tst3.put("w", new Value(5));
		tst3.put("wet", new Value(6));
		tst3.put("was", new Value(7));

		System.out.println("Testcase 4");
		System.out.println("Input : wall walmart well wear wore w wet was");
		System.out.println("Tries created \n(wore) value is " + tst3.get("wore").getVal()+"\n");
		
		TrieSymbolTable<Value> tst4 = new TrieSymbolTable<Value>();

		tst4.put("a", new Value(0));
		tst4.put("at", new Value(1));
		tst4.put("all", new Value(2));
		tst4.put("almost", new Value(3));
		tst4.put("as", new Value(4));
		tst4.put("are", new Value(5));
		tst4.put("alot", new Value(6));
		tst4.put("bat", new Value(7));

		System.out.println("Testcase 5");
		System.out.println("Input : a at all almost as are alot bat");
		System.out.println("Tries created \n(bat) value is " + tst4.get("bat").getVal());
	}
}