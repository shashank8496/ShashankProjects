package e8_Alphabet;
/*
 * @author Sai Shashank Gourisetty
 */
public class Alphabet {
	private static int R;
	private static String str;
	
	public Alphabet(String str) {
		this.R = str.length();
		this.str = str;
	}
	
	public static char toChar(int index)
	{
		return str.charAt(index);
	}
	
	
	public static int toIndex(char c)
	{
		for(int i = 0; i < R; i++)
		{
			if(str.charAt(i) == c)
				return i;
		}
		return c;
	}
}