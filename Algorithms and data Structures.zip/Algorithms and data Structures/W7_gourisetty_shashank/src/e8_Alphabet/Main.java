package e8_Alphabet;
/*
 * @author Sai Shashank Gourisetty
 */
public class Main {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("Testcase 1");
		Alphabet alp = new Alphabet("sea");
		System.out.println("Input: sea");
		System.out.println("toChar(1) is "+alp.toChar(1));
		System.out.println("toIndex(e) value is "+alp.toIndex("e".charAt(0))+"\n");
				
		System.out.println("Testcase 2");
		Alphabet alp1 = new Alphabet("sai");
		System.out.println("Input: sai");
		System.out.println("toChar(2) is "+alp1.toChar(2));
		System.out.println("toIndex(s) value is "+alp1.toIndex("s".charAt(0))+"\n");
		
		System.out.println("Testcase 3");
		Alphabet alp2 = new Alphabet("shashank");
		
		System.out.println("Input: shashank");
		System.out.println("toChar(4) is "+alp2.toChar(4));
		System.out.println("toIndex(k) value is "+alp1.toIndex("k".charAt(0))+"\n");
		
		System.out.println("Testcase 4");
		Alphabet alp3 = new Alphabet("shashi");
	
		
		System.out.println("Input: shashi");
		System.out.println("toChar(1) is "+alp3.toChar(1));
		System.out.println("toIndex(i) value is "+alp3.toIndex("i".charAt(0))+"\n");
		
		System.out.println("Testcase 5");
		Alphabet alp4 = new Alphabet("gmu");
		
		System.out.println("Input: gmu");
		System.out.println("toChar(2) is "+alp4.toChar(2));
		System.out.println("toIndex(u) value is "+alp4.toIndex("u".charAt(0)));
	}
}