package e4_linkedliststack;
/*
 * @author Sai Shashank Gourisetty
 */
public class LinkedListStack<Item> {
	
	private class Node {
		Item item;
		Node NNode;
	}
	
	public Node top;
	int size;
	public LinkedListStack() {
		top = null;
		size = 0;
	}	
	
	public void push(Item item) {
		Node node = new Node();
		node.item = item;
		node.NNode = top;
		top = node;
		size++;
	}
	
	public Item pop() {
		Node node = top;
		top = node.NNode;
		size--;
		return node.item;
	}
	
	public int size() {
		return size;
	}

	public String toString() {
		String result ="stack :[";
		String stack = "",sep = "";
		for (Node node=top; node!=null; node=node.NNode) {
			Item item = node.item;
			stack = item.toString()+sep+stack;;
			sep = ", ";
		}
		result += stack+"]";
		return result;
	}
}
