package e4_linkedliststack;
/*
 * @author Sai Shashank Gourisetty
 */
public class TestLinkedListStack<Item> {
	int i=0,len;
	public LinkedListStack<Item> testStack() {
		LinkedListStack<Item> result = new LinkedListStack<>();
		System.out.println(result.toString());
		return result;
	}
	
	public int Size(LinkedListStack<Item> stack) {
		int size = stack.size();
		System.out.println(stack.toString()+" has size "+size);
		return size;
	}
	
	public void Incstack(LinkedListStack<Item> stack, Item item) {
		System.out.print(stack.toString()+" push("+item.toString()+") into ");
		stack.push(item);
		System.out.println(stack.toString());
	}	
	
	public void Decstack(LinkedListStack<Item> stack) {
		System.out.print(stack.toString()+" pop from ");
		stack.pop();//This method pushes value out of stack
		System.out.println(stack.toString());
	}	
	
	
	public TestLinkedListStack( Item[] testData) {
		System.out.println("Testing stack of integers:");
		LinkedListStack<Item> stack = testStack();
		Size(stack);
		for (Item item:testData) {
			System.out.println();
			Incstack(stack, item);//increments stack and stores the value
			Size(stack);			
		}
		
		for ( i=0, len = testData.length; i<len; i++) {
			System.out.println();
			Decstack(stack);//decrements stack
			Size(stack);				
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");	
		Integer[] array1 ={10, 4, 11, 6, 20, 11, 24};
		new TestLinkedListStack<>(array1);
	}

}
