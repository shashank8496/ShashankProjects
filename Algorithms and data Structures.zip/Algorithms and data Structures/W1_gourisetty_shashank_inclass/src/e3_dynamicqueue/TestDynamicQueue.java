package e3_dynamicqueue;
/*
 * @author Sai Shashank Gourisetty
 */
public class TestDynamicQueue<Item> {

	public DynamicQueue<Item> testQueueConstructor(int capacity) {
		DynamicQueue<Item> result = new DynamicQueue<>(capacity);
		System.out.println(result.toString());
		return result;
	}
	
	public int testSize(DynamicQueue<Item> queue) {
		int size = queue.size();
		System.out.println(" has size "+size);
		return size;
	}
	public int ts(DynamicQueue<Item> queue) {
		int size = queue.size();
		return size;
	}
	
	public void testEnqueue(DynamicQueue<Item> queue, Item item) {//to test queue when elements are added
		System.out.print(queue.toString()+" enqueue ("+item.toString()+")  ");
		queue.enqueue(item);
		System.out.println(queue.toString());
	}	
	
	public void testDequeue(DynamicQueue<Item> queue) {//to test queue when elements are removed
		System.out.print(queue.toString()+" dequeue to ");
		queue.dequeue();
		System.out.println(queue.toString());
	}	
	
	public TestDynamicQueue(String testTitle, Item[] testData) {
		System.out.println(testTitle);
		DynamicQueue<Item> queue= testQueueConstructor(0);
		testSize(queue);
		for (Item item:testData) {
			System.out.println();
			testEnqueue(queue, item);
			testSize(queue);			
		}
		for (int i=0, len = testData.length; i<len; i++) {
			System.out.println();
			testDequeue(queue);
			testSize(queue);				
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		Integer[] test1 = {1, 94, 31, 96, 0, 1, 24};
		new TestDynamicQueue<>("Test a queue of integers:", test1);
	}
}
