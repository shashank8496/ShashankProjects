package e3_dynamicqueue;
/**
 * 
 * @author Sai Shashank Gourisetty
 *
 */
public class DynamicQueue <Item>{
	private int capacity;
	public Item[] items;
	public int size;	
	@SuppressWarnings("unchecked")
	public DynamicQueue(int capacity) {
		if (capacity<0) {
			throw new RuntimeException("Invalid  capacity");
		}
		items = ((Item[])new Object[capacity]);
		size = 0;
	}
	
	@SuppressWarnings("unchecked")
	private void doubleCapacity() {
		// compute the new capacity
		int newCapacity = capacity * 2;
		if (newCapacity == 0) {
			newCapacity = 1;
		}
		// creates new items
		Item[] newItems = ((Item[])new Object[newCapacity]);
		// copy the current items to new items
		for (int i=0, len=size; i<len; i++) {
			newItems[i]=items[i];
		}

		capacity = newCapacity;
		items = newItems;
	}
	
	@SuppressWarnings("unchecked")
	private void halfCapacity() {
		// calculate the new capacity
		int newCapacity = capacity / 2;
		if (newCapacity == 0) {
			newCapacity = 1;
		}
		// create new items
		Item[] newItems = ((Item[])new Object[newCapacity]);
		// copy the current items
		for (int i=0; i<size; i++) {
			newItems[i]=items[i];
		}
		capacity = newCapacity;
		items = newItems;
	}	
	
	public void enqueue(Item item) {
		if (size>=(3*capacity)/4) {//checks for the current load and increases capacity if required
			doubleCapacity();
		}
		items[size++] = item;
	}
	
	public Item dequeue() {
		Item result = items[0];
		for (int i=0, len = size -1; i<len; i++) {
			items[i] = items [i+1];
		}
		size --;
		if (size<capacity/4) {//checks for the current load and decreases capacity if required
			halfCapacity();
		}
		return result;
	}
	
	public int size() {
		return size;
	}

	public String toString() {
		String result ="Queue(" + size + "/" + capacity + "):[";
		String sep = "";
		for (int i=0; i<size; i++) {
			Item item = items[i];
			result += sep + item.toString();
			sep = ", ";
		}
		result += "]";
		return result;
	}
		}
