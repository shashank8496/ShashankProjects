package e1_median;
/*
 * @author Sai Shashank Gourisetty
 */
public class Median {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("\n"+"Testcase 1:"+"median for 3 numbers ");
		int a[]={15,23,20};
		System.out.println("sorted Array is ");
		//Below median number function calculates median in an array
		mediannumber(a);
		System.out.println("\n"+"Testcase 2:"+"median for 3 numbers ");
		int b[]={315,123,22};
		System.out.println("sorted Array is ");
		mediannumber(b);
		System.out.println("\n"+"Testcase 3:"+"median for 3 numbers ");
		int c[]={0,3,1};
		System.out.println("sorted Array is ");
		mediannumber(c);
		System.out.println("\n"+"Testcase 4:"+"median for 3 numbers ");
		int d[]={1,5,10};
		System.out.println("sorted Array is ");
		mediannumber(d);
		System.out.println("\n"+"Testcase 5:"+"median for 3 numbers ");
		int e[]={31,13,122};
		System.out.println("sorted Array is ");
		mediannumber(e);
		}
// Method for calculating median, which takes input as array of 3 numbers
	public static int mediannumber(int number[]) {
		int temp;
		for (int i=0;i<3;i++)
		{
			for (int j=0;j<3-i-1;j++)
			{//Sorts the array in ascending order
				if (number[j] > number[j+1])
				{temp=number[j];
				number[j]=number[j+1];
				number[j+1]=temp;
			}}
			System.out.print(number[i]+" ");
		}
		System.out.println("\n"+"median is " +number[1]+"\n");
		return number[1];//return median
	}

}
