package e2_count;

import java.util.Arrays;

/**
 * 
 * @author Sai Shashank Gourisetty
 *
 */
public class CountCommonElements {
static void CommonNumbers(int array1[], int array2[]) 
{ 
   int m = array1.length; 
   int n = array2.length; 
  int i = 0, j = 0 ,count=0; 

  for(i=0;i<m;i++)//This for loops are used to compare two arrays 
  {
	  for(j=0;j<n;j++)
	  {
		  if(array1[i]==array2[j])
			  {
			  count++;
			  }
		  }
	  }
  System.out.println(count);
} 
  
public static void main(String args[]) 
{ 
	System.out.println("Test output produced by Sai Shashank Gourisetty");
    int array1[] = {1, 5, 9, 2, 4}; 
    int array2[] = {2, 3, 1, 4};
    System.out.println("common elements in the arrays are below");
    System.out.println("testcase 1:");
    System.out.println("First array is "+Arrays.toString(array1) + " and Second Array is "+Arrays.toString(array2));
    CommonNumbers(array1,array2);//This function compares two arrays 
    
    int array3[] = {15, 13, 251, 32, 8}; 
    int array4[] = {9,5,1,51,33,30,132}; 
    
    System.out.println("testcase 2:");
    System.out.println("First array is "+Arrays.toString(array3) + " and Second Array is "+Arrays.toString(array4));
    CommonNumbers(array3,array4); //This function compares two arrays
    
    int array5[] = {1,3,29,21}; 
    int array6[] = {3,4,25,127,8,13}; 
    System.out.println("testcase 3:");
    System.out.println("First array is "+Arrays.toString(array5) + " and Second Array is "+Arrays.toString(array6));
    CommonNumbers(array5, array6); //This function compares two arrays
    
    int array7[] = {11,2,35,6,3}; 
    int array8[] = {4,5,6,44,8,9,10}; 
    System.out.println("testcase 4:");
    System.out.println("First array is "+Arrays.toString(array7) + " and Second Array is "+Arrays.toString(array8));
    CommonNumbers(array7, array8);//This function compares two arrays
    
    int array9[] = {89,11,12,91,4,1}; 
    int array10[] = {54,-1,31,12,10,1}; 
    System.out.println("testcase 5:");
    System.out.println("First array is "+Arrays.toString(array9) + " and Second Array is "+Arrays.toString(array10));
    CommonNumbers(array9,array10);//This function compares two arrays
       } 

}