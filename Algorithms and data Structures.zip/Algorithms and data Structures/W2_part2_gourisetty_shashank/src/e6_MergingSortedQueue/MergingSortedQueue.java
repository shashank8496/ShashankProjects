package e6_MergingSortedQueue;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.LinkedList;
import java.util.Queue;
public class MergingSortedQueue {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Queue merge(Queue q1,Queue q2)
	{
		if(q1.isEmpty())
			return q2;
		if(q2.isEmpty())
			return q1;
		Queue q=new LinkedList();
		int length1=q1.size();
		int length2=q2.size();
		Double[] a1=new Double[length1];
		Double[] a2=new Double[length2];
		for(int i=0;i<a1.length;i++)//removes elements
		{
			a1[i]=(Double) q1.remove();
		}
		for(int i=0;i<a2.length;i++)
		{
			a2[i]=(Double) q2.remove();
		}
		int i=0,j=0;
		while(i<length1||j<length2)
		{//adds elements
			if(i>=length1)
				q.add(a1[j++]);
			else if (j>=length2)
				q.add(a2[i++]);
			else if(a1[i]<a2[j])
				q.add(a1[i++]);
			else
				q.add(a2[j++]);
		}
		return q;
	}
	public static void display(Queue<Double> q)//shows queue
	{
		for(Double i: q)
		{
			System.out.print(i +" ");
		}
		System.out.println();
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args)
	{
		int N=10;
		Queue q1=new LinkedList(); 	 	
		Queue q2=new LinkedList();
		for(int i=1;i<=N;i++)
		{
			q1.add((double)i*5);
			q2.add((double)i-i*8);
		}
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("first queue");
		display(q1);
		System.out.println("second queue");
		display(q2);
		System.out.println("sorted merged queues ");
		Queue q=merge(q1,q2);
		display(q);
		Queue a1=new LinkedList(); 	 	
		Queue a2=new LinkedList();
		for(int i=1;i<=N;i++)
		{
			a1.add((double)i*3);
			a2.add((double)i*10-i+4);
		}
		System.out.println("\nTest Case 2");
		System.out.println("First Queue:");
		display(a1);
		System.out.println("Second Queue:");
		display(a2);
		System.out.println("sorted merged queues");
		Queue a=merge(a1,a2);
		display(a);
		
		Queue b1=new LinkedList(); 	 	
		Queue b2=new LinkedList();
		for(int i=1;i<=N;i++)
		{
			b1.add((double)i*7);
			b2.add((double)i*3);
		}
		System.out.println("\nTest Case 3");
		System.out.println("First Queue:");
		display(b1);
		System.out.println("Second Queue:");
		display(b2);
		System.out.println("sorted merged queues ");
		Queue b=merge(b1,b2);
		display(b);
		
		Queue c1=new LinkedList(); 	 	
		Queue c2=new LinkedList();
		for(int i=1;i<=N;i++)
		{
			c1.add((double)i*14-i*2);
			c2.add((double)i*-21);
		}
		System.out.println("\nTest Case 4");
		System.out.println("First Queue:");
		display(c1);
		System.out.println("Second Queue:");
		display(c2);
		System.out.println("sorted merged queues");
		Queue c=merge(c1,c2);
		display(c);
		
		Queue d1=new LinkedList(); 	 	
		Queue d2=new LinkedList();
		for(int i=1;i<=N;i++)
		{
			d1.add((double)i*13);
			d2.add((double)i*-7);
		}
		System.out.println("\nTest Case5 ");
		System.out.println("First Queue:");
		display(d1);
		System.out.println("Second Queue:");
		display(d2);
		System.out.println("sorted merged queues");
		Queue d=merge(d1,d2);
		display(d);
	}
}