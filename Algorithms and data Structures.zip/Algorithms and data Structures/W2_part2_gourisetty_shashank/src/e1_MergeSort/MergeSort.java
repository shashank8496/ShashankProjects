package e1_MergeSort;
/*
 * @author Sai Shashank Gourisetty
 */
public class MergeSort {

	    private static void merge(Comparable[] a, Comparable[] aux, int low, int mid, int high) {
	        assert isSorted(a, low, mid);
	        assert isSorted(a, mid+1, high);

	        // copy to aux[]
	        for (int k = low; k <= high; k++) 
	            aux[k] = a[k]; 	        

	        // merge to a[]
	        int i = low, j = mid+1;
	        for (int k = low; k <= high; k++) {
	            if      (i > mid)              
	            	a[k] = aux[j++];
	            else if (j > high)               
	            	a[k] = aux[i++];
	            else if (less(aux[j], aux[i]))
	            	a[k] = aux[j++];
	            else
	            	a[k] = aux[i++];
	        }
	        assert isSorted(a, low, high);
	    }


	    public static void sort(Comparable[] a) {
	        Comparable[] aux = new Comparable[a.length];
	        sort(a, aux, 0, a.length-1);
	        assert isSorted(a);
	    }
	    private static boolean isSorted(Comparable[] a) {//checks for sort array
	        return isSorted(a, 0, a.length - 1);
	    }

	    private static boolean isSorted(Comparable[] a, int low, int high) {
	        for (int i = low + 1; i <= high; i++)
	            if (less(a[i], a[i-1])) 
	            	return false;
	        return true;
	    }
	    private static void sort(Comparable[] a, Comparable[] aux, int low, int high) {
	        if (high <= low) return;
	        int mid = low + (high - low) / 2;
	        sort(a, aux, low, mid);
	        sort(a, aux, mid + 1, high);
	        merge(a, aux, low, mid, high);
	    }

	    private static boolean less(Comparable v, Comparable w) {
	        return v.compareTo(w) < 0;
	    }
	    public static void sortbu(Comparable[] a) {
	        int n = a.length;
	        Comparable[] aux = new Comparable[n];
	        for (int len = 1; len < n; len *= 2) {
	            for (int low = 0; low < n-len; low += len+len) {
	                int mid  = low+len-1;
	                int high = Math.min(low+len+len-1, n-1);
	                merge(a, aux, low, mid, high);
	            }
	        }
	        assert isSorted(a);
	    }


	    private static void merge(Comparable[] a, int[] index, int[] aux, int low, int mid, int high) {

	        for (int k = low; k <= high; k++) {
	            aux[k] = index[k]; 
	        }

	        // merge to a[]
	        int i = low, j = mid+1;
	        for (int k = low; k <= high; k++) {
	            if      (i > mid)                   
	            	index[k] = aux[j++];
	            else if (j > high)                   
	            	index[k] = aux[i++];
	            else if (less(a[aux[j]], a[aux[i]]))
	            	index[k] = aux[j++];
	            else                         
	            	index[k] = aux[i++];
	        }
	    }
	    private static void sort(Comparable[] a, int[] index, int[] aux, int low, int high) {
	        if (high <= low) return;
	        int mid = low + (high - low) / 2;
	        sort(a, index, aux, low, mid);
	        
	        sort(a, index, aux, mid + 1, high);
	        
	        merge(a, index, aux, low, mid, high);
	        
	    }
	    public static int[] indexSort(Comparable[] a) {
	        int n = a.length;
	        int[] index = new int[n];
	        for (int i = 0; i < n; i++)
	            index[i] = i;

	        int[] aux = new int[n];
	        sort(a, index, aux, 0, n-1);
	        return index;
	    }
	    
	    private static void display(Comparable[] a) {//displays string
	        for (int i = 0; i < a.length; i++) {
	        	System.out.print(a[i]+" ");
	        }
	    }
	    public static void mergeSort(String[] names) {
	        if (names.length >= 2) {
	            String[] left = new String[names.length / 2];
	            String[] right = new String[names.length - names.length / 2];

	            for (int i = 0; i < left.length; i++) {
	                left[i] = names[i];
	            }

	            for (int i = 0; i < right.length; i++)
	            {
	                right[i] = names[i + names.length / 2];
	            }

	            mergeSort(left);
	            mergeSort(right);
	            merge(names, left, right);
	        }
	    }
		public static void merge(String[] names, String[] left, String[] right) {
	        int a = 0,b = 0;
	        for (int i = 0; i < names.length; i++) {
	            if (b >= right.length || (a < left.length && left[a].compareToIgnoreCase(right[b]) < 0)) {
	                names[i] = left[a];
	                a++;
	            } 
	            else 
	            {
	                names[i] = right[b];
	                b++;
	            }
	        }
	    }
	    public static void main(String[] args) {
	    	 String[] FirstName = {"S","H","A","S","H","A","N","K"};
	         String[] LastName = { "G","O","U","R","I","S","E","T","T","Y"};
	         String[] names = new String[FirstName.length + LastName.length];
	         System.out.println("Test output produced by Sai Shashank Gourisetty");
	         System.out.println("First name");
	         for (String First : FirstName) {
	             System.out.print(First);
	         }
	         System.out.println("\nLast name");
	         for (String last : LastName) {
	             System.out.print(last);
	         }
	         
	         mergeSort(FirstName);
	         mergeSort(LastName);
	         merge(names, FirstName, LastName);
	         mergeSort(names);
	         
	         System.out.println("\nMerged Sort");
	         for (String FullName : names) {
	             System.out.print(FullName);
	         }
	        String[] a = {"G","O","U","R","I","S","E","T","T","Y","S","H","A","S","H","A","N","K"};
	        
	        System.out.println("\nTop Down Approach");
	        MergeSort.sort(a);
	        display(a);
	        System.out.println();
	        System.out.println("\nBottom-Up Approach");
	        MergeSort.sortbu(a);
	        display(a);
	    }
}