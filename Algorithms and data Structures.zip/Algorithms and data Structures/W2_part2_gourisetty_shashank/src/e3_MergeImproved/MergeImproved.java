package e3_MergeImproved;
/*
 * @author Sai Shashank Gourisetty
 */
public class MergeImproved {
	private static final int CUTOFF = 5;  // cutoff to insertion sort
	private static void merge(Comparable[] a, Comparable[] aux, int low, int mid, int high) {
    assert isSorted(a, low, mid);
        assert isSorted(a, mid+1, high);
        int i = low, j = mid+1;
        for (int k = low; k <= high; k++) {
            if      (i > mid)            
            	aux[k] = a[j++];
            else if (j > high) 
            	aux[k] = a[i++];
            else if (less(a[j], a[i]))
            	aux[k] = a[j++];  
            else
            	aux[k] = a[i++];
        }
  
        assert isSorted(aux, low, high);
    }
    @SuppressWarnings("rawtypes")
	private static void sort(Comparable[] a, Comparable[] aux, int low, int high) {
   
        if (high <= low + CUTOFF) { 
            insertionSort(aux, low, high);
            return;
        }
        int mid = low + (high - low) / 2;
        sort(aux, a, low, mid);
        sort(aux, a, mid+1, high);

         if (!less(a[mid+1], a[mid])) {
           for (int i = low; i <= high; i++) aux[i] = a[i];
           return;
        }
        merge(a, aux, low, mid, high);
    }
    // compares two elements
    @SuppressWarnings({ "rawtypes", "unchecked" })
	private static boolean less(Comparable a, Comparable b) {
        return a.compareTo(b) < 0;
    }
    // sort using insertion sort
    @SuppressWarnings("rawtypes")
	private static void insertionSort(Comparable[] a, int low, int high) {
        for (int i = low; i <= high; i++)
            for (int j = i; j > low && less(a[j], a[j-1]); j--)
                exchange(a, j, j-1);
    }
    // exchange 
    private static void exchange(Object[] a, int i, int j) {
        Object swap = a[i];
        a[i] = a[j];
        a[j] = swap;
    }
    @SuppressWarnings("rawtypes")
	public static void sort(Comparable[] a) {
        Comparable[] aux = a.clone();
        sort(aux, a, 0, a.length-1);  
        assert isSorted(a);
    }
    //display array
    private static void display(Object[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]+" ");
        }
    }
    private static boolean isSorted(Comparable[] a, int low, int high) {
        for (int i = low + 1; i <= high; i++)
            if (less(a[i], a[i-1]))
            	return false;
        return true;
    }
    private static boolean isSorted(Comparable[] a) {
        return isSorted(a, 0, a.length - 1);
    }
   
    public static void main(String[] args) { 	
    
        String[] a = {"S","A","I","S","H","A","S","H","A","N","K"};
        System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("Test Case 1");
        for (int i = 0; i < a.length; i++)
        {
			System.out.print(a[i]+" ");
			}
        System.out.println("After improvement");
        MergeImproved.sort(a);
        display(a);
        
    System.out.println("\nTest Case 2");
    System.out.println("Input cars");
    String[] b = {"c","a","r","s"};
    MergeImproved.sort(b);
    display(b);
    System.out.println("\nTest Case 3");

    System.out.println("Input Atlanta");
    String[] c = {"a","t","l","a","n","t","a"};
    MergeImproved.sort(c);
    display(c);
    System.out.println("\nTest Case 4");
    System.out.println("Input ohio");
    String[] d = {"o","h","i","o"};
    MergeImproved.sort(d);
    display(d);
    System.out.println("\nTest Case 5");
    System.out.println("Input mason");
    String[] e = {"m","a","s","o","n"};
    MergeImproved.sort(e);
    display(e);
}
}
