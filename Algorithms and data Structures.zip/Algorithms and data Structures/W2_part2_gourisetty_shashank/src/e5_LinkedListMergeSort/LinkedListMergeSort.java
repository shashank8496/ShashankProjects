package e5_LinkedListMergeSort;
/*
 * @author Sai Shashank Gourisetty
 */
public class LinkedListMergeSort {

	node head = null;
   static class node  
    { 
        int value; 
        node next; 
        public node(int value)  
        { 
            this.value = value; 
        } 
    } 
      
   public node Merge(node a, node b)  
    { 
        node result = null; 
        if (b == null) 
            return a;
		if (a == null) 
            return b;
        if (a.value <= b.value)  
        { 
            result = a; 
            result.next = Merge(a.next, b); 
        }  
        else 
        { 
            result = b; 
            result.next = Merge(a, b.next); 
        } 
        return result; 
      } 
  
   public node gMiddle(node h)  
    { 
        //Base case 
        if (h == null) 
            return h; 
        node fp = h.next; 
        node sp = h; 
          
        while (fp != null) 
        { 
            fp = fp.next; 
            if(fp!=null) 
            { 
                sp = sp.next; 
                fp=fp.next; 
            } 
        } 
        return sp; 
    } 
   
   public node mergeSort(node h)  
    {  
        if (h == null || h.next == null) 
        { 
            return h; 
        } 
  
        // middle of the list 
        node middle = gMiddle(h); 
        node nextofmiddle = middle.next; 
        middle.next = null; 
  
        // Sort left list 
        node left = mergeSort(h); 
  
        // Sort right list 
        node right = mergeSort(nextofmiddle); 
  
        // Merge left and right lists 
        node sortedlist = Merge(left, right); 
        return sortedlist; 
    } 
   public void push(int newdata)  
    { 
        node newnode = new node(newdata);  
        newnode.next = head; 
        head = newnode; 
    } 
  
    //  Display list
  public  void display(node hr)  
    { 
        while (hr != null)  
        { 
            System.out.print(hr.value + " "); 
            hr = hr.next; 
        } 
    } 
      
    public static void main(String[] args)  
    { 
  
    	LinkedListMergeSort l = new LinkedListMergeSort(); 
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        System.out.println("\nTest case 1");
        l.push(21); 
        l.push(0); 
        l.push(-55); 
        l.push(99); 
        l.push(31); 
        l.push(6);
        System.out.println("Original Linked List is"); 
        l.display(l.head); 
  
        // merge Sort 
        l.head = l.mergeSort(l.head); 
        System.out.print("\nSorted Linked List is: \n"); 
        l.display(l.head); 
        LinkedListMergeSort l1 = new LinkedListMergeSort(); 
        System.out.println("\nTest case 2");
        l1.push(-100); 
        l1.push(-51); 
        l1.push(6); 
        l1.push(71); 
        l1.push(11); 
        l1.push(23); 
        System.out.println("Original Linked List is");  
        l1.display(l1.head); 
  
        // Apply merge Sort 
        l1.head = l1.mergeSort(l1.head); 
        System.out.print("\nSorted Linked List is: \n"); 
        l1.display(l1.head); 
        LinkedListMergeSort l3 = new LinkedListMergeSort(); 

        System.out.println("\nTest case 3");
        l3.push(-91); 
        l3.push(-245); 
        l3.push(-88); 
        l3.push(66); 
        l3.push(-1); 
        l3.push(29); 

        System.out.println("Original Linked List is");  
        l3.display(l3.head); 
  
        l3.head = l3.mergeSort(l3.head); 
        System.out.print("\nSorted Linked List is: \n"); 
        l3.display(l3.head); 
        LinkedListMergeSort l4 = new LinkedListMergeSort(); 
        System.out.println("\nTest case 4");
        l4.push(-66); 
        l4.push(-2); 
        l4.push(-4); 
        l4.push(-100); 
        l4.push(-33); 
        l4.push(27); 

        System.out.println("Original Linked List is");  
        l4.display(l1.head); 
  
        l4.head = l4.mergeSort(l4.head); 
        System.out.print("\nSorted Linked List is: \n"); 
        l4.display(l4.head); 
        
        LinkedListMergeSort l5 = new LinkedListMergeSort();
        System.out.println();
        System.out.println("\nTest case 5");
        l5.push(10); 
        l5.push(-24); 
        l5.push(-86); 
        l5.push(100); 
        l5.push(99); 
        l5.push(52); 
        System.out.println("Original Linked List is"); 
        l5.display(l5.head); 
  
        // Apply merge Sort 
        l5.head = l5.mergeSort(l5.head); 
        System.out.print("\nSorted Linked List is: \n"); 
        l5.display(l5.head); 
    } 
}