package e4_Naturalmergesort;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.Stopwatch;
/*
 * @author Sai Shashank Gourisetty
 */
public class NaturalMergeSort {
	private static void merge(Comparable[] array,Comparable[] aux,int lo,int mid,int high)
	{
		int i=lo;
		int j=mid+1;
		for(int k=0;k<=high;k++)
		{
			aux[k]=array[k];
		}
		for(int k=lo;k<=high;k++)
		{
			if(i>mid)
				array[k]=aux[j++];
			else if(j>high)
				array[k]=aux[i++];
			else if(less(aux[i],aux[j]))
				array[k]=aux[i++];
			else
				array[k]=aux[j++];
		}
	}

private static boolean less(Comparable a,Comparable b)
{
	return a.compareTo(b)<0;
}
	@SuppressWarnings("rawtypes")
	public static void sort(Comparable[] array)
	{
		Comparable[] aux=new Comparable[array.length];
		int high=0,mid=0;
		while(true)
		{
			int i=0;
			while(less(array[i],array[i+1])&&i<array.length-2)
				i++;
			mid=i;
			if(mid==array.length-1)
				break;
			if(mid==array.length-2)
			{
				merge(array,aux,0,mid,array.length-1);
				return ;
				
			}
			int j=mid+1;
			while(less(array[j],array[j+1])&&j<array.length-2)
				j++;
			high=j;
			merge(array,aux,0,mid,high);
		}
	}

private static boolean isSorted(Comparable[] a)
{//checks if array is sorted
	for(int i=1;i<=a.length;i++)
		if(less(a[i],a[i-1]))
			return false;
	return true;
}

public static void main(String[] args)
{
	int size=15;
	System.out.println("Test output produced by Sai Shashank Gourisetty");
	System.out.println("array size\tno of sorted elements\t  time\tratio");
	double percent=0.0001;
	double prev=0.0;
	for(int N=size;true;N+=N)
	{
		for(double i=percent;i<1;i+=1)
		{
			Comparable[] array=new Comparable[N];
			int breakpoint=(int)Math.round(i*N);
			for(int j=0;j<breakpoint;j++)
			{
				array[j]=new Double(j);
			}
			for(int j=breakpoint;j<N;j++)
			{
				array[j]=StdRandom.uniform();
			}
			Stopwatch sw=new Stopwatch();
			sort(array);
			double tim=sw.elapsedTime();
			if(prev==0)
				System.out.printf("%8d\t%8d\t\t"+"%4.3f\t--\n",N,breakpoint,tim);
			else
				System.out.printf("%9d\t%9d\t\t"+"%4.3f\t%2.3f\n",N,breakpoint,tim,tim/prev);
			assert(isSorted(array));
			prev=tim;
		}
	}
}
}