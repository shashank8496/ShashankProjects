package e2_MergeFaster;
import java.util.Arrays;
/*
 * @author Sai Shashank Gourisetty
 */
public class MergeFaster {
	private static void merge(int[] a) {
		int ArrayLength = a.length; //length of the the array
		int aux[] = new int[a.length/2];		
		aux = Arrays.copyOfRange(a, a.length/2, ArrayLength);		//Copying second half of array
		Arrays.sort(aux);//sorting 
		for(int i = aux.length - 1, j = a.length/2; j <= ArrayLength - 1; i--, j++) 
		a[j] = aux[i];//Copying aux array to a in reverse order
		}
		public static void main(String[] args) {
			int[] m = {34,1, 51,6,6,179, 0};
			System.out.println("Test output produced by Sai Shashank Gourisetty");
			System.out.println("Test case 5");
			System.out.println("Original array is "+Arrays.toString(m));
			merge(m);//Calling merge function and passing array a
			System.out.println("After faster mergesort "+Arrays.toString(m));
			}
}