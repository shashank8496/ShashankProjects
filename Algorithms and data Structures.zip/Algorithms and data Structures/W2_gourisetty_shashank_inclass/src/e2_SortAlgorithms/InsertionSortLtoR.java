package e2_SortAlgorithms;
/**
 * @author Sai Shashank Gourisetty
 *
 */
import java.util.Arrays;

public class InsertionSortLtoR {
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 1:");
		int a[]={7,1,0,3};
		Sort(a);//sort the array using insertion method
		
	}
	static void Sort(int[] a) {
		 int length=a.length,temp=0;
			for(int i=0;i<length;i++)
			{System.out.println("array trace "+Arrays.toString(a));
				for(int j=i;j>0;j--)
				{
				if(a[j]<a[j-1])
				{
				temp=a[j];//swapping
					a[j]=a[j-1];
					a[j-1]=temp;
				}
			}	
		}
		System.out.println("array is "+Arrays.toString(a));		
	}
}
