package e2_SortAlgorithms;
import java.util.Arrays;
/**
 * @author Sai Shashank Gourisetty
 *
 */
public class SelectionSortLtoR {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 1:");
		int a[]={94,96,7,1,0,10,3};
		Sort(a);//sorts the given array
	}

	 static void Sort(int[] a) {
		 int length=a.length,temp=0;
		for(int i=0;i<length;i++)
		{
			System.out.println("array trace "+Arrays.toString(a));
		int index=i;
			for(int j=i+1;j<length;j++)
			{
				if(a[index]>a[j])
				{ index=j;//stores the next possible value
					
				}
			}	temp=a[i];//swapping
			a[i]=a[index];
			a[index]=temp;
		}
		System.out.println("array is "+Arrays.toString(a));	
	}
}
