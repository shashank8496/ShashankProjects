package e2_SortAlgorithms;
import java.util.Arrays;
/**
 * @author Sai Shashank Gourisetty
 */
public class SelectionSortRtoL {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Testcase 4:");
		int a[]={0,6,21,9,8,2,58};
		Sort(a);//sort the array using insertion method
	}

	 static void Sort(int[] a) {
		 int length=a.length,temp=0;
		for(int i=length-1;i>0;i--)
		{
			System.out.println("array trace "+Arrays.toString(a));
			int index=i;
			for(int j=i-1;j>=0;j--)
			{
				if(a[index]>a[j])
				{ 
					index=j;//stores the next possible value
				}
			}
				temp=a[i];//swapping
				a[i]=a[index];
				a[index]=temp;
			}	
		System.out.println("array is "+Arrays.toString(a));		}
	}