package e1_SortedArray;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Arrays;
public class SortedArray {
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("\n"+"Testcase 5: Is Array sorted? ");
		int array[]={-1,0,1,2,9};
		int length=array.length;
		int result;
		System.out.println("Given array is "+Arrays.toString(array));
		result=SortStatus(array,length);
		if(result==1)//returns 1 if array is sorted
			System.out.println("Array is sorted");
		else
			System.out.println("Array is not sorted");
	}

	 static int SortStatus(int[] array,int length) {//functions checks whether the array is sorted or not
		 
		 if(length==0||length==1)
			 return 1;
		if(array[length-1]<array[length-2])//checks if any previous element is greater than next element 
			return 0;
		 return SortStatus(array,length-1);
	 }
}