package e4_QuickSort3way;
/*
 * @author Sai Shashank Gourisetty
 */
import edu.princeton.cs.algs4.StdRandom;
public class Quick3string {

	private static final int CUTOFF =  15;   // cutoff to insertion sort  
    private static int charAt(String s, int d) { 
        assert d >= 0 && d <= s.length();
        if (d == s.length()) return -1;
        return s.charAt(d);
    }
    private Quick3string() { } 

    public static void sort(String[] a) {    //ascending order.
        StdRandom.shuffle(a);
        sort(a, 0, a.length-1, 0);
        assert isSorted(a);
    }
   
    private static void sort(String[] a, int lo, int hi, int d) { 
        if (hi <= lo + CUTOFF) {
            insertion(a, lo, hi, d);
            return;
        }

        int lt = lo, gt = hi;
        int v = charAt(a[lo], d);
        int i = lo + 1;
        while (i <= gt) {
            int t = charAt(a[i], d);
            if      (t < v) exch(a, lt++, i++);
            else if (t > v) exch(a, i, gt--);
            else              i++;
        }
        sort(a, lo, lt-1, d);
        if (v >= 0) sort(a, lt, gt, d+1);
        sort(a, gt+1, hi, d);
    }

    private static void insertion(String[] a, int lo, int hi, int d) {
        for (int i = lo; i <= hi; i++)
            for (int j = i; j > lo && less(a[j], a[j-1], d); j--)
                exch(a, j, j-1);
    }
   
    private static boolean less(String v, String w, int d) {
        assert v.substring(0, d).equals(w.substring(0, d));
        for (int i = d; i < Math.min(v.length(), w.length()); i++) {
            if (v.charAt(i) < w.charAt(i)) return true;
            if (v.charAt(i) > w.charAt(i)) return false;
        }
        return v.length() < w.length();
    }

    private static boolean isSorted(String[] a) {
        for (int i = 1; i < a.length; i++)
            if (a[i].compareTo(a[i-1]) < 0) return false;
        return true;
    }
    // exchange
    private static void exch(String[] a, int i, int j) {
        String temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    public static void main(String[] args) {
    	System.out.println("Test output produced by Sai Shashank Gourisetty");
        String[] a = {"georg","mason","unive","rsity","unity"};
        String[] b=  {"a","bb","ccc","dddd","eeeeee"};
        String[] c= {"a6","b3","c8","a1","b9"};
        String[] d= {"as0","as1","as3","as2","as6"};
        String[] e= {"retry","dfsd7","tyuk","kl","1234"};
        
        sort(a);
        System.out.println("Testcase 1");
        for (int i = 0; i < a.length; i++)
            System.out.println(a[i]);
        
        System.out.println("\nTestcase 2");
        sort(b);
        for (int j = 0; j < b.length; j++)
            System.out.println(b[j]);
        
        System.out.println("\nTestcase 3");
        sort(c);
        for (int k = 0; k < c.length; k++)
            System.out.println(c[k]);
        
        System.out.println("\nTestcase 4");
        sort(d);
        for (int l = 0; l < d.length; l++)
            System.out.println(d[l]);
        
        System.out.println("\nTestcase 5");
        sort(e);
        for (int m = 0; m < e.length; m++)
            System.out.println(e[m]);
    }
}