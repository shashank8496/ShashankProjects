package e1_KeyIndexedCounting;
/*
 * @author Sai Shashank Gourisetty
 */
public class KeyIndexedCounting {

	public static void sort(String[] a, int W)
	{ // Sorting
	int N = a.length;
	int R = 256;
	String[] aux = new String[N];
	for (int d = W-1; d >= 0; d--)
	{ 
	int[] count = new int[R+1]; // frequency counts
	for (int i = 0; i < N; i++)
	count[a[i].charAt(d) + 1]++;
	for (int r = 0; r < R; r++) 
	count[r+1] += count[r];
	for (int i = 0; i < N; i++) 
	aux[count[a[i].charAt(d)]++] = a[i];
	for (int i = 0; i < N; i++) // Copy to a.
	a[i] = aux[i];
	}
	}
	
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		String[] str  = new String[5];
		String[] str2 = new String[5];
		String[] str3 = new String[5];
		String[] str4 = new String[5];
		String[] str5 = new String[5];
		str[0]="4ABCD8";str[1]="2UY980";str[2]="3JU120";str[3]="1IAK50";str[4]="1OA345";
		sort(str , 6);
		System.out.println("Testcase 1: ");
		for(int i = 0 ; i < str.length ; i++)
			System.out.println(str[i]);
		
		str2[0]="2UY1T98";str2[1]="1I1K150";str2[2]="3I1Q710";str2[3]="2ORE110";str2[4]="OX1V985";
		sort(str2 , 7);
		System.out.println("\nTestcase 2: ");
		for(int i = 0 ; i < str.length ; i++)
			System.out.println(str2[i]);

		str3[0]="3QIQ7101";str3[1]="2UYT988";str3[2]="3CTW123";str3[3]="AQ14E2";str3[4]="61NJSA";
		sort(str3 , 6);
		System.out.println("\nTestcase 3 ");
		for(int i = 0 ; i < str.length ; i++)
			System.out.println(str3[i]);

		str4[0]="91C";str4[1]="ZY4";str4[2]="USD";str4[3]="IND";str4[4]="61A";
		sort(str4 , 3);
		System.out.println("\nTestcase 4 ");
		for(int i = 0 ; i < str.length ; i++)
			System.out.println(str4[i]);

		str5[0]="109G";str5[1]="QQ1R";str5[2]="AQC4";str5[3]="01D3";str5[4]="AA0X";
		sort(str5 , 4);
		System.out.println("\nTestcase 5 ");
		for(int i = 0 ; i < str.length ; i++)
			System.out.println(str5[i]);

	}
}