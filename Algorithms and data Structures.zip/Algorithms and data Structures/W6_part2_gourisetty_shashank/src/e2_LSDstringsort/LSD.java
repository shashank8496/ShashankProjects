package e2_LSDstringsort;
/*
 * @author Sai Shashank Gourisetty
 */
public class LSD {

	private static final int BITS_PER_BYTE = 8;
    private LSD() { }
    public static void sort(String[] a, int w) 
    {
        int n = a.length;
        int R = 256;   
        String[] aux = new String[n];

        for (int d = w-1; d >= 0; d--) 
        {
            int[] count = new int[R+1];
            for (int i = 0; i < n; i++)
                count[a[i].charAt(d) + 1]++;
            for (int r = 0; r < R; r++)
                count[r+1] += count[r];
           
            for (int i = 0; i < n; i++)
                aux[count[a[i].charAt(d)]++] = a[i];
            
            for (int i = 0; i < n; i++)
                a[i] = aux[i];
        }
    }

    public static void sort(int[] a) {
        final int BITS = 32;                 
        final int R = 1 << BITS_PER_BYTE;   
        final int MASK = R - 1;              
        final int w = BITS / BITS_PER_BYTE; 
        int n = a.length;
        int[] aux = new int[n];

        for (int d = 0; d < w; d++) {         

            int[] count = new int[R+1];
            for (int i = 0; i < n; i++) {           
                int c = (a[i] >> BITS_PER_BYTE*d) & MASK;
                count[c + 1]++;
            }
            
            for (int r = 0; r < R; r++)
                count[r+1] += count[r];
            
            if (d == w-1) {
                int shift1 = count[R] - count[R/2];
                int shift2 = count[R/2];
                for (int r = 0; r < R/2; r++)
                    count[r] += shift1;
                for (int r = R/2; r < R; r++)
                    count[r] -= shift2;
            }
            
            for (int i = 0; i < n; i++) {
                int c = (a[i] >> BITS_PER_BYTE*d) & MASK;
                aux[count[c]++] = a[i];
            }
            
            for (int i = 0; i < n; i++)
                a[i] = aux[i];
        }
    }
public static void main(String[] args) {
	System.out.println("Test output produced by Sai Shashank Gourisetty");
    	
        String[] a= {"georg","mason","unive","rsity","unity"};
        String[] b= {"sais","shas","gour","sett","gout"};
        String[] c= {"t5","s1","x1","y2","z3"};
        String[] d= {"a6","b3","c8","a1","b9"};
        String[] e= {"ind1","6us9","2chi5","9aus","3can"};
    	
    	int n = 5;
System.out.println("Testcase 1");
        // check strings have fixed length
        int w = a[0].length();
        for (int i = 0; i < n; i++)
        {
        	if(a[i].length()==w)
        	{
        	sort(a,w);
        		System.out.println(a[i]);
        	}
        	else
        		System.out.println("Strings are of unequal length");
        }
        System.out.println("Testcase 2");
        int w1 = b[0].length();
	        for (int j= 0; j < n; j++)
	        {
	        	if(b[j].length()==w1)
	        	{
	        	sort(b,w1);
	        		System.out.println(b[j]);
	        	}
	        	else
	        		System.out.println("Strings are of unequal length");
	        }
	        System.out.println("Testcase 3");
	        int w2 = c[0].length();
		        for (int k= 0; k< n; k++)
		        {
		        	if(c[k].length()==w2)
		        	{
		        	sort(c,w2);
		        		System.out.println(c[k]);
		        	}
		        	else
		        		System.out.println("Strings are of unequal length");
		        }
		        System.out.println("Testcase ");
		        int w3 = d[0].length();
			        for (int l= 0; l< n; l++)
			        {
			        	if(d[l].length()==w3)
			        	{
			        	sort(d,w3);
			        		System.out.println(d[l]);
			        	}
			        	else
			        		System.out.println("Strings are of unequal length");
			        }
			        System.out.println("Testcase 5");
			        int w4 = e[0].length();
				        for (int m= 0; m < n; m++)
				        {
				        	if(e[m].length() == w4)
				        	{
				        	sort(e,w4);
				        		System.out.println(e[m]);
				        	}
				        	else
				        		System.out.println("Strings are of unequal length");
				        }       
}
}