package e1_Sort;
import java.util.Arrays;
import java.util.Scanner;
/*
 * @author Sai Shashank Gourisetty
 */
public class Sort {

	public static void insertionsort(Comparable[] a)
	{
		for(int i=1;i<a.length;i++)
		{System.out.println("Step " +i+": "+Arrays.toString(a));
			for(int j=i;j>0 && less(a[j],a[j-1]);j--)
				swap(a,j,j-1);
		}
	}
  
	//Searches minimum element in the list and Swap with value
	public static void selectionsort(Comparable[] a)
	{	
		for(int i=0;i<a.length;i++)
		{System.out.println("Step " +i+": "+Arrays.toString(a));
			int min=i; 
			for(int j=i+1;j<a.length;j++)
				if(less(a[j],a[min]))
					min=j;
			swap(a,i,min);//exchange present element  with smallest entry 
		}
	}
	//Divide list into small sub list of h equal interval and sorts this groups using insertion sort
	public static void shellsort(Comparable[] a)
	{
		int N=a.length;
		int h=1; //initializing h
		while(h<N/3)
			h=3*h+1;
		while(h>=1)
		{
			for(int i=h;i<N;i++) 
			{System.out.println(Arrays.toString(a));
				for(int j=i;j>=h && less(a[j],a[j-h]); j-=h) //till last element in the list 
					swap(a,j,j-h);
			}
			h=h/3;
		}
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static boolean less(Comparable v,Comparable w)
	{
		return v.compareTo(w)<0;
	}
	@SuppressWarnings("rawtypes")
	public static void swap(Comparable[] a,int i,int j)//exchange of elements
	{
		Comparable t=a[i];
		a[i]=a[j];
		a[j]=t;
	} 
	@SuppressWarnings("rawtypes")
	public static void display(Comparable[] a)//displays array
	{
		for (int i=0;i<a.length;i++)
			System.out.print(a[i] + " ");
	}
	@SuppressWarnings("rawtypes")
	public static boolean issorted(Comparable[] a)
	{
		for(int i=1;i<a.length;i++)
			if(less(a[i],a[i-1]))
				return false;
				return true;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		System.out.println("Test case ");
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the size of array:");
		int num=input.nextInt();
		String[] a= new String[num];
		String[] b= new String[num];
		String[] c= new String[num];
		System.out.println("Enter the string that to be sorted");
		for(int i=0;i<a.length;i++)
		{
			a[i]=input.next();
		}
		System.out.println("The given string is");
		display(a);
		
	    System.out.println("\nINSERTION SORT");
		insertionsort(a);
		assert issorted(a);
		display(a);
		
		System.out.println("\nSELECTION SORT");
		System.out.println("Enter the string that to be sorted");
		for(int i=0;i<b.length;i++)
		{
			b[i]=input.next();
		}
		selectionsort(b);
		assert issorted(b);
		display(b);
		
		System.out.println("\nSHELL SORT");
		System.out.println("Enter the string that to be sorted");
		for(int i=0;i<c.length;i++)
		{
			c[i]=input.next();
		}
		shellsort(c);
		assert issorted(c);
		display(c);
	}
}