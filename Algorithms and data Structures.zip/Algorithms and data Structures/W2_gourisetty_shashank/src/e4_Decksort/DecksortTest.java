package e4_Decksort;
/*
 * @author Sai Shashank Gourisetty
 */
public class DecksortTest {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
    	Decksort deck = new Decksort();
        
        System.out.println("Test case 1");
        System.out.println("The original deck:\n" + deck.toString());
        System.out.println("Exchange 7 & 12 cards");
        deck.exchange(7, 12);
        deck.display();
     
        System.out.println("Test case 2");
        System.out.println("After 11 exchanges in a shuffle:");
        deck.shuffle(11);
        System.out.println("Deck status");
        deck.display();
        System.out.println("12th Card: " + deck.getCard(11).toString());
        System.out.println("After sortfacedown method");
        deck.sortFaceDown();
        deck.display();
       
        System.out.println("Test case 3");
        System.out.println("21th Card: " + deck.getCard(20).toString());
        System.out.println("After Selection sort");
        deck.selectionSort();
        deck.display();
        
        System.out.println("Test case 4");
        System.out.println("32nd Card: " + deck.getCard(31).toString());
        System.out.println("After 2 exchanges in a shuffle");
        deck.shuffle(2);
        System.out.println("Deck status");
        deck.display();
        System.out.println("After Insertion sort");
        deck.insertionSort();
        deck.display();

        System.out.println("Test case 5");
        System.out.println("12th Card: " + deck.getCard(11).toString());
        System.out.println("After Shell sort");
        deck.shellSort();
        deck.display();
    }
}
