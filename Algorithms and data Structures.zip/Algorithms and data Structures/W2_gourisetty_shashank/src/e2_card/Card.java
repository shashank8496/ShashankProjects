package e2_card;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Random;
@SuppressWarnings("rawtypes")
public class Card implements Comparable {
    int suit, rank;
public Card(String Suit, String Rank)  
{
	String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    
    // Calculates index of cards
    for(int i = 0; i < Ranks.length; i++) {
        if(Ranks[i].equalsIgnoreCase(Rank)) {
            this.rank = i;
            break;
        }
    }
    // Calculates suit number from Suit    
    switch(Suit){
case "diamonds":
	this.suit = 0;
	break;
case "clubs":
	this.suit = 1;
	break;
case "hearts":
	this.suit = 2;
	break;
case "spades":
	this.suit = 3;
	break;
    }
}

//to get suit 
public int getSuit() {
    return this.suit;
}
//to get rank 
public int getRank() {
    return this.rank;
}

public String toString() {
    String suitName, CardRank;
    String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
    String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    
    suitName = Suits[this.suit]; // suit name of card
    CardRank = Ranks[this.rank];// rank of card
    
    return CardRank + " of " + suitName;
}

public void display() 
{
    System.out.println(this.toString());
}

@Override
public int compareTo(Object crd) {//compares two cards
    int result = 0;

    if(this.rank < ((Card)crd).getRank()) 
        result = -1;
    else if(this.rank > ((Card)crd).getRank()) 
        result = 1;
    else if(this.rank == ((Card)crd).getRank()) {
        if(this.suit < ((Card)crd).getSuit())
            result = -1;
        else if(this.suit > ((Card)crd).getSuit())
            result = 1;
        else if(this.suit == ((Card)crd).getSuit())
            result = 0;
    }
    return result;
}
//Generates random cards
public static Card generateCard() {
    Random rnd = new Random();  // generates random integer 
    String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
    int rank, suit;
    
    rank = rnd.nextInt(13);//Generate random rank and suit indices
    suit = rnd.nextInt(4);
    
    Card randomCard = new Card(Suits[suit], Ranks[rank]);    // new card generated
    return randomCard;
}
}