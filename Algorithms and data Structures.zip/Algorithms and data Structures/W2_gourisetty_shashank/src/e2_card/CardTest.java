package e2_card;
/*
 * @author Sai Shashank Gourisetty
 */
public class CardTest {
	public static void main(String args[]) 
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
    	//Calculates rank and suit of a spades K
        Card DeckCard = new Card("spades", "9");
        System.out.println("Test case 1 ");
        System.out.println("Rank: " + DeckCard.getRank()+"\nSuit: " + DeckCard.getSuit());

        //Generate random card and get suit and rank of the card
        Card DeckCard3 = Card.generateCard();
        System.out.println("\nTest case 2 ");
        System.out.println("Rank: " + DeckCard3.getRank()+"\nSuit: " + DeckCard3.getSuit());

        System.out.print("Card: ");
        DeckCard3.display();
        
        Card DeckCard1 = Card.generateCard();        //Generates random card
        System.out.println("\nTest case 3 ");
        System.out.println("performing the testcase by generatng a random card");
        System.out.println("Rank: " + DeckCard1.getRank()+"\nSuit: " + DeckCard1.getSuit());
        System.out.println("Card: " + DeckCard1.toString());

        System.out.println("\nTestcase 4 " );        //Compare test case 1 & 2
        System.out.println("Compare case 1 and case 2" );
        if(DeckCard3 .compareTo(DeckCard) < 0)
            System.out.println("First card is greater");
        else if(DeckCard3.compareTo(DeckCard) > 0)
            System.out.println("Second card is greater");
        else
            System.out.println("Both cards are equal");

        Card DeckCard2 = new Card("Diamonds","A"); //fetching the rank and suit of Diamonds A
        System.out.println("\nTest case 5 ");
        System.out.println("Rank: " + DeckCard2.getRank()+"\nSuit: " + DeckCard2.getSuit());
        System.out.print("Card: ");
        DeckCard2.display();
        System.out.println();        
    }
}
