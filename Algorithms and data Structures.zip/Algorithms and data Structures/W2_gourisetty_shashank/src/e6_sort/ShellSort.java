package e6_sort;
/*
 * @author Sai Shashank Gourisetty
 */
public class ShellSort {

	public static int Count = 0;
	// Sorting array 
	public static int sort(int array[]) 
	{
		int h= array.length,j,temp;
		Count = 0;
		for (int g = h / 2; g > 0; g= g/2) {
			for (int i = g; i < h; i =i+ 1) {
				temp = array[i];
				for (j = i; j >= g && array[j - g] > temp; j =j - g)
				{
					array[j] = array[j - g];
					Count++;
				}
				array[j] = temp;
			}
		}
		return 0;
	}
}