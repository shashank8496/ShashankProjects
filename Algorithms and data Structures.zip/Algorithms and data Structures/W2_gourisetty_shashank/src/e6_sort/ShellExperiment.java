package e6_sort;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Random;
public class ShellExperiment {

	public static void main(String[] args) 
    
	{
		System.out.println("Test output produced by Sai Shashank Gourisetty");
		shellSortB(100000, 5);
		Sort.DisplayOut();
	}
	
	public static void shellSortB(int amount, int threshold)
	{
		Sort.RankT(threshold);
		Sort result;
		int[] unSorted;
		int array[] = generateArray(111);
		for(int i = 0; i < amount; i++)
		{
			shuffle(array);
			unSorted = array.clone();
			ShellSort.sort(array);
			result = new Sort(unSorted.clone(), array.clone(), ShellSort.Count);
			Sort.Rank(result);
		}
	}
	
	public static int[] generateArray(int size)
	{
		int[] array = new int[size];
		
		for (int i=0; i<array.length; i++)
			array[i] = i+1;
		
		shuffle(array);	
		return array;
	}
	
	public static void shuffle(int[] array)
	{
		Random rnd = new Random();  // Generate random number			
		int j,temp;
		for (int i=0; i<array.length; i++) 
		{
		    j= rnd.nextInt(array.length);
		    temp = array[i];//swap
		    array[i] = array[j];
		    array[j] = temp;
		}
	}
}