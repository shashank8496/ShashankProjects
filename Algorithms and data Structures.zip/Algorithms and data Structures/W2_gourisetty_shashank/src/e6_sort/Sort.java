package e6_sort;
/*
 * @author Sai Shashank Gourisetty
 */
public class Sort {
	 int[] unsorted;
	 int[] sorted;
	 int cc;
	 static Sort[] hc;
	 static Sort[] lc;
	 static int range,rankcount;

		public Sort(int[] unsorted, int[] sorted, int cc) {//constructor
			this.unsorted = unsorted;
			this.sorted = sorted;
			this.cc = cc;
		}


		public static void Rank(Sort result) {
			for (int i = 0; i <= rankcount && i<range; i++) {
				if (hc[i] == null || result.cc > hc[i].cc) {
					rankshift(result, i, true);
					break;
				}
			}

			for (int i = 0; i <= rankcount && i<range; i++) {
				if (lc[i] == null || result.cc < lc[i].cc) {
					rankshift(result, i, false);
					break;
				}
			}
			rankcount++;
		}

		public static void RankT(int r) {
			hc = new Sort[r];
			lc = new Sort[r];
			Sort.range = r;
		}
		private static void rankshift(Sort result, int index, boolean highest) {
			Sort temp;
			Sort cur = result;
			if (highest) 
			{
				for (int i = index; i < range; i++) {
					temp = hc[i];
					hc[i] = cur;
					cur = temp;
				}
			}
			else
			{
				for(int i = index; i < range; i++)
				{
					temp = lc[i];
					lc[i] = cur;
					cur = temp;
				}
			}
		}

		public static void DisplayOut() {
			String report = "Highest Compares:\n";	
			int rank = 1;		
			for(Sort cur : hc)	
			{	
				if(rankcount >= rank)
					report += "  Rank " + rank++ + ": Search Count["+cur.cc+"]\n    Array: ["+display(cur.unsorted)+"]\n";
			}
			
			report =report+ "\n\nLowest Compares:\n";
			rank = 1;
			for(Sort cur : lc)
			{
				if(rankcount >= rank)
					report += "  Rank " + rank++ + ": Search Count["+cur.cc+"]\n    Array: ["+display(cur.unsorted)+"]\n";
			}
			System.out.println(report);
		}
		
		public static String display(int array[]) 
		{
			String text = "";
			for (int i = 0; i < array.length; ++i)
				text =text+ array[i] + " ";
			return text;
		}
}