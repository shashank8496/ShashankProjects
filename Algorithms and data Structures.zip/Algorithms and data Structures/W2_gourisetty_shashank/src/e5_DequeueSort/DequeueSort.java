package e5_DequeueSort;
import java.util.Arrays;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Random;
import e2_card.Card;
public class DequeueSort {

Card[] deck;
    public DequeueSort() {
        this.deck = new Card[52];
        String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        int i, j, count = 0;
        for(i = 0; i < Ranks.length; i++) {
            for(j = 0; j < Suits.length; j++) {  
                this.deck[count++] = new Card(Suits[j], Ranks[i]);
            }
        }
    }
    
    public Card getCard(int position) {
        return this.deck[position];
    }
    
    //Swapping cards
    public void exchange(int index1, int index2) {
        String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        Card temp;
        temp = new Card(Suits[this.deck[index1].getSuit()], Ranks[this.deck[index1].getRank()]);
        this.deck[index1] = new Card(Suits[this.deck[index2].getSuit()], Ranks[this.deck[index2].getRank()]);
        this.deck[index2] = new Card(Suits[temp.getSuit()], Ranks[temp.getRank()]);
    }
    
    public void shuffle(int noOfExchanges) {
        Random rnd = new Random();//generates random  numbers 
        int i, index1, index2;
        for(i = 0; i < noOfExchanges; i++) {
            
            index1 = rnd.nextInt(52);
            index2 = rnd.nextInt(52);
            
            this.exchange(index1, index2);
        } 
    }
    
     
    public void exchangeTop()//exchange the top card
    {
    	exchange(0, 1);
    }
    //card shuffle from top to bottom
    public void moveTopToBottom()
    {
    	Card temp=deck[0];
    	for(int i=0;i<deck.length-1;i++)
    		deck[i]=deck[i+1];
    	deck[deck.length-1]=temp;
    }

    public void Deque()
    {	
    	for(int k=0;k<52;k++)
    	{
    			for(int i=1;i<52-k;i++)
    			{
    				if(deck[0].compareTo(deck[1])>0)
    				{
    					exchangeTop();
    				}
    				moveTopToBottom();
    			}
	    		for(int i=0;i<=k;i++)
	    			moveTopToBottom();
    	}
    }
     boolean isSorted()
    {
 
        for (int i = 1; i < deck.length; i++)
        	if (deck[i-1] .compareTo(deck[i])>0)
                return false;
     return true;
    }
     
    public String toString() {
        int i,j;
        String strCards = "";
        
        for(i = 0,j=1; i < 52; i++,j++) {
        	if(j%11==0)
        	{
        		strCards = strCards + this.deck[i].toString() + "\t"+"\n";
        	}
        	else
            strCards = strCards + this.deck[i].toString() + "\t";
        }
        
        return strCards;
    }
    
    public void display() {
        System.out.println(this.toString());
    }
    
    public void selectionSort() {
        int i, j, minIndex;
        
        for(i = 0; i < 51; i++) { 
            minIndex = i; 
            for(j = i + 1; j < 52; j++) {  
                if(this.deck[j].compareTo(this.deck[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            
            this.exchange(i, minIndex);
        }
    }
    
   
    public void insertionSort() {
        int i, j;
        Card sortcard;
        String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        
        for(i = 1; i < 52; i++) { 
            sortcard = new Card(Suits[this.deck[i].getSuit()], Ranks[this.deck[i].getRank()]);
            j = i - 1;  
            while(j >= 0 && this.deck[j].compareTo(sortcard) > 0) {
                
                this.deck[j + 1] = new Card(Suits[this.deck[j].getSuit()], Ranks[this.deck[j].getRank()]);
                
                j = j - 1;
            }
            
            this.deck[j + 1]  = new Card(Suits[sortcard.getSuit()], Ranks[sortcard.getRank()]);
        }
    }
    
    public void shellSort() {
        int i, h, j;
        Card temp;
        String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        
        for(h = 26; h > 0; h = h / 2) {
            
            for(i = h; i < 52; i++) {
              
                temp = new Card(Suits[this.deck[i].getSuit()], Ranks[this.deck[i].getRank()]);
                for(j = i; j >= h && this.deck[j - h].compareTo(temp) > 0; j = j - h) {
                    this.deck[j] = new Card(Suits[this.deck[j - h].getSuit()], Ranks[this.deck[j - h].getRank()]);
                } 
                this.deck[j] = new Card(Suits[temp.getSuit()], Ranks[temp.getRank()]);
            }
        }
    }
}
