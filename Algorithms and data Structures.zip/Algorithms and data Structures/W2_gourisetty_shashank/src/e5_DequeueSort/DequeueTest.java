package e5_DequeueSort;
/*
 * @author Sai Shashank Gourisetty
 */
public class DequeueTest {
	static void deckstatus() {
		
		DequeueSort myDeck = new DequeueSort();
		    myDeck.Deque();
		    if(myDeck.isSorted())
		    	System.out.println("the deck is sorted");
		    else
		    	System.out.println("the deck is not sorted");
	}
	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
    	System.out.println("Test Case 1");
    	System.out.println("After deque method");
		deckstatus();
		DequeueSort deck = new DequeueSort();
        
        System.out.println("Test case 2:");
        System.out.println("The initial deck:\n" + deck.toString());
        System.out.println("After exchangetop");
        deck.exchangeTop();
        deck.display();
       
       System.out.println("Test case 3:");
        System.out.println("After 2 exchanges:");
        deck.shuffle(2);
        System.out.println("Deck status");
        deck.display();
        System.out.println("After toptobottom:");
        deck.moveTopToBottom();
        deck.display();
        
        System.out.println("Test case 4:");
        System.out.println("After Shell sort:");
        deck.shellSort();
        deck.display();
        
        System.out.println("Test case 5:");
        System.out.println("After Insertion sort:");
        deck.insertionSort();
        deck.display();
    }
}