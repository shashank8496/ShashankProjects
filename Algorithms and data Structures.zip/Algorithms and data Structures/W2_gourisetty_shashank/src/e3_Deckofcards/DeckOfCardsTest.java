package e3_Deckofcards;
/*
 * @author Sai Shashank Gourisetty
 */
public class DeckOfCardsTest {

	public static void main(String[] args) {
		System.out.println("Test output produced by Sai Shashank Gourisetty");
        DeckOfCards deck = new DeckOfCards();
       
        System.out.println("Test case 1 ");
        System.out.println("The original deck:\n" + deck.toString());
        System.out.println("13th Card: " + deck.getCard(12).toString());
        System.out.println("After 14 exchanges in a shuffle:");
        deck.shuffle(14);
        System.out.println("Deck now:");
        deck.display();
        
        System.out.println("After Selection sort:");
        deck.selectionSort();//calling selection sort method
        deck.display();
        
        System.out.println("Test case 2 ");
        System.out.println("After 14 exchanges in a shuffle:");
        deck.shuffle(14);
        System.out.println("Deck now:");
        deck.display();
        System.out.println("42nd Card: " + deck.getCard(41).toString());
        System.out.println("After Insertion sort:");
        deck.insertionSort();//calling Insertion sort method
        deck.display();
       
        System.out.println("Test case 3 ");
        System.out.println("51st Card: " + deck.getCard(50).toString());
        System.out.println("After 13 exchanges in a shuffle:");
        deck.shuffle(13);
        System.out.println("Deck now:");
        deck.display();
        System.out.println("After Shell sort:");
        deck.shellSort();//calling shell sort method
        deck.display();
        
        System.out.println("Test case 4 ");
        System.out.println("22nd Card: " + deck.getCard(21).toString());
        System.out.println("After 6 exchanges in a shuffle:");
        deck.shuffle(6);
        System.out.println("Deck now:");
        deck.display();
        
        
        System.out.println("Test case 5 ");
        System.out.println("27th Card: " + deck.getCard(26).toString());
        System.out.println("After 25 exchanges in a shuffle:");
        deck.shuffle(25);
        System.out.println("Deck now:");
        deck.display();      
    }
}
