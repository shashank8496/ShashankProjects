package e3_Deckofcards;
/*
 * @author Sai Shashank Gourisetty
 */
import java.util.Random;
import e2_card.Card;
public class DeckOfCards {
Card[] deck;
    public DeckOfCards() 
    {
        this.deck = new Card[52];
        String[] Suits = new String[]{"diamonds", "clubs", "hearts", "spades"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        int i, j, count = 0;
         for(i = 0; i < Ranks.length; i++) 
         {
            for(j = 0; j < Suits.length; j++)
            {  
                this.deck[count++] = new Card(Suits[j], Ranks[i]);
            }
        }
    }
    
    // position of the card
    public Card getCard(int position) 
    {
        return this.deck[position];
    }
    
    // exchange method 
    public void exchange(int index1, int index2) {
        String[] Suits = new String[]{"diamond", "club", "heart", "spade"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        Card temp;
        
        temp = new Card(Suits[this.deck[index1].getSuit()], Ranks[this.deck[index1].getRank()]);
        this.deck[index1] = new Card(Suits[this.deck[index2].getSuit()], Ranks[this.deck[index2].getRank()]);
        this.deck[index2] = new Card(Suits[temp.getSuit()], Ranks[temp.getRank()]);
    }
    //number of exchanges
    public void shuffle(int noOfExchanges) {
        Random rnd = new Random();  
        int i, index1, index2;
        
        
        for(i = 0; i < noOfExchanges; i++) 
        {
            index1 = rnd.nextInt(52);// Generate random index
            index2 = rnd.nextInt(52);
            this.exchange(index1, index2);//swapping
        } 
    }
    
    public String toString() {
        int i,j;
        String strCards = "";
        
        for(i = 0,j=1; i < 52; i++,j++) {
            // Add all cards 
        	if(j%11==0)
        	{
        		strCards = strCards + this.deck[i].toString() + "\t"+"\n";
        	}
        	else
            strCards = strCards + this.deck[i].toString() + "\t";
        }
        
        return strCards;
    }
    //Display the card
    public void display() {
        System.out.println(this.toString());
    }
    //Searches for the minimum element in the list and swaps
    public void selectionSort() {
        int i, j, minIndex;
        
        for(i = 0; i < 51; i++) {  
            minIndex = i;  
            for(j = i + 1; j < 52; j++) {  
                
                if(this.deck[j].compareTo(this.deck[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            
            this.exchange(i, minIndex);
        }
    }
    
     //Compare with all elements in the sorted sublist and shifts all the elements greater than the value to be sorted
	
    public void insertionSort() {
        int i, j;
        Card sortcard;
        String[] Suits = new String[]{"diamond", "club", "heart", "spade"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        
        for(i = 1; i < 52; i++) {  
            sortcard = new Card(Suits[this.deck[i].getSuit()], Ranks[this.deck[i].getRank()]);
            j = i - 1;  
   
            while(j >= 0 && this.deck[j].compareTo(sortcard) > 0) {
                this.deck[j + 1] = new Card(Suits[this.deck[j].getSuit()], Ranks[this.deck[j].getRank()]);
                j = j - 1;
            }    
            this.deck[j + 1]  = new Card(Suits[sortcard.getSuit()], Ranks[sortcard.getRank()]);
        }
    }
    //Divide list into small sub list of h equal interval and sorts this groups using insertion sort
    
    public void shellSort() {
        int i, s, j;
        Card temp;
        String[] Suits = new String[]{"diamond", "club", "heart", "spade"};
        String[] Ranks = new String[]{"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for(s = 26; s > 0; s = s / 2) {
             for(i = s; i < 52; i++) {
                temp = new Card(Suits[this.deck[i].getSuit()], Ranks[this.deck[i].getRank()]);
                for(j = i; j >= s && this.deck[j - s].compareTo(temp) > 0; j = j - s) 
                    this.deck[j] = new Card(Suits[this.deck[j - s].getSuit()], Ranks[this.deck[j - s].getRank()]);
                this.deck[j] = new Card(Suits[temp.getSuit()], Ranks[temp.getRank()]);
            }
        }
    }
}